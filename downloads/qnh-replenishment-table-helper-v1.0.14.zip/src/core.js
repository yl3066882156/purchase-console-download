/** Pure review logic. No browser, storage, network or platform write operations. */
const PDD_ORIGIN = 'https://mobile.yangkeduo.com';
const isBlank = value => value == null || String(value).trim() === '';

function fail(message, code = 'INVALID_INPUT') {
  const error = new Error(message);
  error.code = code;
  throw error;
}

function idString(value, label, { optional = false, zero = false } = {}) {
  if (isBlank(value)) {
    if (optional) return '';
    fail(`缺少${label}`, 'MISSING_ID');
  }
  if (typeof value === 'number' && !Number.isSafeInteger(value)) {
    fail(`${label}必须使用完整的字符串ID`, 'UNSAFE_ID');
  }
  const result = String(value).trim();
  if (!/^\d+$/.test(result) || (!zero && /^0+$/.test(result))) {
    fail(`${label}必须是${zero ? '非负' : '正'}整数字符串`, 'INVALID_ID');
  }
  return result;
}

/** IDs remain strings. Haixiaobao uses group "0" when no group is supplied. */
export function buildCheckoutLink({ goodsId, skuId, groupId = '', goodsNumber = '1' } = {}) {
  const goods = idString(goodsId, '商品ID');
  const sku = idString(skuId, '规格ID');
  const group = idString(isBlank(groupId) ? '0' : groupId, '拼团ID', { zero: true });
  const quantity = idString(goodsNumber, '购买数量');
  const params = new URLSearchParams({ sku_id: sku, group_id: group });
  params.set('goods_id', goods);
  params.set('goods_number', quantity);
  return `${PDD_ORIGIN}/order_checkout.html?${params}`;
}

/** Repair legacy generated links before selection; never carry a quote across groups. */
export function normalizeCheckoutCandidate(candidate, { groupId: overrideGroup } = {}) {
  const c = { ...candidate };
  const goodsId = idString(c.goodsId, '商品ID'), skuId = idString(c.skuId, '规格ID');
  const quantity = idString(c.goodsNumber ?? '1', '购买数量');
  const parsed = c.checkoutUrl ? parsePddLink(c.checkoutUrl) : null;
  if (parsed && (parsed.kind !== 'checkout' || parsed.goodsId !== goodsId || parsed.skuId !== skuId || parsed.goodsNumber !== quantity)) fail('候选商品、SKU或数量与结算链接不一致');
  const declared = idString(c.groupId, '拼团ID', { optional: true, zero: true });
  if (declared && parsed?.groupId && declared !== parsed.groupId) fail('候选拼团ID与结算链接不一致');
  const previousGroup = parsed ? parsed.groupId : declared;
  const groupId = overrideGroup != null ? idString(overrideGroup, '拼团ID', { zero: true }) : declared || parsed?.groupId || '0';
  c.groupId = groupId;
  if (overrideGroup != null) c.groupIdSource = 'official_catalog';
  c.goodsNumber = quantity;
  c.checkoutUrl = buildCheckoutLink({ goodsId, skuId, groupId, goodsNumber: quantity });
  if (!declared && !parsed?.groupId && overrideGroup == null) c.groupIdSource = 'haixiaobao_default';
  let quoteGroupMatches = true;
  if (c.actualPayPriceSource) try { quoteGroupMatches = new URL(c.actualPayPriceSource.sourceUrl).searchParams.get('group_id') === groupId; } catch { quoteGroupMatches = false; }
  if (previousGroup !== groupId || !quoteGroupMatches) {
    for (const key of ['actualPayPrice', 'actualPayPriceUnit', 'actualPayPriceSource']) delete c[key];
  }
  return c;
}

export function parsePddLink(input) {
  if (typeof input !== 'string' || !input.trim()) fail('请输入一条拼多多链接', 'EMPTY_URL');
  const sourceUrl = input.trim();
  if (/\s/.test(sourceUrl) || (sourceUrl.match(/https?:\/\//gi) || []).length > 1) {
    fail('请一次只输入一条完整链接，不要附带文字', 'MULTIPLE_OR_EMBEDDED_URLS');
  }
  let url;
  try { url = new URL(sourceUrl); } catch { fail('链接格式不正确', 'INVALID_URL'); }
  if (url.protocol !== 'https:' || url.hostname !== 'mobile.yangkeduo.com' || url.port || url.username || url.password) {
    fail('仅支持 https://mobile.yangkeduo.com 的商品或结算链接', 'UNSUPPORTED_ORIGIN');
  }
  let kind;
  if (/^\/goods\d*\.html$/.test(url.pathname)) kind = 'detail';
  else if (url.pathname === '/order_checkout.html') kind = 'checkout';
  else fail('仅支持商品详情页或指定SKU结算页', 'UNSUPPORTED_PATH');
  const seen = new Map();
  for (const [key, value] of url.searchParams) {
    if (seen.has(key) && seen.get(key) !== value) fail(`链接中有冲突的重复参数：${key}`, 'CONFLICTING_PARAMETER');
    seen.set(key, value);
  }
  const goodsId = idString(seen.get('goods_id'), '商品ID');
  const skuId = idString(seen.get('sku_id'), '规格ID', { optional: kind === 'detail' });
  const groupId = idString(seen.get('group_id'), '拼团ID', { optional: true, zero: true });
  const goodsNumber = idString(seen.has('goods_number') ? seen.get('goods_number') : '1', '购买数量');
  return {
    sourceUrl, goodsId, skuId, groupId, goodsNumber, kind,
    detailUrl: `${PDD_ORIGIN}/goods.html?goods_id=${goodsId}`,
    checkoutUrl: skuId ? buildCheckoutLink({ goodsId, skuId, groupId, goodsNumber }) : '',
  };
}

/** Auxiliary comparison only: preserve decimals and meaningful separators. */
export function normalizeSpec(value) {
  return String(value ?? '').normalize('NFKC').toUpperCase()
    .replace(/公斤|千克/g, 'KG').replace(/毫升/g, 'ML').replace(/厘米/g, 'CM').replace(/毫米/g, 'MM')
    .replace(/克/g, 'G').replace(/升/g, 'L')
    .replace(/[×✕⨉]/g, 'X').replace(/[—–−]/g, '-')
    .replace(/【/g, '[').replace(/】/g, ']').replace(/\s+/g, '');
}

function gcd(a, b) {
  a = a < 0n ? -a : a;
  b = b < 0n ? -b : b;
  while (b) [a, b] = [b, a % b];
  return a || 1n;
}

function fraction(n, d = 1n) {
  if (d === 0n) fail('分母不能为0');
  if (d < 0n) { n = -n; d = -d; }
  const divisor = gcd(n, d);
  return { n: n / divisor, d: d / divisor };
}

function decimalFraction(value, label, { optional = false, zero = false, integer = false } = {}) {
  if (isBlank(value)) {
    if (optional) return null;
    fail(`请填写${label}`);
  }
  if (typeof value === 'number' && (!Number.isFinite(value) || Math.abs(value) > Number.MAX_SAFE_INTEGER)) {
    fail(`${label}数值不安全，请使用十进制字符串`);
  }
  const text = String(value).trim();
  if (text.length > 120 || !/^\d+(?:\.\d+)?$/.test(text)) fail(`${label}必须是明确的非负十进制数`);
  const [whole, tail = ''] = text.split('.');
  const result = fraction(BigInt(whole + tail), 10n ** BigInt(tail.length));
  if ((!zero && result.n === 0n) || (integer && result.d !== 1n)) {
    fail(`${label}必须是${zero ? '非负' : '正'}${integer ? '整数' : '数'}`);
  }
  return result;
}

const divide = (a, b) => fraction(a.n * b.d, a.d * b.n);
const multiply = (a, b) => fraction(a.n * b.n, a.d * b.d);
const compare = (a, b) => a.n * b.d < b.n * a.d ? -1 : a.n * b.d > b.n * a.d ? 1 : 0;

function decimalText(value, scale = 18) {
  const sign = value.n < 0n ? '-' : '';
  const n = value.n < 0n ? -value.n : value.n;
  let remainder = n % value.d;
  let result = sign + (n / value.d).toString();
  if (!remainder) return { text: result, exact: true };
  result += '.';
  for (let i = 0; i < scale && remainder; i++) {
    remainder *= 10n;
    result += (remainder / value.d).toString();
    remainder %= value.d;
  }
  return { text: result + (remainder ? '…' : ''), exact: remainder === 0n };
}

function outputFraction(value, { money = false } = {}) {
  if (!value) return null;
  const display = decimalText(value);
  const result = {
    numerator: value.n.toString(), denominator: value.d.toString(),
    exactText: value.d === 1n ? value.n.toString() : `${value.n}/${value.d}`,
    decimalText: display.text, decimalIsExact: display.exact,
    isInteger: value.d === 1n,
    integerValue: value.d === 1n ? value.n.toString() : null,
  };
  if (money) {
    const cents = (value.n * 100n * 2n + value.d) / (2n * value.d);
    result.currency = 'CNY';
    result.unit = 'yuan';
    result.display = `${cents / 100n}.${(cents % 100n).toString().padStart(2, '0')}`;
    result.displayRounding = 'half_up_2_decimals_for_preview_only';
  }
  return result;
}

function moneyFraction(value) {
  if (value == null || value === '') return null;
  if (typeof value === 'object') {
    const amount = decimalFraction(value.value, 'PDD价格', { zero: true });
    if (['fen', '分'].includes(value.unit)) return divide(amount, fraction(100n));
    if (['yuan', '元', 'CNY'].includes(value.unit)) return amount;
    fail('PDD价格单位未确认');
  }
  // Public helper default: a plain decimal price is CNY yuan.
  return decimalFraction(value, 'PDD价格', { zero: true });
}

/** Assumption: 1 PDD purchasing unit = ratio backend units; never rounds quantity up. */
export function computeConversion({ ratio, backendQuantity, pddPrice = null, stock, minOrderQty, orderMultiple } = {}) {
  const errors = [];
  const warnings = [];
  const take = fn => { try { return fn(); } catch (error) { errors.push(error.message); return null; } };
  const r = take(() => decimalFraction(ratio, '下单比例'));
  const quantity = take(() => decimalFraction(backendQuantity, '后台需求数量'));
  const price = take(() => moneyFraction(pddPrice));
  const available = take(() => decimalFraction(stock, '库存', { optional: true, zero: true, integer: true }));
  const minimum = take(() => decimalFraction(minOrderQty, '起订量', { optional: true, integer: true }));
  const multiple = take(() => decimalFraction(orderMultiple, '下单倍数', { optional: true, integer: true }));
  const pddQuantity = r && quantity ? divide(quantity, r) : null;
  if (pddQuantity && pddQuantity.d !== 1n) errors.push('换算采购数量不是整数，请人工调整比例或需求数量；系统不会自动凑整');
  if (pddQuantity && available && compare(pddQuantity, available) > 0) errors.push('换算采购数量超过已知库存');
  if (pddQuantity && minimum && compare(pddQuantity, minimum) < 0) errors.push('换算采购数量小于起订量');
  if (pddQuantity && multiple && divide(pddQuantity, multiple).d !== 1n) errors.push('换算采购数量不符合下单倍数');
  if (!available) warnings.push('库存未知，不能据此确认可购买');
  if (!price) warnings.push('PDD价格未知，暂不计算成本');
  const unitCost = r && price ? divide(price, r) : null;
  const totalCost = pddQuantity && price ? multiply(pddQuantity, price) : null;
  const trace = [];
  if (pddQuantity) trace.push({ field: 'pddQuantity', formula: '后台需求数量 ÷ 下单比例', operands: [outputFraction(quantity), outputFraction(r)], result: outputFraction(pddQuantity) });
  if (unitCost) trace.push({ field: 'unitCost', formula: 'PDD单位价格（元）÷ 下单比例', operands: [outputFraction(price), outputFraction(r)], result: outputFraction(unitCost, { money: true }) });
  if (totalCost) trace.push({ field: 'totalCost', formula: 'PDD单位价格（元）× 换算采购数量', operands: [outputFraction(price), outputFraction(pddQuantity)], result: outputFraction(totalCost, { money: true }) });
  return {
    ok: errors.length === 0, errors, warnings,
    ratioDirection: 'one_pdd_unit_equals_ratio_backend_units',
    ratio: outputFraction(r), backendQuantity: outputFraction(quantity),
    pddQuantity: outputFraction(pddQuantity), unitCost: outputFraction(unitCost, { money: true }),
    totalCost: outputFraction(totalCost, { money: true }),
    stock: outputFraction(available), minOrderQty: outputFraction(minimum), orderMultiple: outputFraction(multiple),
    trace,
  };
}

export function stableStringify(value) {
  const seen = new Set();
  function canonical(input, arrayItem = false) {
    if (input === undefined) return arrayItem ? null : undefined;
    if (input === null || typeof input === 'string' || typeof input === 'boolean') return input;
    if (typeof input === 'number') {
      if (!Number.isFinite(input)) fail('摘要不支持非有限数值');
      return input;
    }
    if (typeof input !== 'object') fail('摘要只支持JSON数据；ID请使用字符串');
    if (seen.has(input)) fail('摘要数据不能循环引用');
    seen.add(input);
    let result;
    if (Array.isArray(input)) result = Array.from(input, item => canonical(item, true));
    else {
      if (Object.getPrototypeOf(input) !== Object.prototype && Object.getPrototypeOf(input) !== null) fail('摘要只支持普通JSON对象');
      result = Object.create(null);
      for (const key of Object.keys(input).sort()) {
        const normalized = canonical(input[key]);
        if (normalized !== undefined) result[key] = normalized;
      }
    }
    seen.delete(input);
    return result;
  }
  const normalized = canonical(value);
  if (normalized === undefined) fail('摘要输入不能为空');
  return JSON.stringify(normalized);
}

/** Noncryptographic review fingerprint. Not a signature or a server concurrency guard. */
export function fingerprint(value) {
  let hash = 0xcbf29ce484222325n;
  for (const byte of new TextEncoder().encode(stableStringify(value))) {
    hash ^= BigInt(byte);
    hash = BigInt.asUintN(64, hash * 0x100000001b3n);
  }
  return `fnv1a64:${hash.toString(16).padStart(16, '0')}`;
}

function resolveDraft(draft) {
  const parsed = parsePddLink(draft.url ?? '');
  const candidate = draft.candidate || {};
  if (!isBlank(candidate.goodsId) && idString(candidate.goodsId, '候选商品ID') !== parsed.goodsId) fail('候选商品ID与链接不一致');
  const candidateSku = idString(candidate.skuId, '候选规格ID', { optional: true });
  if (candidateSku && parsed.skuId && candidateSku !== parsed.skuId) fail('候选SKU与链接SKU不一致，请重新选择');
  const skuId = candidateSku || parsed.skuId;
  if (!skuId) fail('请明确选择目标SKU；只有商品ID不能生成结算链接');
  if (draft.parsed) {
    for (const key of ['goodsId', 'skuId', 'groupId', 'goodsNumber']) {
      if (draft.parsed[key] != null && String(draft.parsed[key]) !== parsed[key]) fail('草稿链接已经变化，请重新解析并复核');
    }
  }
  return { parsed, checkoutUrl: buildCheckoutLink({ ...parsed, skuId }), skuId };
}

function ratioEqual(a, b) {
  try { return compare(decimalFraction(a, '原比例'), decimalFraction(b, '新比例')) === 0; } catch { return String(a ?? '') === String(b ?? ''); }
}

function reviewProjection(snapshot, draft) {
  return {
    snapshot: Object.fromEntries(['tenantId', 'relationId', 'backendSku', 'backendUpc', 'backendName', 'backendSpec', 'backendUnit', 'channel', 'supplier', 'oldUrl', 'pddGoodsId', 'pddSkuId', 'channelSpec', 'scopeText', 'scopeComplete', 'ratioRaw', 'constraintsText', 'readOnlyFallbackFields', 'fingerprint', 'identityVerified'].map(key => [key, snapshot[key] ?? null])),
    draft: {
      url: draft.url ?? '', parsed: draft.parsed ?? null,
      candidate: Object.fromEntries(['goodsId', 'skuId', 'spec', 'name', 'price', 'priceUnit', 'stock'].map(key => [key, draft.candidate?.[key] ?? null])),
      ...Object.fromEntries(['ratio', 'backendQuantity', 'ratioChangeApproved', 'rulesConfirmed', 'specConfirmed', 'scopeConfirmed', 'samePackConfirmed', 'expectedOriginalRatio', 'priceUpdate', 'referencePrice', 'ratioMappingVerified', 'minOrderQty', 'orderMultiple'].map(key => [key, draft[key] ?? null])),
    },
  };
}

/** Use this value as approvedFingerprint after approving this exact review version. */
export function draftFingerprint(snapshot = {}, draft = {}) {
  return fingerprint(reviewProjection(snapshot, draft));
}

/** Actual changed fields only. Only "url" is eligible for V0.1 native-form assistance. */
export function buildDiff(snapshot = {}, draft = {}) {
  let target;
  try { target = resolveDraft(draft); } catch { target = null; }
  const proposed = [
    ['url', '结算链接', snapshot.oldUrl, target?.checkoutUrl ?? draft.url, true],
    ['pddGoodsId', 'PDD商品ID', snapshot.pddGoodsId, target?.parsed.goodsId ?? draft.candidate?.goodsId, false],
    ['pddSkuId', 'PDD规格ID', snapshot.pddSkuId, target?.skuId ?? draft.candidate?.skuId, false],
    ['channelSpec', '渠道规格（仅比较）', snapshot.channelSpec, draft.candidate?.spec, false],
    ['ratioRaw', '下单比例（原生表单人工修改）', snapshot.ratioRaw, draft.ratio, false],
  ];
  if (draft.priceUpdate) proposed.push(['referencePrice', '参考价格（原生表单人工修改）', snapshot.referencePrice, draft.referencePrice, false]);
  return proposed.filter(([field, , before, after]) => after != null && (field === 'ratioRaw' ? !ratioEqual(before, after) : String(before ?? '') !== String(after))).map(([field, label, before, after, assistWritable]) => ({
    field, label, before: before ?? '', after, assistWritable,
    reason: assistWritable ? '仅辅助填写链接，用户仍需在原生表单保存' : '仅展示差异，不自动回写此字段',
  }));
}

export function validateDraft(snapshot = {}, draft = {}) {
  const errors = [];
  const warnings = [];
  const assistErrors = [];
  let resolved = null;
  try { resolved = resolveDraft(draft); } catch (error) { errors.push(error.message); }
  if (snapshot.channel && String(snapshot.channel).toLowerCase() !== 'pdd') errors.push('当前关系不是拼多多渠道');
  const ratio = isBlank(draft.ratio) ? snapshot.ratioRaw : draft.ratio;
  const ratioChanged = !ratioEqual(snapshot.ratioRaw, ratio);
  const candidate = draft.candidate || {};
  const price = isBlank(candidate.price) ? null : { value: candidate.price, unit: candidate.priceUnit };
  const calculation = computeConversion({
    ratio, backendQuantity: draft.backendQuantity, pddPrice: price,
    stock: candidate.stock, minOrderQty: draft.minOrderQty, orderMultiple: draft.orderMultiple,
  });
  errors.push(...calculation.errors);
  warnings.push(...calculation.warnings);
  if (snapshot.identityVerified !== true || isBlank(snapshot.tenantId) || isBlank(snapshot.relationId)) assistErrors.push('租户或relationshipID身份尚未确认，只能预览');
  if (snapshot.scopeComplete !== true || isBlank(snapshot.scopeText)) assistErrors.push('供货门店范围尚未完整读取，只能预览');
  if (isBlank(snapshot.channel)) assistErrors.push('当前关系渠道尚未确认，只能预览');
  if (Array.isArray(snapshot.readOnlyFallbackFields) && snapshot.readOnlyFallbackFields.length > 0) assistErrors.push('部分关系字段仅为原生列启发式读取，只能预览和复制，不能作为自动填入依据');
  if (draft.scopeConfirmed !== true) assistErrors.push('请确认本次关系的供货范围');
  if (isBlank(candidate.spec)) assistErrors.push('请填写候选SKU的规格或包装文本，作为人工复核依据');
  if (draft.specConfirmed !== true) assistErrors.push('请人工核对并确认目标SKU规格');
  if (draft.rulesConfirmed !== true) assistErrors.push('请确认起订量、倍数、箱规等原关系约束');
  if (draft.ratioMappingVerified !== true) {
    warnings.push('下单比例方向未验证，当前计算仅按“1个PDD单位对应ratio个后台单位”预览');
    if (ratioChanged || draft.samePackConfirmed !== true) {
      assistErrors.push('下单比例方向未验证，请确认替代SKU包装与原包装一致且原比例保持不变');
    } else {
      warnings.push('已确认同包装且比例保持原值；只允许填写链接，不据预览计算修改比例或价格');
    }
  }
  if (draft.expectedOriginalRatio != null && !ratioEqual(draft.expectedOriginalRatio, snapshot.ratioRaw)) {
    assistErrors.push('草稿记录的原比例与当前快照不一致，请重新读取关系');
  }
  if (ratioChanged) {
    warnings.push('本次下单比例与原值不同；V0.1不会填写比例，请在原生表单人工复核');
    if (draft.ratioChangeApproved !== true) warnings.push('比例变更尚未获人工确认');
    assistErrors.push('比例变更不能自动填充，请使用原生表单人工处理');
  }
  if (draft.priceUpdate === true) {
    warnings.push('V0.1不自动回写价格，参考价格只用于比较');
    assistErrors.push('包含价格回写意图，请使用原生表单人工处理');
  }
  if (candidate.spec && snapshot.backendSpec && normalizeSpec(candidate.spec) !== normalizeSpec(snapshot.backendSpec)) {
    warnings.push('候选规格与后台规格不同，需人工确认包装与转换关系');
  }
  let reviewFingerprint = '';
  try { reviewFingerprint = draftFingerprint(snapshot, draft); } catch (error) { errors.push(error.message); }
  if (!reviewFingerprint || draft.approvedFingerprint !== reviewFingerprint) assistErrors.push('草稿尚未确认或确认后已变化，请重新复核');
  const diff = buildDiff(snapshot, draft);
  if (resolved && !diff.some(row => row.field === 'url')) assistErrors.push('结算链接与原值相同，无需填充');
  warnings.push('辅助操作只填写结算链接；最终保存由用户在原生表单完成');
  const unique = values => [...new Set(values)];
  return {
    ok: errors.length === 0,
    canAssist: errors.length === 0 && assistErrors.length === 0,
    errors: unique(errors), warnings: unique(warnings), assistErrors: unique(assistErrors),
    calculation, diff, reviewFingerprint,
    checkoutUrl: resolved?.checkoutUrl ?? '', parsed: resolved?.parsed ?? null,
  };
}
