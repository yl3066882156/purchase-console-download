import {convertSkuPriceToYuan,isFreshCheckoutPrice,validateCheckoutPriceSource} from './draft-defaults.js';

const fresh=(source,now)=>typeof source?.capturedAt==='string'&&Number.isFinite(Date.parse(source.capturedAt))&&now-Date.parse(source.capturedAt)>=-5000&&now-Date.parse(source.capturedAt)<=60000;
const couponFields=['afterCouponPrice','afterCouponPriceUnit','afterCouponPriceSource'];
const checkoutFields=['actualPayPrice','actualPayPriceUnit','actualPayPriceSource'];
export function couponPrice(candidate,now=Date.now()){
 const source=candidate?.afterCouponPriceSource;
 if(source?.kind!=='visible_favorites_coupon_quote'||source.goodsId!==candidate.goodsId||source.skuId!==candidate.skuId||source.goodsNumber!=='1'||!fresh(source,now))return null;
 if(source.sourceTabId!=null&&source.sourceTabId!==candidate.sourceTabId)return null;
 try{const url=new URL(source.sourceUrl);if(url.origin!=='https://mobile.yangkeduo.com'||url.pathname!=='/likes.html'||url.username||url.password)return null;}catch{return null;}
 const amount=convertSkuPriceToYuan(candidate.afterCouponPrice,candidate.afterCouponPriceUnit);
 return amount.status==='converted'&&/[1-9]/.test(amount.value)?{value:amount.value,source}:null;
}

/** A current exact-SKU favorites offer is a cross-check, never a substitute payable. */
export function checkoutCouponConflict(candidate,now=Date.now()){
 const coupon=couponPrice(candidate,now),checkout=validateCheckoutPriceSource(candidate);
 if(!coupon||!checkout.valid)return false;
 const [whole,fraction='']=coupon.value.split('.'),scale=10n**BigInt(fraction.length);
 return BigInt(checkout.source.goodsPayableFen)*scale>BigInt(whole+fraction)*100n;
}

/** List presentation only. Never promotes a reference price to coupon/payable. */
export function resolveCatalogPrice(candidate={},now=Date.now()){
 if(isFreshCheckoutPrice(candidate,now)){
  const quote=validateCheckoutPriceSource(candidate);
  return {kind:'checkout',value:quote.value,text:'应付 ¥'+quote.value,title:'当前SKU采购1件的订单页应付价，含已核实运费；尚未提交订单'};
 }
 const coupon=couponPrice(candidate,now);
 if(coupon)return {kind:'coupon',value:coupon.value,text:'券后 ¥'+coupon.value,title:'收藏页当前SKU、数量1的券后价；点击规格后再核实订单页应付价'};
 return {kind:'pending',value:'',text:'价格请到官网核对',title:'采购价由员工在牵牛花手工填写，列表不展示未核实报价'};
}

/** Preserve quotes during data enrichment, scoped to exact SKU/tab/group. */
export function retainCatalogQuotes(previous,candidate,{preserveCoupon=false,now=Date.now()}={}){
 if(!previous||previous.goodsId!==candidate.goodsId||previous.skuId!==candidate.skuId||previous.sourceTabId!==candidate.sourceTabId)return candidate;
 const next={...candidate};
 const preserve=(fields,valid)=>{
  if(fields.some(key=>Object.hasOwn(candidate,key)))return;
  const combined={...next,...Object.fromEntries(fields.map(key=>[key,previous[key]]))};
  if(valid(combined))for(const key of fields)next[key]=structuredClone(previous[key]);
 };
 preserve(checkoutFields,c=>isFreshCheckoutPrice(c,now));
 if(preserveCoupon)preserve(couponFields,c=>!!couponPrice(c,now));
 return next;
}
