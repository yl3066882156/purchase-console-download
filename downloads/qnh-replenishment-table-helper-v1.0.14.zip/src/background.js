import {inspectPddFavoritesScroll,startFavoritesLoad,advanceFavoritesLoad,favoritesLoadProgress} from './pdd-favorites-loader.js';
import {createCartonUnitRuntime} from './qnh-carton-runtime.js';
import {selectExistingCartonForDraft} from './qnh-existing-carton.js';
import {retainCatalogQuotes,checkoutCouponConflict,couponPrice} from './catalog-price.js';
import {resolvePddSpecifications} from './pdd-spec-resolver.js';
import { validateDraft, parsePddLink, normalizeCheckoutCandidate } from './core.js';
import { readPddPage } from './pdd-reader.js';
import { ensureMobileSpecReader } from './pdd-mobile-specs.js';
import { readPddCheckoutQuotePage } from './pdd-checkout-reader.js';
import { PDD_OFFICIAL_ROUTES, classifyPddUrl, readPddFavoritesPage } from './pdd-collector.js';
import { validateMaintenanceDraft } from './maintenance.js';
import { validateCheckoutPriceSource } from './draft-defaults.js';
import { createProductDiscoveryRuntime } from './product-discovery-runtime.js';
import { validateDraftRecovery } from './draft-recovery.js';
import {buildProductSearchProfile} from './product-matching.js';
import {evaluateProcurementPrice} from './procurement-price-policy.js';
import {evaluatePromotionEligibility} from './pdd-promotions.js';
import {targetIdentity} from './auto-fill.js';

export function classifyTab(raw) {
  try {
    const u = new URL(raw || '');
    if (u.origin === 'https://qnh.meituan.com' && u.pathname === '/home.html' && u.hash.startsWith('#/pms/online-purchase-center/')) return 'qnh';
    if (u.origin === 'https://qnh.meituan.com' && ['/home.html','/'].includes(u.pathname) && u.hash.split('?')[0] === '#/purchase/replenishment/refer') return 'qnh_reference';
    if (u.protocol === 'http:' && ['127.0.0.1', 'localhost'].includes(u.hostname) && u.port === '8765' && u.pathname === '/demo/index.html') return 'demo';
    if (u.origin === 'https://mobile.yangkeduo.com' && /^\/goods\d*\.html$/.test(u.pathname)) return 'pdd';
    if (u.origin === 'https://mobile.yangkeduo.com' && u.pathname === '/personal.html') return 'pdd_account';
    if (u.origin === 'https://mobile.yangkeduo.com' && ['/', '/index.html','/personal_profile.html'].includes(u.pathname)) return 'pdd_account';
    const pdd=classifyPddUrl(raw);
    if(pdd==='favorites')return 'pdd_favorites';
    if(pdd==='login')return 'pdd_login';
    if(pdd==='product')return 'pdd_demo_product';
  } catch { /* Unknown tabs are not extension targets. */ }
  return '';
}

const error = (code, message) => Object.assign(new Error(message), {code});
const sameDecimal=(a,b)=>{
  const parse=v=>{const s=String(v??'');if(s.length>100||!/^\d+(?:\.\d+)?$/.test(s))return null;const [w,t='']=s.split('.');return [BigInt(w+t),10n**BigInt(t.length)];};
  const x=parse(a),y=parse(b);return !!x&&!!y&&x[0]*y[1]===y[0]*x[1];
};
const tabRoute = raw => {
  try {
    const u=new URL(raw);
    return `${u.origin}${u.pathname}${u.hash.split('?')[0]}`;
  } catch { return ''; }
};

export function repairPddCatalogLinks(catalog) {
  if (!catalog) return {products:[],skus:[]};
  const products=new Map((catalog.products||[]).map(p=>[p.goodsId,p]));
  return {...catalog,skus:(catalog.skus||[]).map(s=>{
    const p=products.get(s.goodsId),group=Number.isInteger(s.sourceTabId)&&p?.sourceTabId===s.sourceTabId&&p?.groupIdSource!=='haixiaobao_default'&&typeof p?.groupId==='string'&&/^\d+$/.test(p.groupId)?p.groupId:undefined;
    try{return normalizeCheckoutCandidate(s,{groupId:group});}catch{return {...s,checkoutUrl:'',specComplete:false};}
  })};
}

function orderFavoriteProducts(products,incoming,previous,evidence){
 const incomingIds=[...new Set(incoming.map(p=>p.goodsId))];
 if(evidence?.kind!=='rendered_favorites')return [...incomingIds.map(id=>products.get(id)),...[...products.values()].filter(p=>!incomingIds.includes(p.goodsId))];
 const ids=[...new Set((evidence.goodsIds||[]).filter(id=>incomingIds.includes(id)))];
 const base=[...new Set([...(previous||[]).map(p=>p.goodsId),...incomingIds])].filter(id=>products.has(id));
 if((evidence.coversLoaded===true&&incomingIds.every(id=>ids.includes(id)))||evidence.fromStart===true){
  return [...ids,...base.filter(id=>!ids.includes(id))].map(id=>products.get(id));
 }
 // A middle viewport supplies relative order, never proof that its first card
 // belongs at the head. Keep unseen products in their established positions.
 const known=ids.filter(id=>base.includes(id)&&previous?.some(p=>p.goodsId===id)),knownSet=new Set(known);
 let next=0,ordered=base.filter(id=>!ids.includes(id)||knownSet.has(id)).map(id=>knownSet.has(id)?known[next++]:id);
 for(let i=0;i<ids.length;i++){
  const id=ids[i];if(ordered.includes(id))continue;
  const following=ids.slice(i+1).find(other=>ordered.includes(other)),preceding=ids.slice(0,i).reverse().find(other=>ordered.includes(other));
  const at=following?ordered.indexOf(following):preceding?ordered.indexOf(preceding)+1:ordered.length;
  ordered.splice(at,0,id);
 }
 return ordered.map(id=>products.get(id));
}

export function mergePddCatalog(previous, result, tab, {expandedFavorites=false}={}) {
  if(result?.status!=='read')return previous || {products:[],skus:[]};
  const mode=result.isDemo?'demo':'official';
  const same=previous?.mode===mode;
  const products=new Map((same&&Array.isArray(previous.products)?previous.products:[]).map(p=>[p.goodsId,p]));
  const skus=new Map((same&&Array.isArray(previous.skus)?previous.skus:[]).map(s=>[s.goodsId+':'+s.skuId,s]));
  const capturedAt=result.capturedAt || new Date().toISOString();
  const source={sourceTabId:tab.id,sourceUrl:tab.url,capturedAt,isDemo:mode==='demo'};
  const incoming=result.products || (result.goodsId?[{goodsId:result.goodsId,name:result.name,groupId:result.groupId,groupIdSource:result.groupIdSource,detailUrl:result.sourceUrl,needsDetail:false,skuCoverage:'loaded_detail'}]:[]);
  const favorites=result.pageType==='favorites',priorSkus=new Map(skus),hasFullSpecs=(result.skus||[]).length>0&&(result.skus||[]).every(s=>String(s.spec||'').trim()&&s.specComplete!==false);
  for(const product of incoming){
    // A favorites page contains selected SKUs only. It cannot invalidate the
    // rest of a detail catalog. A fresh detail read still removes absent SKUs.
    if(!favorites)for(const [key,sku]of skus)if(sku.goodsId===product.goodsId)skus.delete(key);
    const old=products.get(product.goodsId),next={...old,...product,...source,...(!favorites&&hasFullSpecs?{detailReadAt:capturedAt}:{}),...(favorites?{favoritesObservedAt:capturedAt}:{})};
    if(old?.sourceTabId===tab.id&&old.groupId&&old.groupIdSource!=='haixiaobao_default'&&(!product.groupId||product.groupIdSource==='haixiaobao_default')){next.groupId=old.groupId;next.groupIdSource=old.groupIdSource;}
    products.set(product.goodsId,next);
  }
  for(const sku of result.skus || []){
    const key=sku.goodsId+':'+sku.skuId,old=priorSkus.get(key),next={...sku,...source};
    if(!next.thumbnailUrl&&old?.thumbnailUrl)next.thumbnailUrl=old.thumbnailUrl;
    if(old?.sourceTabId===tab.id&&old?.spec&&!String(sku.spec||'').trim())Object.assign(next,{spec:old.spec,specComplete:old.specComplete!==false,specSource:old.specSource||'product_sku',specReadAt:old.specReadAt||old.capturedAt});
    if(favorites&&old?.detailReadAt)next.detailReadAt=old.detailReadAt;
    if(!favorites&&String(sku.spec||'').trim())Object.assign(next,{detailReadAt:capturedAt,specReadAt:capturedAt});
    skus.set(key,next);
  }
  for(const product of incoming){const p=products.get(product.goodsId),variants=[...skus.values()].filter(s=>s.goodsId===p.goodsId&&s.sourceTabId===tab.id);p.needsDetail=!variants.some(s=>String(s.spec||'').trim()&&s.specComplete!==false);p.loadedSpecCount=variants.filter(s=>String(s.spec||'').trim()&&s.specComplete!==false).length;if(p.detailReadAt)p.skuCoverage='loaded_detail';}

  // Refresh favorites in the page's order, rather than the cache insertion
  // order. Detail/SKU enrichment keeps this order while retaining loaded data.
  const orderedProducts=favorites?orderFavoriteProducts(products,incoming,same?previous.products:[],result.favoritesOrder):[...products.values()];
  const expanded=expandedFavorites||previous?.expandedFavorites===true,productLimit=expanded?5000:300,skuLimit=expanded?50000:1000;
  const catalog=repairPddCatalogLinks({mode,...(expanded?{expandedFavorites:true}:{}),products:favorites?orderedProducts.slice(0,productLimit):orderedProducts.slice(-productLimit),skus:[...skus.values()].slice(-skuLimit),updatedAt:capturedAt,lastSourceUrl:tab.url,coverage:result.coverage,warnings:result.warnings || []});
  const changed=new Set((result.skus||[]).map(s=>s.goodsId+':'+s.skuId));
  catalog.skus=catalog.skus.map(s=>changed.has(s.goodsId+':'+s.skuId)?retainCatalogQuotes(priorSkus.get(s.goodsId+':'+s.skuId),s,{preserveCoupon:!favorites}):s);
  return catalog;
}
export function createRouter(api, {quoteWait=()=>new Promise(resolve=>setTimeout(resolve,500)),quoteAttempts=16,referenceReader,enforceProcurementPolicy=true,existingCartonSelector=selectExistingCartonForDraft}={}) {
  let receiptQueue = Promise.resolve();
  let catalogQueue = Promise.resolve();
  let quoteQueue = Promise.resolve();
  let latestQuoteRequestId = '';
  let tabQuoteBusy=false;
  let officialQueue=Promise.resolve(),officialWork='';
  const withOfficialOperation=(kind,fn)=>{const work=officialQueue.then(async()=>{officialWork=kind;try{return await fn();}finally{officialWork='';}});officialQueue=work.catch(()=>{});return work;};
  const activeAssists = new Set();
  const fillLocks = new Set();
  const ensureTab = async (tabId, kinds) => {
    if (!Number.isInteger(tabId)) throw error('NO_TARGET_TAB', '请先选择网采中心、补货参考或本地演示标签页');
    let tab;
    try { tab = await api.tabs.get(tabId); } catch { throw error('NO_TARGET_TAB', '目标标签页已关闭，请重新选择'); }
    const kind = classifyTab(tab.url);
    if (!kinds.includes(kind)) throw error('WRONG_TARGET_TAB', '目标标签页已关闭、导航或不在允许的维护页面，请重新选择');
    return tab;
  };
  const send = async (tabId, message) => {
    const readOnly=['QNH_READ_PAGE','QNH_GET_RELATION','QNH_INSPECT_EDITOR','QNH_VERIFY_RELATION','QNH_VERIFY_MAINTENANCE','QNH_PLAN_NEW_FORM_COMPLETION'].includes(message.type);
    const sendOnce=async()=>{
      const envelope=api.runtime.getManifest?.().version?{...message,type:'QNH_ADAPTER_1_1_2',action:message.type}:message;
      const response=await api.tabs.sendMessage(tabId,envelope);
      if(!response)throw error('EMPTY_RESPONSE','页面适配器没有响应');
      if(!response.ok)throw Object.assign(new Error(response.error?.message||'页面操作失败'),response.error||{});
      return response.data;
    };
    try {
      return await sendOnce();
    } catch (cause) {
      if(readOnly&&(!cause.code||cause.code==='EMPTY_RESPONSE')&&api.scripting?.executeScript){
        try{const before=await ensureTab(tabId,['qnh','qnh_reference','demo']);await api.scripting.executeScript({target:{tabId},files:['content/qnh.js']});await confirmReturnedTab(before);return await sendOnce();}catch(reconnect){if(reconnect.code&&reconnect.code!=='EMPTY_RESPONSE')throw reconnect;}
      }
      if (cause.code) throw cause;
      throw error('PAGE_ADAPTER_UNAVAILABLE', '页面适配器尚未连接。加载插件后请刷新网采中心、补货参考或演示页面再试。');
    }
  };
  const mutateReceipts = operation => {
    const work = receiptQueue.then(async () => {
      const stored = await api.storage.local.get('receipts');
      const receipts = Array.isArray(stored.receipts) ? stored.receipts : [];
      const {next, result} = operation(receipts);
      await api.storage.local.set({receipts:next.slice(0,100)});
      return result;
    });
    receiptQueue = work.catch(() => {});
    return work;
  };
  const appendReceipt = entry => mutateReceipts(receipts => {
    const receipt = {...entry,id:crypto.randomUUID(),at:new Date().toISOString()};
    return {next:[receipt,...receipts],result:receipt};
  });
  const updateReceipt = (id, patch) => mutateReceipts(receipts => {
    const previous = receipts.find(r=>r.id===id);
    if (!previous) throw error('NO_RECEIPT','待核对记录已不存在，请重新读取');
    const updated = {...previous,...patch};
    return {next:receipts.map(r=>r.id===id?updated:r),result:updated};
  });
  const stampSnapshot = (snapshot, tab) => snapshot && ({...snapshot,sourceTabId:tab.id,sourceTabUrl:tab.url});
  const stampResult = (result, tab) => ({
    ...result,
    ...(result?.snapshot ? {snapshot:stampSnapshot(result.snapshot,tab)} : {}),
    ...(Array.isArray(result?.relations) ? {relations:result.relations.map(snapshot=>stampSnapshot(snapshot,tab))} : {}),
  });
  const confirmReturnedTab = async initial => {
    const current = await ensureTab(initial.id,['qnh','qnh_reference','demo']);
    if (tabRoute(current.url)!==tabRoute(initial.url)) throw error('NAVIGATION_CHANGED','目标页面在操作期间切换到其他路由，请重新读取关系');
    return current;
  };
  const pddKinds=['pdd','pdd_favorites','pdd_login','pdd_account','pdd_demo_product'];
  const ownedPddTab=async()=>{
    const {pddTabWorkspace}=await api.storage.local.get('pddTabWorkspace');
    if(pddTabWorkspace?.owned!==true||!Number.isInteger(pddTabWorkspace.tabId))throw error('NO_PDD_WORKSPACE','请先连接拼多多官方标签页');
    let tab;
    try{tab=await api.tabs.get(pddTabWorkspace.tabId);}catch{throw error('NO_PDD_WORKSPACE','官方标签页已关闭，请重新连接');}
    const url=tab.url;
    if(tab.status==='loading'&&(!url||url==='about:blank'))return tab;
    let u;try{u=new URL(url);}catch{}
    if(u?.origin!=='https://mobile.yangkeduo.com')throw error('PDD_WORKSPACE_NAVIGATED','官方标签页已切换到其他网站；不会自动改写，请重新连接');
    return tab;
  };
  const waitForPddTabLoad=async tabId=>{
    const events=api.tabs.onUpdated;
    if(!events)return api.tabs.get(tabId);
    return new Promise((resolve,reject)=>{
      const finish=(fn,value)=>{
        clearTimeout(timeout);
        events.removeListener(updated);
        api.tabs.onRemoved?.removeListener(closed);
        fn(value);
      };
      const updated=(id,change,tab)=>{if(id===tabId&&change.status==='complete')finish(resolve,tab);};
      const closed=id=>{if(id===tabId)finish(reject,error('NO_PDD_WORKSPACE','商品详情标签页已关闭'));};
      const timeout=setTimeout(()=>finish(reject,error('PDD_DETAIL_TIMEOUT','商品详情仍在加载，请在官网查看')),15000);
      events.addListener(updated);
      api.tabs.onRemoved?.addListener(closed);
      api.tabs.get(tabId).then(tab=>{if(tab.status==='complete')finish(resolve,tab);},e=>finish(reject,e));
    });
  };
  const openPdd = async (url,{resetCatalog=false,newTab=false}={}) => {
    await catalogQueue;
    const {pddContext,pddCatalog}=await api.storage.local.get(['pddContext','pddCatalog']);
    const nextMode=new URL(url).origin==='https://mobile.yangkeduo.com'?'official':'demo';
    let tab=null;
    if(!newTab&&pddContext?.tabId){try{const current=await api.tabs.get(pddContext.tabId);if(pddKinds.includes(classifyTab(current.url)))tab=await api.tabs.update(current.id,{url,active:true});}catch{/* Closed workspace: make a new one. */}}
    if(!tab){
      if(!newTab&&api.windows?.create){const win=await api.windows.create({url,type:'popup',width:560,height:840,focused:true});tab=win.tabs?.[0];}
      if(!tab)tab=await api.tabs.create({url,active:true});
    }
    if(tab.windowId&&api.windows?.update)await api.windows.update(tab.windowId,{focused:true}).catch(()=>{});
    const context={tabId:tab.id,windowId:tab.windowId || null,url,openedAt:new Date().toISOString()};
    await api.storage.local.set({pddContext:context,...(resetCatalog||pddCatalog?.mode!==nextMode?{pddCatalog:{products:[],skus:[],mode:nextMode}}:{})});
    return context;
  };
  const readPdd = async (tabId,{fullFavorites=false,catalogTab=null,scanJobId=null}={}) => {
    const tab=await ensureTab(tabId,pddKinds);
    const kind=classifyPddUrl(tab.url);
    if(kind==='login')return {status:'login_required',pageType:'login',products:[],skus:[],message:'请在拼多多官方窗口完成登录，再点击“打开收藏”和“读取当前页面”。'};
    if(classifyTab(tab.url)==='pdd_account')return {status:'open_favorites',pageType:'account',products:[],skus:[],message:'官方窗口已进入个人中心。请点击侧栏“打开商品收藏”，再读取收藏商品。'};
    const results=await api.scripting.executeScript({target:{tabId},world:'MAIN',func:kind==='favorites'?readPddFavoritesPage:readPddPage,...(kind==='favorites'&&fullFavorites?{args:[{fullFavorites:true}]}:{})});
    if(!results[0]?.result)throw error('PDD_READ_FAILED','当前页面未返回商品数据，请在官方窗口确认页面已加载');
    const current=await ensureTab(tabId,pddKinds);
    if(current.url!==tab.url)throw error('NAVIGATION_CHANGED','拼多多页面在读取期间发生导航，请重新读取');
    const result=results[0].result;
    if(result.status==='read'){
      const u=new URL(current.url),isDemo=u.origin!=='https://mobile.yangkeduo.com';
      if(Boolean(result.isDemo)!==isDemo)throw error('PDD_MODE_MISMATCH','采集结果的演示/官方来源不匹配，已拒绝入库');
      const positiveId=v=>typeof v==='string'&&/^[1-9]\d*$/.test(v);
      if(kind==='product'){
        const ids=u.searchParams.getAll('goods_id');
        if(!ids.length||new Set(ids).size!==1||!positiveId(ids[0])||result.goodsId!==ids[0])throw error('PDD_ID_MISMATCH','商品页面与读取到的商品ID不一致');
        if((result.skus||[]).some(s=>s.goodsId!==result.goodsId||!positiveId(s.skuId)))throw error('PDD_ID_MISMATCH','候选SKU不属于当前商品');
      }else{
        const ids=new Set((result.products||[]).map(p=>p.goodsId));
        if([...ids].some(id=>!positiveId(id))||(result.skus||[]).some(s=>!ids.has(s.goodsId)||!positiveId(s.skuId)))throw error('PDD_ID_MISMATCH','收藏商品与规格的归属不完整');
      }
    }
    const work=catalogQueue.then(async()=>{
      const {pddCatalog,pddFavoritesLoad}=await api.storage.local.get(['pddCatalog','pddFavoritesLoad']);
      if(scanJobId&&(pddFavoritesLoad?.id!==scanJobId||pddFavoritesLoad.state!=='running'))return {status:'superseded',catalog:pddCatalog};
      // The scanner and explicit detail tabs feed the same sidebar workspace.
      const source=catalogTab?{...current,id:catalogTab.id}:current;
      const catalog=mergePddCatalog(pddCatalog,result,source,{expandedFavorites:fullFavorites});
      const context=catalogTab||current;
      await api.storage.local.set({pddContext:{tabId:context.id,windowId:context.windowId||null,url:context.url},...(result.status==='read'?{pddCatalog:catalog}:{})});
      return {...result,catalog};
    });catalogQueue=work.catch(()=>{});return work;
  };
  const closeFavoritesScanner=async job=>{
    if(!Number.isInteger(job?.scanTabId)||job.scanTabId===job.tabId)return;
    try{
      const scanner=await api.tabs.get(job.scanTabId);
      if(!scanner.active&&scanner.url===job.scanUrl)await api.tabs.remove(scanner.id);
    }catch{/* Already closed or changed by the user. */}
  };
  const favoritesSnapshot=(tab,job,catalog)=>({
    status:'read',pageType:'favorites',tabId:tab.id,catalog:catalog||{products:[],skus:[]},
    products:(job?.productsComplete?job.seen:[...new Set([...(job?.retainedIds||[]),...(job?.seen||[])])]).map(goodsId=>({goodsId})),
    favoritesLoad:favoritesLoadProgress(job),
    ...(job?.productsComplete===true?{favoriteIds:job.seen}:{})
  });
  const quoteIdentity = (raw, expected) => {
    try {
      const parsed=parsePddLink(raw),url=new URL(raw);
      return parsed.kind==='checkout'&&['goods_id','sku_id','goods_number'].every(key=>url.searchParams.getAll(key).length===1)&&url.searchParams.getAll('group_id').length<=1&&parsed.goodsNumber==='1'&&parsed.goodsId===expected.goodsId&&parsed.skuId===expected.skuId&&parsed.groupId===expected.groupId;
    } catch { return false; }
  };
  const quoteCandidate = candidate => {
    if(!candidate||candidate.isDemo===true||['goodsId','skuId'].some(key=>typeof candidate[key]!=='string'||!/^[1-9]\d*$/.test(candidate[key])))throw error('INVALID_QUOTE_CANDIDATE','请先选择完整的官方商品与SKU');
    let parsed;
    try{parsed=parsePddLink(candidate.checkoutUrl);}catch{throw error('INVALID_QUOTE_CANDIDATE','缺少可核对的官方完整SKU结算链接');}
    const expected={goodsId:candidate.goodsId,skuId:candidate.skuId,goodsNumber:'1',groupId:parsed.groupId};
    if(!parsed.groupId||!quoteIdentity(parsed.sourceUrl,expected)||(candidate.goodsNumber!=null&&String(candidate.goodsNumber)!=='1')||(candidate.groupId!=null&&String(candidate.groupId)!==parsed.groupId))throw error('INVALID_QUOTE_CANDIDATE','结算链接、商品、SKU、拼团或单件数量不一致，未打开报价页面');
    return {expected,url:parsed.sourceUrl};
  };
  const refreshPddActualPrice = async (payload,requestId) => {
    const candidate=payload.candidate,{expected,url}=quoteCandidate(candidate);
    const coupon=couponPrice(candidate);
    if(coupon&&/^\d+(?:\.\d{1,2})?$/.test(coupon.value)){
      const [whole,fraction='']=coupon.value.split('.');expected.favoritesCoupon={amountFen:(BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'))).toString(),goodsId:expected.goodsId,skuId:expected.skuId,goodsNumber:'1',sourceUrl:coupon.source.sourceUrl,capturedAt:coupon.source.capturedAt};
    }
    let context={quoteUrl:url,expected,requestId};
    const terminal=(status,message,reason,extra={})=>({status,...context,message,reason,...extra});
    const superseded=()=>requestId!==latestQuoteRequestId;
    const supersededResult=()=>terminal('superseded','已有更新的SKU报价读取请求，本次读取已停止','newer_quote_request');
    if(superseded())return supersededResult();
    const sourceTabId=payload.sourceTabId??candidate.sourceTabId;
    let workspaceTab=payload.workspaceTab===true?await ownedPddTab():null;
    if(workspaceTab&&sourceTabId!=null&&sourceTabId!==workspaceTab.id)throw error('PDD_QUOTE_SOURCE_MISMATCH','当前SKU不是由本次官方标签页同步，请先同步收藏');
    if(sourceTabId!=null&&!workspaceTab){
      if(payload.sourceTabId!=null&&candidate.sourceTabId!=null&&payload.sourceTabId!==candidate.sourceTabId)throw error('PDD_QUOTE_SOURCE_MISMATCH','所选SKU不属于当前商品来源标签页');
      const source=await ensureTab(sourceTabId,['pdd','pdd_favorites','pdd_login','pdd_account']);
      if(classifyTab(source.url)==='pdd'){
        let parsed;try{parsed=parsePddLink(source.url);}catch{throw error('PDD_QUOTE_SOURCE_MISMATCH','商品来源地址无法核对，请重新读取');}
        if(parsed.goodsId!==expected.goodsId)throw error('PDD_QUOTE_SOURCE_MISMATCH','商品来源页面已经切换，请重新选择SKU');
      }
    }
    // A failed refresh must not let the next favorites heartbeat restore a
    // previously accepted (possibly pre-coupon) quote for this same source.
    const invalidation=catalogQueue.then(async()=>{
      if(superseded())return;
      const {pddCatalog}=await api.storage.local.get('pddCatalog');
      if(superseded()||pddCatalog?.mode!=='official'||!Array.isArray(pddCatalog.skus))return;
      let changed=false;
      const skus=pddCatalog.skus.map(s=>{
        if(s.goodsId!==expected.goodsId||s.skuId!==expected.skuId||s.sourceTabId!==sourceTabId||!['actualPayPrice','actualPayPriceUnit','actualPayPriceSource'].some(k=>Object.hasOwn(s,k)))return s;
        try{if(parsePddLink(s.checkoutUrl).groupId!==expected.groupId)return s;}catch{return s;}
        const next={...s};for(const k of ['actualPayPrice','actualPayPriceUnit','actualPayPriceSource'])delete next[k];changed=true;return next;
      });
      if(changed&&!superseded())await api.storage.local.set({pddCatalog:{...pddCatalog,skus}});
    });catalogQueue=invalidation.catch(()=>{});await invalidation;
    const {pddQuoteContext,pddContext,pddQuotePreview}=await api.storage.local.get(['pddQuoteContext','pddContext','pddQuotePreview']);
    if(superseded())return supersededResult();
    let tab=null;
    if(pddQuotePreview?.owned===true&&Number.isInteger(pddQuotePreview.tabId)&&pddQuotePreview.tabId!==sourceTabId){
      try{const preview=await api.tabs.get(pddQuotePreview.tabId);if(quoteIdentity(preview.url,expected))tab=preview;}catch{/* Closed or independently navigated previews are not repurposed. */}
    }
    if(!tab&&workspaceTab)tab=workspaceTab.url===url?workspaceTab:await api.tabs.update(workspaceTab.id,{url,active:false});
    if(!tab&&!workspaceTab&&pddQuoteContext?.owned===true&&Number.isInteger(pddQuoteContext.tabId)&&pddQuoteContext.tabId!==sourceTabId&&pddQuoteContext.tabId!==pddContext?.tabId){
      try{
        const previous=await api.tabs.get(pddQuoteContext.tabId),u=new URL(previous.url);
        if(superseded())return supersededResult();
        if(u.origin==='https://mobile.yangkeduo.com'&&(u.pathname==='/order_checkout.html'||classifyPddUrl(previous.url)==='login'))tab=previous.url===url?previous:await api.tabs.update(previous.id,{url,active:false});
      }catch{/* Do not repurpose a closed or independently navigated user tab. */}
    }
    if(superseded())return supersededResult();
    if(!tab)tab=await api.tabs.create({url,active:false});
    await api.storage.local.set({pddQuoteContext:{owned:true,tabId:tab.id,url,goodsId:expected.goodsId,skuId:expected.skuId,goodsNumber:'1',openedAt:new Date().toISOString()}});
    context={...context,quoteTabId:tab.id};
    const attempts=Number.isInteger(quoteAttempts)?Math.max(1,Math.min(quoteAttempts,16)):16;
    let lastReaderMessage='',lastReaderReason='';
    for(let attempt=0;attempt<attempts;attempt++){
      if(superseded())return supersededResult();
      if(attempt)await quoteWait();
      if(superseded())return supersededResult();
      try{tab=await api.tabs.get(tab.id);}catch{return terminal('needs_user','报价标签页已关闭，请重新读取所选SKU报价','quote_tab_closed');}
      if(superseded())return supersededResult();
      // During navigation Chrome can still expose the previous committed URL.
      if(tab.status==='loading')continue;
      if(!quoteIdentity(tab.url,expected)){
        const kind=classifyPddUrl(tab.url);
        return terminal('needs_user',kind==='login'?'请在拼多多官方标签页完成登录，再重新读取实际应付报价':'报价页面已跳转，请在官方标签页核对登录或验证提示后重新读取','navigation_or_verification',{quoteUrl:tab.url});
      }
      let result;
      try{
        const results=await api.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:readPddCheckoutQuotePage,args:[expected]});
        result=results?.[0]?.result;
      }catch(cause){
        if(superseded())return supersededResult();
        try{const current=await api.tabs.get(tab.id);if(!quoteIdentity(current.url,expected))return terminal('needs_user','报价页面已跳转，请先在官方标签页核对登录或验证提示','navigation_or_verification',{quoteUrl:current.url});}catch{return terminal('needs_user','报价标签页已关闭，请重新读取','quote_tab_closed');}
        if(attempt===attempts-1)return terminal('not_ready','报价页面尚未可读取，请等待加载后重试','reader_unavailable');
        continue;
      }
      if(superseded())return supersededResult();
      let current;try{current=await api.tabs.get(tab.id);}catch{return terminal('needs_user','报价标签页已关闭，请重新读取','quote_tab_closed');}
      if(superseded())return supersededResult();
      if(current.status==='loading')continue;
      if(!quoteIdentity(current.url,expected))return terminal('needs_user','报价页面在读取期间发生跳转，请先核对官方标签页','navigation_or_verification',{quoteUrl:current.url});
      if(current.url!==tab.url||current.status==='loading')continue;
      if(!result||result.status==='not_ready'){lastReaderMessage=result?.message||'';lastReaderReason=result?.reason||'';continue;}
      if(result.status!=='read')return terminal(result.status==='needs_user'?'needs_user':'unsupported',result.message||'当前结算页没有可安全读取的所选SKU单件应付报价',result.reason||result.status,{warnings:result.warnings||[]});
      // The reader must independently prove one SKU and quantity one. URL
      // parameters alone cannot turn a cart/order total into a unit quote.
      const quote=result.quote||result,source=quote.actualPayPriceSource;
      const price=quote.actualPayPrice,unit=quote.actualPayPriceUnit;
      if(quote.goodsId!==expected.goodsId||quote.skuId!==expected.skuId||quote.goodsNumber!=='1'||typeof price!=='string'||price.length>80||!/^\d+(?:\.\d+)?$/.test(price)||!/[1-9]/.test(price)||!['fen','yuan'].includes(unit)||!source||source.sourceUrl!==current.url){
        return terminal('unsupported','结算页未提供完整一致的单SKU、单件和未提交报价证据，未更新实际价格','quote_evidence_mismatch');
      }
      const verified=validateCheckoutPriceSource({...candidate,...quote});
      if(!verified.valid)return terminal('unsupported',verified.message,'quote_evidence_mismatch');
      if(checkoutCouponConflict({...candidate,...quote}))return terminal('needs_user','当前结算商品金额高于收藏页同规格的券后价，优惠可能尚未领取、生效或条件不同。请打开官网核对优惠后重新读取；本次未用较高价格计算采购价','coupon_not_applied');
      const capturedAt=source.capturedAt;
      const patch={actualPayPrice:price,actualPayPriceUnit:unit,actualPayPriceSource:{...source,sourceTabId:current.id,readAt:new Date().toISOString()}};
      const refreshed={...candidate,...patch};
      const work=catalogQueue.then(async()=>{
        if(superseded())return supersededResult();
        const {pddCatalog,pddDiscovery}=await api.storage.local.get(['pddCatalog','pddDiscovery']);
        if(superseded())return supersededResult();
        let catalog=pddCatalog,catalogUpdated=false;
        if(catalog?.mode==='official'&&Array.isArray(catalog.skus)&&catalog.skus.some(s=>s.goodsId===expected.goodsId&&s.skuId===expected.skuId)){
          catalog={...catalog,skus:catalog.skus.map(s=>s.goodsId===expected.goodsId&&s.skuId===expected.skuId?{...s,...patch}:s),actualPriceUpdatedAt:capturedAt};
          await api.storage.local.set({pddCatalog:catalog});catalogUpdated=true;
        }
        // Keep the registered click source in step with its independently verified quote.
        if(pddDiscovery&&pddDiscovery.tabId===sourceTabId&&pddDiscovery.skus?.some(s=>s.goodsId===expected.goodsId&&s.skuId===expected.skuId)){
          await api.storage.local.set({pddDiscovery:{...pddDiscovery,skus:pddDiscovery.skus.map(s=>s.goodsId===expected.goodsId&&s.skuId===expected.skuId?{...s,...patch}:s)}});
        }
        return terminal('read','已读取所选SKU当前单件应付报价；仅查看未提交结算页，不代表已付款','checkout_payable_unit_quote',{candidate:refreshed,quote:patch,catalog:catalog||null,catalogUpdated,quoteUrl:current.url});
      });catalogQueue=work.catch(()=>{});return work;
    }
    return superseded()?supersededResult():terminal('not_ready',lastReaderMessage||'报价页面仍在加载或尚无完整单件报价，请等待后重试',lastReaderReason||'quote_not_ready');
  };
  const inspectDiscoveryTarget=async tabId=>{const tab=await ensureTab(tabId,['qnh','qnh_reference','demo']);let data;try{data=await send(tabId,{type:'QNH_INSPECT_EDITOR'});}catch(e){if(!['NO_EDITOR','EDITOR_NOT_OPENED'].includes(e.code))throw e;data=await send(tabId,{type:'QNH_PLAN_NEW_FORM_COMPLETION',ratioQnh:''});}return stampSnapshot(data.snapshot,await confirmReturnedTab(tab));};
  const reference=async()=>({status:'disabled',comparisonEnabled:false});
  const checkProcurement=async(snapshot,candidate,{ratioPdd='1',ratioQnh,purchasePriceDecimals='2',requireRegistered=false}={})=>{
    const profile=buildProductSearchProfile(snapshot),{pddDiscovery}=await api.storage.local.get('pddDiscovery');
    const registered=pddDiscovery?.targetIdentity===targetIdentity(snapshot)&&pddDiscovery.profile?.profileKey===profile.profileKey&&pddDiscovery.skus?.find(s=>s.goodsId===candidate.goodsId&&s.skuId===candidate.skuId);
    if(requireRegistered&&(!registered||candidate.recommendationTarget!==pddDiscovery.targetIdentity||candidate.recommendationRequestId!==pddDiscovery.requestId))throw error('STALE_RECOMMENDATION','推荐已变化，请重新选择当前商品的推荐');
    const referenceCost={status:'disabled',comparisonEnabled:false};
    const percent=registered&&['0','5','10'].includes(String(pddDiscovery.pricePolicy?.maxIncreasePercent))?String(pddDiscovery.pricePolicy.maxIncreasePercent):'10';
    const cost=evaluateProcurementPrice({candidate,reference:referenceCost,ratioPdd,ratioQnh:ratioQnh??registered?.matching?.ratioQnh,purchasePriceDecimals,profile,maxIncreasePercent:percent,compareReference:false});
    if(cost.status!=='eligible')throw Object.assign(error(cost.status==='over_limit'?'PROCUREMENT_OVER_LIMIT':'PROCUREMENT_PRICE_UNCONFIRMED',cost.reason+(cost.maxAllowedYuan?'；最高 ¥'+cost.maxAllowedYuan+'/'+profile.unit:'')),{details:{cost,referenceCost}});
    return {status:'eligible',cost,referenceCost,pricePolicy:{comparisonEnabled:false}};
  };
  const addCartonUnitFromPage=createCartonUnitRuntime({api});
  const discovery=createProductDiscoveryRuntime({api,ownedTab:ownedPddTab,runOfficial:withOfficialOperation,reference,
    quote:async(candidate,{requestId,isCurrent})=>{if(!isCurrent())return {status:'superseded'};latestQuoteRequestId=requestId;return refreshPddActualPrice({candidate,sourceTabId:candidate.sourceTabId,workspaceTab:true},requestId);},
    cancelQuote:()=>{latestQuoteRequestId='cancel-discovery-'+Date.now();},inspect:inspectDiscoveryTarget,
    commit:(result,tab)=>{const work=catalogQueue.then(async()=>{const {pddCatalog}=await api.storage.local.get('pddCatalog');const catalog=mergePddCatalog(pddCatalog,result,tab);await api.storage.local.set({pddCatalog:catalog});return catalog;});catalogQueue=work.catch(()=>{});return work;}
  });
  return async function route(message, sender) {
    if(message?.type==='QNH_ADD_CARTON_UNIT')return addCartonUnitFromPage(message.payload,sender);
    if(message?.type==='QNH_REFRESH_CARTON_FORM')return addCartonUnitFromPage.refresh(message.payload,sender);
    let senderIsExtensionPage = false;
    try {
      const base = new URL(api.runtime.getURL(''));
      const origin = new URL(sender?.url || '');
      senderIsExtensionPage = sender?.id === api.runtime.id && origin.protocol === base.protocol && origin.host === base.host && !origin.username && !origin.password;
    } catch { /* An extension page URL and runtime identity are both required. */ }
    if (!senderIsExtensionPage) throw error('INVALID_SENDER', '仅允许插件自身页面发起维护操作');
    if (!message || typeof message.type !== 'string') throw error('INVALID_MESSAGE', '无效操作');
    const payload = message.payload || {};
    if(message.type==='SEARCH_PDD_PRODUCTS')return discovery.search(payload);
    if(message.type==='CANCEL_PDD_PRODUCT_SEARCH')return discovery.cancel(payload);
    if(message.type==='GET_PDD_DISCOVERY_PROGRESS')return discovery.progress(payload);
    if(message.type==='CHECK_PROCUREMENT_PRICE'){
      const snapshot=await inspectDiscoveryTarget(payload.tabId);
      if(targetIdentity(snapshot)!==payload.targetIdentity)throw error('TARGET_CHANGED','当前牵牛花商品已变化');
      return checkProcurement(snapshot,payload.candidate,{ratioPdd:payload.ratioPdd||'1',ratioQnh:payload.ratioQnh,purchasePriceDecimals:snapshot.nativeEditor?.purchasePriceDecimals||'2',requireRegistered:!!payload.candidate?.recommendationTarget});
    }
    if(message.type==='FAVORITE_PDD_RECOMMENDATION')return discovery.favorite(payload);
    if (message.type === 'DISCOVER_TABS') {
      const tabs = await api.tabs.query({});
      return tabs.filter(tab => classifyTab(tab.url)).map(tab => ({id:tab.id,title:tab.title || '',kind:classifyTab(tab.url),active:!!tab.active}));
    }
    if (message.type === 'OPEN_DEMO') return api.tabs.create({url:'http://127.0.0.1:8765/demo/index.html'});
    if (message.type === 'OPEN_QNH') return api.tabs.create({url:'https://qnh.meituan.com/home.html#/pms/online-purchase-center/list'});
    if(message.type==='OPEN_PDD_LOGIN')return openPdd(PDD_OFFICIAL_ROUTES.login,{resetCatalog:true});
    if(message.type==='PDD_WORKSPACE_LOGIN_LOADED'){
      const {pddTabWorkspace}=await api.storage.local.get('pddTabWorkspace');
      if(!pddTabWorkspace?.awaitingLogin||pddTabWorkspace.tabId!==payload.tabId)return;
      const tab=await ownedPddTab();
      if(tab.id!==payload.tabId||tab.status!=='complete')return;
      const kind=classifyTab(tab.url);
      if(kind==='pdd_login'){
        await api.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:showPddQrLogin});
      }else if(kind==='pdd_account'||kind==='pdd_favorites'){
        await api.storage.local.set({pddTabWorkspace:{...pddTabWorkspace,awaitingLogin:false}});
        if(kind==='pdd_account')await api.tabs.update(tab.id,{url:PDD_OFFICIAL_ROUTES.favorites});
      }
      return;
    }
    if(message.type==='START_PDD_TAB_WORKSPACE'){
      let tab;try{tab=await ownedPddTab();}catch{}
      const saved=(await api.storage.local.get('pddTabWorkspace')).pddTabWorkspace;
      const url=payload.login===true||!tab&&payload.preferLogin===true?PDD_OFFICIAL_ROUTES.login+'?from='+encodeURIComponent(PDD_OFFICIAL_ROUTES.favorites):PDD_OFFICIAL_ROUTES.favorites;
      if(!tab&&payload.reuseOnly===true)throw error('NO_PDD_WORKSPACE','请点击「官网标签页登录」连接拼多多');
      const created=!tab;
      if(created)tab=await api.tabs.create({url,active:payload.active===true});
      else if(payload.login===true)tab=await api.tabs.update(tab.id,{url,active:payload.active===true});
      else if(payload.active===true)tab=await api.tabs.update(tab.id,{active:true});
      const context={owned:true,tabId:tab.id,windowId:tab.windowId||null,url:tab.url,awaitingLogin:payload.login===true||payload.resumeLogin===true||(saved?.tabId===tab.id&&saved.awaitingLogin===true)};
      if(payload.login===true||(saved&&saved.tabId!==tab.id)){
        const {pddFavoritesLoad}=await api.storage.local.get('pddFavoritesLoad');
        await api.storage.local.set({pddFavoritesLoad:null,pddWorkspaceDetail:null,...(payload.login===true?{pddCatalog:{products:[],skus:[]}}:{})});
        await closeFavoritesScanner(pddFavoritesLoad);
      }
      await api.storage.local.set({pddTabWorkspace:context,pddContext:context});
      if(context.awaitingLogin&&tab.status==='complete')await route({type:'PDD_WORKSPACE_LOGIN_LOADED',payload:{tabId:tab.id}},sender);
      return {...context,created};
    }
    if(message.type==='NAVIGATE_PDD_TAB_WORKSPACE'){
      if(tabQuoteBusy||officialWork)throw error('QUOTE_IN_PROGRESS','正在处理所选商品，请稍候再打开页面');
      if(payload.goodsId!=null){
        if(typeof payload.goodsId!=='string'||!/^[1-9]\d*$/.test(payload.goodsId))throw error('INVALID_PRODUCT','商品编号无效');
        const tab=await ownedPddTab().catch(()=>null);
        const {pddWorkspaceDetail:saved}=await api.storage.local.get('pddWorkspaceDetail');
        const url='https://mobile.yangkeduo.com/goods.html?goods_id='+payload.goodsId;
        let detail;
        if(saved?.goodsId===payload.goodsId){
          const current=await api.tabs.get(saved.tabId).catch(()=>null);
          if(current?.url===url||current?.pendingUrl===url)detail=await api.tabs.update(current.id,{active:true});
        }
        if(!detail)detail=await api.tabs.create({url,active:true});
        await api.storage.local.set({pddWorkspaceDetail:{ownerTabId:tab?.id,tabId:detail.id,goodsId:payload.goodsId}});
        if(payload.readDetail!==true)return {tabId:tab?.id,detailTabId:detail.id,url};
        const loaded=await waitForPddTabLoad(detail.id);
        if(classifyTab(loaded.url)!=='pdd'||new URL(loaded.url).searchParams.get('goods_id')!==payload.goodsId)
          return {status:'needs_user',message:'商品详情已跳转，请在拼多多官网核对登录或验证提示。'};
        const result=await readPdd(detail.id,{catalogTab:tab});
        return {...result,message:result.status==='read'?'已读取当前商品详情。':result.message||'详情页没有可用规格，请在官网核对。'};
      }
      const tab=await ownedPddTab();
      const url=PDD_OFFICIAL_ROUTES.favorites;
      if(classifyTab(tab.url)==='pdd_favorites')await api.tabs.update(tab.id,{active:true});
      else await api.tabs.update(tab.id,{url,active:true});
      await api.storage.local.set({pddWorkspaceDetail:null});
      return {tabId:tab.id,url};
    }
    if(message.type==='FOCUS_PDD_TAB_WORKSPACE'){const tab=await ownedPddTab();await api.tabs.update(tab.id,{active:true});return {tabId:tab.id};}
    if(message.type==='SHOW_PDD_CHECKOUT_QUOTE'){
      const {expected,url}=quoteCandidate(payload.candidate),{pddQuotePreview}=await api.storage.local.get('pddQuotePreview');let tab=null;
      if(pddQuotePreview?.owned===true&&Number.isInteger(pddQuotePreview.tabId)&&pddQuotePreview.tabId!==payload.candidate.sourceTabId){
        try{const current=await api.tabs.get(pddQuotePreview.tabId);if(quoteIdentity(current.url,expected))tab=await api.tabs.update(current.id,{active:true});}catch{}
      }
      if(!tab)tab=await api.tabs.create({url,active:true});
      await api.storage.local.set({pddQuotePreview:{owned:true,tabId:tab.id,url,goodsId:expected.goodsId,skuId:expected.skuId}});
      return {tabId:tab.id,url};
    }
    if(message.type==='SYNC_PDD_TAB_WORKSPACE'){
      if(payload.stopFavoritesLoad===true){
        return withOfficialOperation('favorites',async()=>{
          const {pddFavoritesLoad:current,pddCatalog,pddTabWorkspace}=await api.storage.local.get(['pddFavoritesLoad','pddCatalog','pddTabWorkspace']);
          if(!current||current.tabId!==pddTabWorkspace?.tabId)return {status:'stopped'};
          const tab={id:current.tabId};
          if(current.state!=='running')return favoritesSnapshot(tab,current,pddCatalog);
          const stopped={...current,state:'stopped',reason:'已停止自动加载，保留已读取商品'};
          await api.storage.local.set({pddFavoritesLoad:stopped});
          await closeFavoritesScanner(stopped);
          return favoritesSnapshot(tab,stopped,pddCatalog);
        });
      }
      const tab=await ownedPddTab();
      const {pddFavoritesLoad:storedJob,pddCatalog}=await api.storage.local.get(['pddFavoritesLoad','pddCatalog']);
      let job=storedJob?.tabId===tab.id?storedJob:null;
      if(officialWork&&officialWork!=='quote')return {status:'working',message:'正在后台读取拼多多商品…'};
      if(tabQuoteBusy)return {status:'quoting',message:'正在读取所选SKU实价…'};

      const kind=classifyTab(tab.url);
      if(tab.status==='loading'&&payload.refreshFavorites===true)return {status:'loading',tabId:tab.id,message:'官方页面正在加载…'};
      if(payload.refreshFavorites===true&&kind!=='pdd_login'){
        return withOfficialOperation('favorites',async()=>{
          const owner=await ownedPddTab();
          if(owner.id!==tab.id)throw error('NAVIGATION_CHANGED','拼多多标签页连接已切换，请重新同步');
          const {pddFavoritesLoad:previous}=await api.storage.local.get('pddFavoritesLoad');
          if(previous?.tabId===tab.id&&previous.state==='running'&&previous.scanTabId)return {...favoritesSnapshot(tab,previous,pddCatalog),refreshStarted:true};
          await closeFavoritesScanner(previous);
          const next=startFavoritesLoad(tab.id);
          const scanUrl=new URL(PDD_OFFICIAL_ROUTES.favorites);
          if(kind==='pdd_favorites')scanUrl.search=new URL(tab.url).search;
          scanUrl.searchParams.set('qnh_favorites_sync',next.id);
          const reuseWorkspace=payload.scanWorkspaceTab===true&&kind==='pdd_favorites'&&!owner.active;
          const scanner=reuseWorkspace?owner:await api.tabs.create({url:scanUrl.href,active:false,...(tab.windowId?{windowId:tab.windowId}:{})});
          const retainedIds=previous?.tabId===tab.id?(previous.productsComplete?previous.seen:[...(previous.retainedIds||[]),...previous.seen]):[];
          job={...next,scanTabId:scanner.id,scanUrl:reuseWorkspace?scanner.url:scanUrl.href,reuseWorkspace,retainedIds:[...new Set(retainedIds)]};
          await api.storage.local.set({pddFavoritesLoad:job});
          return {status:'loading',refreshStarted:true,tabId:tab.id,favoritesLoad:favoritesLoadProgress(job),message:'正在后台同步收藏…'};
        });
      }

      if(job?.state==='running'&&!job.scanTabId){
        // A job saved by an earlier release used the visible favorites tab.
        job={...job,state:'stopped',reason:'旧版收藏加载已停止，可点击立即同步在后台继续'};
        await api.storage.local.set({pddFavoritesLoad:job});
      }
      if(payload.advanceFavorites===true&&job?.state!=='running')return favoritesSnapshot(tab,job,pddCatalog);
      if(job?.state==='running'){
        return withOfficialOperation('favorites',async()=>{
          const latest=(await api.storage.local.get('pddFavoritesLoad')).pddFavoritesLoad;
          if(latest?.id!==job.id||latest.state!=='running')return favoritesSnapshot(tab,latest,pddCatalog);
          job=latest;
          const getScanner=async()=>{
            const scanner=await api.tabs.get(job.scanTabId);
            if((scanner.id===tab.id&&!job.reuseWorkspace)||scanner.active)throw error('NAVIGATION_CHANGED','后台同步标签页已打开，已停止自动滚动');
            if(scanner.status!=='loading'&&scanner.url!==job.scanUrl)throw error('NAVIGATION_CHANGED','后台收藏页发生跳转，请在官网处理登录或验证后重新同步');
            return scanner;
          };
          const observe=async options=>{
            const scanner=await getScanner();
            if(scanner.url!==job.scanUrl||scanner.status==='loading')throw error('NAVIGATION_CHANGED','后台收藏页已切换');
            const results=await api.scripting.executeScript({target:{tabId:scanner.id},world:'MAIN',func:inspectPddFavoritesScroll,args:[options]});
            await getScanner();
            return results[0]?.result||{status:'not_ready',message:'收藏滚动区域没有响应'};
          };
          try{
            const scanner=await getScanner();
            if(Date.now()-job.startedAt>=600000)throw error('PDD_SYNC_TIMEOUT','后台收藏加载超时');
            if(scanner.status==='loading')return {...favoritesSnapshot(tab,job,pddCatalog),status:'loading',message:'后台收藏页正在加载…'};
            const result=await readPdd(scanner.id,{fullFavorites:true,catalogTab:tab,scanJobId:job.id});
            let live=(await api.storage.local.get('pddFavoritesLoad')).pddFavoritesLoad;
            if(live?.id!==job.id||live.state!=='running')return favoritesSnapshot(tab,live,result.catalog);
            const observation=await observe({advance:true,previous:job.metrics});
            job=advanceFavoritesLoad(job,{products:result.products||[],observation,truncated:result.coverage?.truncated===true||new Set([...job.seen,...(result.products||[]).map(p=>p.goodsId)]).size>(result.catalog?.products?.length||0)});
            live=(await api.storage.local.get('pddFavoritesLoad')).pddFavoritesLoad;
            if(live?.id===job.id&&live.state==='running')await api.storage.local.set({pddFavoritesLoad:job});else job=live;
            if(job?.state!=='running')await closeFavoritesScanner(job);
            return favoritesSnapshot(tab,job,result.catalog);
          }catch(cause){
            const live=(await api.storage.local.get('pddFavoritesLoad')).pddFavoritesLoad;
            if(live?.id===job.id&&live.state==='running'){
              job={...live,state:'paused',reason:(cause.message||'后台同步失败')+'，请点击立即同步重试'};
              await api.storage.local.set({pddFavoritesLoad:job});
              await closeFavoritesScanner(job);
            }else job=live;
            return favoritesSnapshot(tab,job,(await api.storage.local.get('pddCatalog')).pddCatalog);
          }
        });
      }

      return {status:'login_required',message:'请先在拼多多官网登录，再点击「立即同步」。'};
    }
    if(message.type==='READ_PDD_FAVORITE_SPECS'){
      if(officialWork)return {status:'working',message:'正在处理官网检索或实价，请稍后读取规格'};
      return withOfficialOperation('spec',async()=>{
      if(tabQuoteBusy)return {status:'quoting',message:'正在读取实价，规格稍后补齐'};
      const tab=await ownedPddTab(),view=classifyTab(tab.url);if(!['pdd','pdd_favorites'].includes(view))return {status:'not_ready',message:'请在官网收藏或详情页读取规格'};if(view==='pdd'&&new URL(tab.url).searchParams.get('goods_id')!==payload.goodsId)return {status:'not_ready',message:'当前详情不属于所选商品'};
      if(typeof payload.goodsId!=='string'||!/^[1-9]\d*$/.test(payload.goodsId))throw error('INVALID_PRODUCT','商品编号无效');
      await catalogQueue;const {pddCatalog}=await api.storage.local.get('pddCatalog');
      if(!pddCatalog?.products?.some(p=>p.goodsId===payload.goodsId&&(p.sourceTabId===tab.id||pddCatalog.mode==='official'&&p.favoritesObservedAt)))throw error('PDD_ID_MISMATCH','仅可补齐当前已加载收藏商品');
      await ensureMobileSpecReader(api,tab.id);
      const result=await resolvePddSpecifications({api,ownedTab:ownedPddTab,goodsId:payload.goodsId,allowNavigation:false,singleRequest:true});
      if(result.status!=='read')return result;
      const current=await ownedPddTab();if(current.id!==tab.id)return {status:'not_ready',message:'官网连接已变化，本次规格未入库'};
      const work=catalogQueue.then(async()=>{const {pddCatalog:previous}=await api.storage.local.get('pddCatalog');const catalog=mergePddCatalog(previous,result,{id:tab.id,url:result.sourceUrl});await api.storage.local.set({pddCatalog:catalog});return {...result,catalog,message:'已读取该商品的规格，请选择所需规格代填。'};});catalogQueue=work.catch(()=>{});return work;
      });
    }
    if(message.type==='CANCEL_PDD_TAB_QUOTE'){latestQuoteRequestId='';return {cancelled:true};}
    if(message.type==='OPEN_PDD_FAVORITES')return openPdd(PDD_OFFICIAL_ROUTES.favorites);
    if(message.type==='OPEN_PDD_DEMO')return openPdd('http://127.0.0.1:8765/demo/pdd-favorites.html',{newTab:true});
    if(message.type==='OPEN_PDD_PRODUCT'){
      if(typeof payload.goodsId!=='string'||!/^[1-9]\d*$/.test(payload.goodsId))throw error('INVALID_PRODUCT','请选择完整的商品编号');
      let url=`https://mobile.yangkeduo.com/goods.html?goods_id=${payload.goodsId}`;
      if(payload.demoDetailUrl){const u=new URL(payload.demoDetailUrl),ids=u.searchParams.getAll('goods_id');if(classifyTab(u.href)!=='pdd_demo_product'||new Set(ids).size!==1||ids[0]!==payload.goodsId)throw error('INVALID_PRODUCT','演示商品详情地址不匹配');url=u.href;}
      return openPdd(url);
    }
    if(message.type==='READ_PDD_CURRENT'){
      const {pddContext}=await api.storage.local.get('pddContext');
      return readPdd(payload.tabId ?? pddContext?.tabId);
    }
    if(message.type==='REFRESH_PDD_ACTUAL_PRICE'){
      quoteCandidate(payload.candidate);
      const requestId=payload.requestId??crypto.randomUUID();
      if(typeof requestId!=='string'||!requestId.trim()||requestId.length>200)throw error('INVALID_QUOTE_REQUEST','报价读取标识无效，请重新选择SKU');
      latestQuoteRequestId=requestId;
      const work=quoteQueue.then(()=>withOfficialOperation('quote',async()=>{if(payload.workspaceTab!==true)return refreshPddActualPrice(payload,requestId);tabQuoteBusy=true;let result;try{result=await refreshPddActualPrice(payload,requestId);return result;}finally{if(result?.status==='read'||result?.status==='superseded'){try{const tab=await ownedPddTab();if(quoteIdentity(tab.url,quoteCandidate(payload.candidate).expected))await api.tabs.update(tab.id,{url:PDD_OFFICIAL_ROUTES.favorites,active:false});}catch{}}tabQuoteBusy=false;}}));quoteQueue=work.catch(()=>{});return work;
    }
    if(message.type==='GET_PDD_CATALOG'){const work=catalogQueue.then(async()=>{const {pddCatalog,pddContext}=await api.storage.local.get(['pddCatalog','pddContext']);const catalog=repairPddCatalogLinks(pddCatalog);if(pddCatalog&&JSON.stringify(catalog)!==JSON.stringify(pddCatalog))await api.storage.local.set({pddCatalog:catalog});return {catalog,context:pddContext||null};});catalogQueue=work.catch(()=>{});return work;}
    if(message.type==='CLEAR_PDD_CATALOG'){await catalogQueue;const catalog={products:[],skus:[]};const {pddFavoritesLoad}=await api.storage.local.get('pddFavoritesLoad');await api.storage.local.set({pddCatalog:catalog,pddFavoritesLoad:null});await closeFavoritesScanner(pddFavoritesLoad);return {catalog};}
    if(message.type==='SEARCH_UPC'){
      const tab=await ensureTab(payload.tabId,['qnh','qnh_reference','demo']);
      if(typeof payload.upc!=='string'||!/^\d{8,14}$/.test(payload.upc))throw error('INVALID_UPC','请输入完整UPC，保留前导零');
      const result=await send(tab.id,{type:'QNH_SEARCH_UPC',upc:payload.upc});
      return stampResult(result,await confirmReturnedTab(tab));
    }
    if(message.type==='PLAN_NEW_FORM_COMPLETION'){
      const tab=await ensureTab(payload.tabId,['qnh','qnh_reference','demo']);
      const result=await send(tab.id,{type:'QNH_PLAN_NEW_FORM_COMPLETION',rowRef:payload.rowRef,expectedFingerprint:payload.expectedFingerprint,ratioQnh:payload.ratioQnh,...(payload.preserveQuantity===true?{preserveQuantity:true}:{})});
      return stampResult(result,await confirmReturnedTab(tab));
    }
    if (message.type === 'READ_PDD') {
      await ensureTab(payload.tabId, ['pdd']);
      const results = await api.scripting.executeScript({target:{tabId:payload.tabId},world:'MAIN',func:readPddPage});
      if (!results[0]?.result) throw error('PDD_READ_FAILED', '商品页没有返回可读取的数据');
      return results[0].result;
    }
    if (message.type === 'READ_RELATIONS') {
      const tab=await ensureTab(payload.tabId, ['qnh','qnh_reference','demo']);
      const result=await send(payload.tabId,{type:'QNH_READ_PAGE'});
      return stampResult(result,await confirmReturnedTab(tab));
    }
    const forwards = {GET_RELATION:'QNH_GET_RELATION',OPEN_EDITOR:'QNH_OPEN_EDITOR',INSPECT_EDITOR:'QNH_INSPECT_EDITOR'};
    if (forwards[message.type]) {
      const tab=await ensureTab(payload.tabId, ['qnh','qnh_reference','demo']);
      const result=await send(payload.tabId,{type:forwards[message.type],rowRef:payload.rowRef,expectedFingerprint:payload.expectedFingerprint,...(message.type==='INSPECT_EDITOR'&&payload.newSelection===true?{newSelection:true}:{})});
      return stampResult(result,await confirmReturnedTab(tab));
    }
    if (message.type === 'FILL_EDITOR') {
      const tab=await ensureTab(payload.tabId,['qnh','qnh_reference','demo']);
      const before = payload.snapshot;
      if (!before?.rowRef || !before.fingerprint) throw error('NO_BASELINE','请重新读取并核对原关系');
      if (before.sourceTabId!==tab.id || before.sourceTabUrl!==tab.url) throw error('SOURCE_TAB_MISMATCH','关系快照不属于当前标签页或页面已导航，请重新读取');
      const current = await send(payload.tabId,{type:'QNH_GET_RELATION',rowRef:before.rowRef});
      const fresh = stampSnapshot(current.snapshot,tab);
      if (!fresh || fresh.fingerprint !== before.fingerprint || fresh.tenantId !== before.tenantId || fresh.relationId !== before.relationId) throw error('CONFLICT','关系在预览后发生变化，请重新读取并审核');
      const validation = validateDraft(fresh,payload.draft);
      if (!validation.canAssist) throw error('REVIEW_REQUIRED',[...validation.errors,...validation.assistErrors].join('；'));
      const prepared = await appendReceipt({state:'assisting',tabId:payload.tabId,tabUrl:tab.url,tenantId:fresh.tenantId,relationId:fresh.relationId,rowRef:fresh.rowRef,beforeSnapshot:fresh,expected:{goodsId:validation.parsed.goodsId,skuId:payload.draft.candidate?.skuId || validation.parsed.skuId,url:validation.checkoutUrl},message:'准备填写原生表单；尚未保存'});
      activeAssists.add(prepared.id);
      try {
        let filled;
        try {
          filled=await send(payload.tabId,{type:'QNH_FILL_EDITOR',rowRef:fresh.rowRef,expectedFingerprint:fresh.fingerprint,url:validation.checkoutUrl});
        } catch (cause) {
          await updateReceipt(prepared.id,{state:'assist_result_unknown',message:'辅助填写未确认，请检查原生表单；没有执行保存',errorCode:cause.code || 'UNKNOWN'});
          throw cause;
        }
        const receipt = await updateReceipt(prepared.id,{state:'waiting_native_save',message:'仅填入原生表单；尚未保存'});
        return {...filled,receipt};
      } finally {
        activeAssists.delete(prepared.id);
      }
    }
    if(message.type==='FILL_MAINTENANCE'){
      const tab=await ensureTab(payload.tabId,['qnh','qnh_reference','demo']),before=payload.snapshot;
      if(!before?.rowRef||!before.fingerprint)throw error('NO_BASELINE','请先读取当前网采关系编辑器');
      if(before.sourceTabId!==tab.id||before.sourceTabUrl!==tab.url)throw error('SOURCE_TAB_MISMATCH','关系快照不属于当前标签页，请重新同步编辑器');
      const lock=JSON.stringify([tab.id,before.tenantId,before.relationId||before.rowRef]);
      if(fillLocks.has(lock))throw error('FILL_IN_PROGRESS','这条关系正在填写，请勿重复操作');
      fillLocks.add(lock);
      try{
      await receiptQueue;
      const {receipts=[]}=await api.storage.local.get('receipts');
      const unresolvedList=receipts.filter(r=>r.mode==='six_fields'&&r.tabId===tab.id&&r.tenantId===before.tenantId&&(r.relationId?r.relationId===before.relationId:r.rowRef===before.rowRef)&&['assisting','assist_result_unknown','waiting_native_save','result_unknown','completion_partial'].includes(r.state));
      const unresolved=unresolvedList[0],replacing=unresolvedList.length===1&&unresolved?.id===payload.replaceReceiptId&&unresolved?.state==='waiting_native_save'&&unresolved?.afterSnapshot&&payload.draft?.selectionIntent?.mode==='sku_selection';
      const completion=payload.draft?.newCompletionConfirmed===true;
      const preserveQuantity=payload.draft?.selectionIntent?.quantitySource==='preserve';
      if(completion&&(before.routeMode!=='new'||before.relationId))throw error('WRONG_COMPLETION_MODE','新增表单补齐仅适用于当前单个新增表单');
      const current=await send(tab.id,completion?{type:'QNH_PLAN_NEW_FORM_COMPLETION',rowRef:before.rowRef,expectedFingerprint:before.fingerprint,ratioQnh:preserveQuantity?'':payload.draft.ratioQnh,...(preserveQuantity?{preserveQuantity:true}:{})}:{type:'QNH_GET_RELATION',rowRef:before.rowRef});
      const fresh=stampSnapshot(current.snapshot,await confirmReturnedTab(tab));
      if(!fresh||fresh.fingerprint!==before.fingerprint||fresh.tenantId!==before.tenantId||fresh.relationId!==before.relationId)throw error('CONFLICT','牵牛花表单已变化，请核对目标商品后重新选择SKU');
      const manualSelection=!completion&&payload.draft?.manualPurchasePrice===true&&payload.draft?.selectionIntent?.mode==='sku_selection';
      const verifiedReference=manualSelection&&classifyTab(tab.url)==='qnh_reference'&&fresh.routeMode==='edit'&&fresh.nativeEditor?.identityLevel==='reference_form'&&fresh.nativeEditor.canFill===true&&
        fresh.backendUpcSource==='native_product'&&!!fresh.backendUpc&&!!fresh.nativeEditor.bindingId&&!!fresh.nativeEditor.protectionFingerprint;
      const sameBinding=r=>targetIdentity(r.beforeSnapshot)===targetIdentity(fresh);
      const core=['channelName','url','channelSpec'];
      const knownCore=values=>values&&core.every(key=>String(values[key]??'')===String(fresh.nativeFields?.[key]??''));
      const canRenewReference=verifiedReference&&unresolvedList.every(r=>!activeAssists.has(r.id)&&sameBinding(r)&&
        (r.state==='waiting_native_save'||r.state==='assist_result_unknown'&&(knownCore(r.expected?.fields)||knownCore(r.beforeSnapshot?.nativeFields))));
      const renewedEdit=unresolvedList.length>0&&(canRenewReference||manualSelection&&
        classifyTab(tab.url)==='qnh'&&fresh.routeMode==='edit'&&/^[1-9]\d*$/.test(fresh.relationId||'')&&fresh.nativeEditor?.identityLevel==='relation_id'&&
        fresh.nativeEditor?.routeKey==='https://qnh.meituan.com/home.html#/pms/online-purchase-center/add-purchase-relation'&&fresh.nativeEditor.canFill===true&&
        fresh.backendUpcSource==='native_product'&&!!fresh.backendUpc&&!!fresh.nativeEditor.bindingId&&!!fresh.nativeEditor.protectionFingerprint&&
        unresolvedList.every(r=>!activeAssists.has(r.id)&&r.beforeSnapshot?.backendUpc===fresh.backendUpc&&r.writeMode!=='new_draft'&&r.writeMode!=='new_draft_completion'));
      const referenceDraft=verifiedReference&&!fresh.relationId&&(!fresh.supplier||core.every(key=>!fresh.nativeFields?.[key])||
        unresolvedList.some(r=>sameBinding(r)&&r.referenceDraft===true));
      if(unresolved&&!replacing&&!renewedEdit)throw error('PENDING_RECEIPT','这条关系已有待保存或待核对记录，请先核对实际结果');
      if(replacing&&!renewedEdit){
        const previous=unresolved.afterSnapshot,manual=payload.draft?.manualPurchasePrice===true&&unresolved.expected?.manualPurchasePrice===true,keys=['channelName','url','channelSpec',...(preserveQuantity?[]:['ratioPdd','ratioQnh']),...(manual?[]:['purchasePrice'])];
        const onlyEmployeeFields=manual&&targetIdentity(previous)===targetIdentity(fresh)&&previous.nativeEditor?.protectionFingerprint===fresh.nativeEditor?.protectionFingerprint&&keys.every(k=>String(previous.nativeFields?.[k]??'')===String(fresh.nativeFields?.[k]??''));
        if((previous.fingerprint!==fresh.fingerprint&&!onlyEmployeeFields)||previous.nativeEditor?.bindingId!==fresh.nativeEditor?.bindingId||keys.some(k=>String(previous.nativeFields?.[k]??'')!==String(fresh.nativeFields?.[k]??'')))throw error('DRAFT_CHANGED','上次代填后表单已被修改，请核对原生内容后再维护');
      }
      let reviewedDraft=payload.draft;
      if(completion){
        if(current.canApply!==true)throw error('REVIEW_REQUIRED',(current.reasons||['新增表单补齐计划未就绪']).join('；'));
        if(!current.completionPlan?.planFingerprint||current.completionPlan.planFingerprint!==payload.draft.completionPlan?.planFingerprint)throw error('COMPLETION_PLAN_CHANGED','供应商、门店或补齐规则已变化，请检查原生表单后重新选择SKU');
        reviewedDraft={...payload.draft,completionPlan:current.completionPlan,completionCanApply:true,completionReasons:current.reasons||[]};
      }
      const validation=validateMaintenanceDraft(fresh,reviewedDraft);
      if(!validation.canAssist)throw error('REVIEW_REQUIRED',[...validation.errors,...validation.assistErrors].join('；'));
      // Independently enforce the same actual unit cost just before the native write.
      let procurementPolicy;
      if(reviewedDraft.manualPurchasePrice!==true&&['qnh','qnh_reference'].includes(classifyTab(tab.url))&&enforceProcurementPolicy){
        procurementPolicy=await checkProcurement(fresh,reviewedDraft.candidate,{ratioPdd:reviewedDraft.ratioPdd,ratioQnh:reviewedDraft.ratioQnh,purchasePriceDecimals:String(fresh.nativeEditor?.purchasePriceDecimals??reviewedDraft.purchasePriceDecimals??'2'),requireRegistered:!!reviewedDraft.candidate?.recommendationTarget});
        if(!sameDecimal(validation.fields.purchasePrice,procurementPolicy.cost.unitCostDisplayYuan))throw error('PROCUREMENT_PRICE_MISMATCH','待填采购价与当前单件实付价换算结果不一致');
        const afterPriceCheck=await inspectDiscoveryTarget(tab.id);if(afterPriceCheck.fingerprint!==fresh.fingerprint||targetIdentity(afterPriceCheck)!==targetIdentity(fresh))throw error('CONFLICT','核价期间牵牛花表单已变化，未填写');
      }
      if(replacing&&!renewedEdit&&!preserveQuantity&&reviewedDraft.selectExistingCartonUnit!==true&&JSON.stringify(unresolved.expected.fields)===JSON.stringify(validation.fields))return {filled:true,unchanged:true,receipt:unresolved};
      const writeMode=validation.writeMode||'edit';
      const prepared=await appendReceipt({mode:'six_fields',writeMode,state:'assisting',...(referenceDraft?{referenceDraft:true}:{}),tabId:tab.id,tabUrl:tab.url,tenantId:fresh.tenantId,relationId:fresh.relationId,rowRef:fresh.rowRef,beforeSnapshot:fresh,...(procurementPolicy?{procurementPolicy}:{}),...(payload.draft.selectionIntent?{selectionIntent:payload.draft.selectionIntent}:{}),expected:{manualPurchasePrice:reviewedDraft.manualPurchasePrice===true,fields:validation.fields,...(preserveQuantity?{preserveQuantity:true}:{}),goodsId:validation.parsed?.goodsId,skuId:validation.parsed?.skuId,url:validation.fields.url,...(completion?{completionPlan:reviewedDraft.completionPlan}:{})},message:preserveQuantity?'准备填写商品信息':completion?'准备补齐当前新增表单及六项草稿；尚未原生提交':writeMode==='new_draft'?'准备填写当前新增表单草稿；尚未原生提交':'准备填写6项；尚未保存'});
      activeAssists.add(prepared.id);
      try{
        let filled;
        try{
          filled=await send(tab.id,completion?{type:'QNH_COMPLETE_NEW_FORM',rowRef:fresh.rowRef,expectedFingerprint:fresh.fingerprint,fields:validation.fields,...(preserveQuantity?{preserveQuantity:true}:{}),...(reviewedDraft.manualPurchasePrice===true?{manualPurchasePrice:true}:{}),completionPlan:reviewedDraft.completionPlan,newRelationConfirmed:true,newCompletionConfirmed:true}:{type:'QNH_FILL_MAINTENANCE',...(referenceDraft?{referenceDefaults:{draft:true,chooseSupplier:true}}:{}),rowRef:fresh.rowRef,expectedFingerprint:fresh.fingerprint,fields:validation.fields,...(preserveQuantity?{preserveQuantity:true}:{}),...(reviewedDraft.manualPurchasePrice===true?{manualPurchasePrice:true}:{}),...(writeMode==='new_draft'?{writeMode,newRelationConfirmed:payload.draft.newRelationConfirmed===true}:{})});
          if(completion&&(filled.filled!==true||filled.submitted!==false))throw Object.assign(error('COMPLETION_RESULT_UNKNOWN','新增补齐结果未得到完整确认，请检查原生表单后再继续'),{details:filled});
          if(!preserveQuantity&&reviewedDraft.selectExistingCartonUnit===true&&filled.filled===true&&['qnh','qnh_reference'].includes(classifyTab(tab.url))){
            const beforeUnit=filled.snapshot?stampSnapshot(filled.snapshot,tab):fresh;
            const matched=await existingCartonSelector({api,send,tab,snapshot:beforeUnit,candidate:reviewedDraft.candidate});
            filled.cartonSelection={status:matched.status,message:matched.message,...(matched.result?{unitCode:matched.result.unitCode,unitName:matched.result.unitName,quantity:matched.result.quantity,baseUnit:matched.result.baseUnit}:{})};
            if(matched.status==='selected'&&matched.snapshot){filled.cartonSelectionBeforeSnapshot=beforeUnit;filled.snapshot=matched.snapshot;}
          }
        }
        catch(cause){
          const details=cause.details&&typeof cause.details==='object'?cause.details:{},operations=Array.isArray(details.operations)?details.operations:[],changedFields=Array.isArray(details.changedFields)?details.changedFields:[];
          const partial=completion&&(changedFields.length>0||operations.some(op=>['done','completed','applied','success'].includes(op?.status)));
          await updateReceipt(prepared.id,{state:partial?'completion_partial':'assist_result_unknown',message:completion?(details.submitted===true?'新增补齐返回异常提交状态，请人工检查原生页面':partial?'新增表单已完成部分步骤，请按记录检查已改字段；未执行原生提交动作':'新增补齐结果待检查，请核对原生表单，避免重复执行'):'6项填写结果待检查；没有执行保存',errorCode:cause.code||'UNKNOWN',...(completion?{errorMessage:String(cause.message||'').slice(0,1000),operations,changedFields,...(details.submitted!=null?{submitted:details.submitted}:{}),...(details.snapshot?{afterSnapshot:stampSnapshot(details.snapshot,tab)}:{})}:{})});throw cause;
        }
        const receipt=await updateReceipt(prepared.id,{state:'waiting_native_save',message:preserveQuantity?'商品信息已填入，请填写或核对数量后保存':completion?'新增表单及六项草稿已补齐，尚未提交；请由你核对后原生提交':writeMode==='new_draft'?'新增表单6项草稿已填入；由员工原生补齐并提交':'6项已辅助填入；请在原生窗口保存',...(filled.snapshot?{afterSnapshot:stampSnapshot(filled.snapshot,tab)}:{}),...(filled.cartonSelection?{cartonSelection:filled.cartonSelection,cartonSelectionBeforeSnapshot:filled.cartonSelectionBeforeSnapshot}:{}),nativeDefaultChanges:filled.nativeDefaultChanges||[],...(Array.isArray(filled.referenceDefaults)?{referenceDefaults:filled.referenceDefaults}:{}),...(completion?{submitted:false,operations:Array.isArray(filled.operations)?filled.operations:[],changedFields:Array.isArray(filled.changedFields)?filled.changedFields:[]}:{})});
        if(renewedEdit){
          const ids=new Set(unresolvedList.map(r=>r.id)),at=new Date().toISOString();
          await mutateReceipts(rows=>({next:rows.map(r=>ids.has(r.id)?{...r,state:'superseded_edit',supersededFromState:r.state,replacementReceiptId:receipt.id,supersededAt:at,message:'已按本次规格选择重新编辑；此前保存结果仍未核验'}:r),result:null}));
        }else if(replacing)await updateReceipt(unresolved.id,{state:'replaced_draft',replacementReceiptId:receipt.id,message:'未提交草稿已按新的SKU选择替换'});
        return {...filled,receipt};
      }finally{activeAssists.delete(prepared.id);}
      }finally{fillLocks.delete(lock);}
    }
    if(message.type==='RECHECK_FILLED_DRAFT'){
      const tab=await ensureTab(payload.tabId,['qnh','qnh_reference','demo']);await receiptQueue;
      const {receipts=[]}=await api.storage.local.get('receipts'),receipt=receipts.find(r=>r.id===payload.receiptId&&r.tabId===tab.id);
      if(!receipt||activeAssists.has(receipt.id))throw error('NO_RECOVERABLE_DRAFT','没有可只读核对的本次草稿');
      const read=await send(tab.id,{type:'QNH_INSPECT_EDITOR'}),snapshot=stampSnapshot(read.snapshot,await confirmReturnedTab(tab));
      const check=validateDraftRecovery(receipt,snapshot);
      if(!check.ok)return {status:'not_verified',message:check.reasons.join('；'),submitted:false};
      const updated=await updateReceipt(receipt.id,{state:'waiting_native_save',recoveredReadOnly:true,recoveredAt:new Date().toISOString(),nativeDefaultChanges:check.nativeDefaultChanges,afterSnapshot:snapshot,submitted:false,message:'已只读核对当前草稿六项与原生起订量联动，尚未提交；请由你核对后原生提交'});
      return {status:'draft_verified',receipt:updated,snapshot,submitted:false};
    }
    if (message.type === 'VERIFY_RELATION' || message.type==='VERIFY_MAINTENANCE') {
      const tab=await ensureTab(payload.tabId,['qnh','qnh_reference','demo']);
      await receiptQueue;
      const {receipts=[]}=await api.storage.local.get('receipts');
      const prepared=receipts.find(r=>r.id===payload.receiptId);
      if (!prepared || prepared.tabId!==payload.tabId) throw error('NO_RECEIPT','没有匹配的待核对记录');
      const six=prepared.mode==='six_fields';
      const allowedReturn=six&&classifyTab(prepared.tabUrl)==='qnh'&&classifyTab(tab.url)==='qnh';
      if (!tabRoute(prepared.tabUrl) || (!allowedReturn&&tabRoute(prepared.tabUrl)!==tabRoute(tab.url))) throw error('SOURCE_TAB_MISMATCH','原标签页已导航到其他路由，不能使用旧记录核对另一页面');
      if (activeAssists.has(prepared.id)) throw error('FILL_IN_PROGRESS','辅助填写尚未完成，请稍后核对');
      let verificationBefore=prepared.beforeSnapshot;
      if(prepared.cartonSelection?.status==='selected'&&prepared.cartonSelectionBeforeSnapshot?.nativeEditor?.protectionFingerprint===verificationBefore?.nativeEditor?.protectionFingerprint&&prepared.afterSnapshot?.nativeEditor?.protectionFingerprint){
        verificationBefore={...verificationBefore,nativeEditor:{...verificationBefore.nativeEditor,protectionFingerprint:prepared.afterSnapshot.nativeEditor.protectionFingerprint}};
      }
      const result=stampResult(await send(payload.tabId,{type:six?'QNH_VERIFY_MAINTENANCE':'QNH_VERIFY_RELATION',rowRef:prepared.rowRef,expected:prepared.expected,beforeSnapshot:verificationBefore}),tab);
      const updated=await updateReceipt(prepared.id,{state:result.status==='verified'?'page_verified':result.status==='mismatch'?'mismatch':prepared.state==='completion_partial'?'completion_partial':'result_unknown',verifiedAt:new Date().toISOString(),verification:result});
      return {...result,receipt:updated};
    }
    throw error('UNKNOWN_COMMAND','不支持的操作');
  };
}

export function showPddQrLogin(){if(location.origin!=='https://mobile.yangkeduo.com'||location.pathname!=='/login.html')return {ready:false};if(!globalThis.__qnhQrLoginOpened){const node=[...document.querySelectorAll('span,div,button,a')].find(n=>!n.children.length&&n.textContent.trim()==='扫码登录');if(node){globalThis.__qnhQrLoginOpened=true;node.click();}}return {ready:true};}
