/** Conservative, pure candidate matching. Search text and low prices are not SKU evidence. */
import {targetIdentity} from './auto-fill.js';
import {extractSpecQuantity} from './draft-defaults.js';

const text=value=>typeof value==='string'?value.normalize('NFKC').trim().slice(0,2000):'';
const compact=value=>text(value).toLowerCase().replace(/[\s\[\]【】「」『』（）()_,，。:：;；/／|｜-]/g,'');
const COUNT_UNITS='瓶|袋|包|桶|罐|盒|支|个|条|片|卷|枚|只|粒|杯|件|套|张|箱|提|组';
const SAUCES=['剁椒酱','烧椒酱','豆瓣酱','香菇酱','牛肉酱','辣椒酱','蒜蓉酱','番茄酱','黄豆酱','甜面酱','豆豉酱'];
const MEAT_PARTS=['鸭翅根','鸭爪','鸭翅','鸭腿','鸭脖','鸭掌','鸡爪','鸡翅根','鸡翅','鸡腿'];
const meatParts=value=>MEAT_PARTS.filter(part=>value.includes(part)&&!(part==='鸭翅'&&value.includes('鸭翅根'))&&!(part==='鸡翅'&&value.includes('鸡翅根')));
const FLAVORS=['爆辣','清香','香辣','麻辣','微辣','中辣','特辣','酸辣','红烧','原味','清汤','海鲜','番茄','咖啡','草莓','香芋','麦香','巧克力','抹茶'];
const MIXED=/混合|混装|组合|套餐|随机|任选|拼装|每种|各\s*\d+|[+＋]|赠|贈|(?:买|送)\s*\d/;
const BAD_BRAND=/^(?:预览|查看图片|商品|精选|精品|食品|日用品|其他|新款|热卖|正品|官方|规格|品牌)$/;
const positiveId=value=>typeof value==='string'&&/^[1-9]\d*$/.test(value);

function canonicalDecimal(n,d=1n){
  let whole=String(n/d),rest=n%d;if(!rest)return whole;
  let tail='';for(let i=0;i<12&&rest;i++){rest*=10n;tail+=String(rest/d);rest%=d;}
  return whole+'.'+tail.replace(/0+$/,'');
}
function measure(value,unit){
  const [whole,tail='']=value.split('.');let n=BigInt(whole+tail),d=10n**BigInt(tail.length);
  const normalized=unit.toLowerCase();
  const mass=['kg','千克','公斤','斤','g','克','mg','毫克'].includes(normalized);
  if(['kg','千克','公斤','l','升'].includes(normalized))n*=1000n;
  else if(normalized==='斤')n*=500n;
  else if(['mg','毫克'].includes(normalized))d*=1000n;
  const result=canonicalDecimal(n,d),canonicalUnit=mass?'g':'ml';
  return {dimension:mass?'mass':'volume',value:result,unit:canonicalUnit,text:result+canonicalUnit};
}
function readMeasures(value){
  const input=text(value),values=[];
  const pattern=/(\d{1,6}(?:\.\d{1,6})?)\s*(公斤|千克|毫克|kg|mg|毫升|ml|克|g|升|l|斤)(?![a-z])/gi;
  for(const match of input.matchAll(pattern)){
    if(match.index>0&&/[\d.]/.test(input[match.index-1]))continue;
    const item=measure(match[1],match[2]);if(item.value==='0')continue;
    const before=input.slice(Math.max(0,match.index-12),match.index);
    values.push({...item,raw:match[0],index:match.index,role:/(?:总重|总净含量|合计|共计|共重|合共)\s*[:：]?\s*$/.test(before)?'total':'unit'});
  }
  return values;
}
const keyOf=m=>m.dimension+':'+m.value;
function distinctMeasures(rows){return [...new Map(rows.map(row=>[keyOf(row),row])).values()];}
function backendUnits(snapshot){
  const spec=text(snapshot.backendSpec),name=text(snapshot.backendName),units=[];
  for(const value of [spec,name])for(const match of value.matchAll(new RegExp('(?:[/／]|每)\\s*('+COUNT_UNITS+')','g')))units.push(match[1]);
  const direct=text(snapshot.backendUnit);if(new RegExp('^(?:'+COUNT_UNITS+')$').test(direct))units.push(direct);
  return [...new Set(units)];
}
function brandFrom(snapshot,name){
  const explicit=text(snapshot.backendBrand);if(explicit)return {brand:explicit,source:'backend_brand'};
  const bracket=name.match(/^\s*[【\[]([^】\]]{2,16})[】\]]/);
  if(bracket&&!BAD_BRAND.test(bracket[1])&&!/\d|[/×*]/.test(bracket[1]))return {brand:bracket[1],source:'backend_name_bracket'};
  const first=name.match(/^([\p{L}·]{2,16})\s+/u)?.[1]||'';
  return first&&!BAD_BRAND.test(first)?{brand:first,source:'backend_name_prefix'}:{brand:'',source:'unknown'};
}
function coreFrom(snapshot,name,brand){
  const explicit=text(snapshot.backendProductName||snapshot.backendCoreName);if(explicit)return {name:explicit,source:'backend_product_name'};
  let rest=name.replace(/^[【\[][^】\]]+[】\]]\s*/,'');
  if(brand&&rest.startsWith(brand))rest=rest.slice(brand.length).trim();
  // Keep the actual sauce variety instead of broad marketing nouns such as
  // "下饭菜/厨房调料". Other categories use a short, separated product phrase.
  const sauce=SAUCES.map(term=>({term,index:rest.indexOf(term)})).filter(x=>x.index>=0).sort((a,b)=>a.index-b.index||b.term.length-a.term.length)[0];
  if(sauce&&sauce.index<12)return {name:sauce.term,source:'named_sauce_variety'};
  const parts=meatParts(rest);if(parts.length===1)return {name:parts[0],source:'named_meat_part'};
  rest=rest.split(/\d+(?:\.\d+)?\s*(?:公斤|千克|kg|克|g|毫升|ml|升|l|斤)/i)[0].trim();
  const first=rest.split(/[\s,，;；|｜/／]+/)[0].replace(/(?:下饭菜|厨房|调料|调味|批发|特价|整箱|袋装|瓶装).*$/,'').trim();
  return first&&first.length<=16&&!/商品|预览|名称|规格/.test(first)?{name:first,source:'backend_name_phrase'}:{name:'',source:'unknown'};
}

/** Never use UPC search-box text as the selected product's identity. */
export function buildProductSearchProfile(snapshot={}){
  snapshot=snapshot&&typeof snapshot==='object'?snapshot:{};
  const name=text(snapshot.backendName).split(/\nUPC[:：]?/)[0],spec=text(snapshot.backendSpec),upc=text(snapshot.backendUpc);
  const {brand,source:brandSource}=brandFrom(snapshot,name),core=coreFrom(snapshot,name,brand);
  const measures=distinctMeasures(readMeasures(spec+' '+name).filter(m=>m.role==='unit')),units=backendUnits(snapshot),flavors=FLAVORS.filter(term=>(text(snapshot.backendFlavor)||name+' '+spec).includes(term)),reasons=[];
  const bound=!!snapshot.nativeEditor&&!!text(snapshot.tenantId)&&Number.isInteger(snapshot.sourceTabId)&&!!text(snapshot.nativeEditor.bindingId||snapshot.rowRef)&&/^\d{8,18}$/.test(upc)&&(
    snapshot.backendUpcSource==='native_product'||snapshot.backendUpcSource==='clicked_row'&&!!text(snapshot.relationId)&&!!text(snapshot.rowRef)
  );
  if(!bound)reasons.push('尚未确认原生表单已关联的商品身份，查询输入不能作为关联证据');
  if(!name)reasons.push('后台商品名称尚未读取');
  if(!brand)reasons.push('后台品牌未明确，不能仅凭相似标题确认同款');
  if(!core.name)reasons.push('后台核心品名未明确');
  if(flavors.length>1)reasons.push('后台口味包含多个选项，尚未明确本次维护的具体口味');
  if(measures.length!==1)reasons.push(measures.length?'后台净含量存在冲突，需核对单件规格':'后台未读取到明确的单件净含量');
  if(units.length!==1)reasons.push(units.length?'后台包装单位存在冲突':'后台包装单位未明确');
  const netContent=measures.length===1?{dimension:measures[0].dimension,value:measures[0].value,unit:measures[0].unit,text:measures[0].text}:null;
  const query=[brand,core.name,netContent?.text].filter(Boolean).join(' ')||name.slice(0,80);
  return {version:1,status:reasons.length?'needs_review':'ready',query,brand,brandSource,productName:core.name,productNameSource:core.source,flavors,netContent,unit:units.length===1?units[0]:'',backendName:name,backendSpec:spec,upc,targetIdentity:targetIdentity(snapshot),reasons,profileKey:JSON.stringify([targetIdentity(snapshot),name,spec,brand,core.name,flavors,netContent?.text||'',units])};
}

/** Each result is evidence about this exact SKU, not the product's lowest advertised price. */
export function matchProductSku(profile={},sku={}){
  profile=profile&&typeof profile==='object'?profile:{};sku=sku&&typeof sku==='object'?sku:{};
  const name=text(sku.name),spec=text(sku.spec),reasons=[];
  const result=(status,quantity='')=>({status,reasons,quantity,ratioPdd:'1',ratioQnh:status==='matched'?quantity:'',sku});
  if(!positiveId(sku.goodsId)||!positiveId(sku.skuId)){reasons.push('缺少明确商品ID或SKU ID');return result('needs_review');}
  if(!spec||sku.specComplete===false){reasons.push('尚未读取到完整具体规格');return result('needs_review');}
  if(sku.onSale===false||sku.onSale==='false'||typeof sku.stock==='string'&&/^0+$/.test(sku.stock)||sku.stock===0){reasons.push('当前SKU已下架或库存为0');return result('rejected');}
  if(MIXED.test(spec)){reasons.push('所选SKU包含混装、组合、赠品或随机口味');return result('rejected');}
  if(profile.status!=='ready'||!profile.brand||!profile.productName||!profile.netContent||!profile.unit){reasons.push(...(profile.reasons||[]),'后台匹配条件尚未明确');return result('needs_review');}
  const candidateBrand=text(sku.brand||sku.brandName);
  if(candidateBrand&&compact(candidateBrand)!==compact(profile.brand)){reasons.push('候选品牌与后台品牌不一致');return result('rejected');}
  if(!compact(name+' '+spec).includes(compact(profile.brand))){reasons.push('候选未明确标示后台品牌');return result('needs_review');}
  const skuVarieties=SAUCES.filter(term=>spec.includes(term));
  if(MEAT_PARTS.includes(profile.productName)){
    const parts=meatParts(spec);
    if(parts.length&& (parts.length!==1||parts[0]!==profile.productName)){reasons.push('所选SKU部位与后台商品不一致');return result('rejected');}
    if(!parts.length&&meatParts(name).length>1){reasons.push('SKU未明确部位，标题包含多种鸭肉或鸡肉部位');return result('needs_review');}
  }
  if(SAUCES.includes(profile.productName)&&skuVarieties.length&&(!skuVarieties.includes(profile.productName)||skuVarieties.some(term=>term!==profile.productName&&term!=='辣椒酱'))){reasons.push('所选SKU包含不同或多种酱料品种');return result('rejected');}
  const requiredFlavors=Array.isArray(profile.flavors)?profile.flavors:FLAVORS.filter(term=>profile.productName.includes(term)),skuFlavors=FLAVORS.filter(term=>spec.includes(term));
  if(requiredFlavors.length){
    const observedFlavors=skuFlavors.length?skuFlavors:FLAVORS.filter(term=>name.includes(term));
    if(observedFlavors.length>1||!observedFlavors.length){reasons.push('SKU具体口味尚未明确');return result('needs_review');}
    if(!requiredFlavors.every(term=>observedFlavors.includes(term))){reasons.push('所选SKU口味与后台商品不一致');return result('rejected');}
  }
  if(!compact(name+' '+spec).includes(compact(profile.productName))){reasons.push('核心品名未匹配，未将相似商品当作同款');return result('needs_review');}
  const quantity=extractSpecQuantity(spec,profile.unit);
  // Search ranking still compares package identity; employee-selected filling uses the count directly.
  if(quantity.status==='matched'&&quantity.unit!==profile.unit){reasons.push('候选商品包装单位与搜索条件不同');return result('rejected');}
  const skuMeasures=readMeasures(spec),unitMeasures=distinctMeasures(skuMeasures.filter(m=>m.role==='unit'));
  let source='SKU',observed=unitMeasures;
  if(!observed.length){
    // A short SKU such as "2瓶" may inherit one unambiguous title measure.
    // A title with alternate weights or products cannot resolve that omission.
    const titleVarieties=SAUCES.filter(term=>name.includes(term));
    if(MIXED.test(name)||titleVarieties.some(term=>term!==profile.productName&&term!=='辣椒酱')){reasons.push('SKU未写净含量，标题又包含多个品种或组合');return result('needs_review');}
    observed=distinctMeasures(readMeasures(name).filter(m=>m.role==='unit'));source='商品标题';
  }
  if(observed.length!==1){reasons.push(observed.length?'SKU存在多个净含量，不能确定单件克重':'SKU与标题均未明确单件净含量');return result('needs_review',quantity.status==='matched'&&quantity.unit===profile.unit?quantity.quantity:'');}
  if(keyOf(observed[0])!==keyOf(profile.netContent)){reasons.push('单件净含量不同：后台'+profile.netContent.text+'，候选'+observed[0].text);return result('rejected');}
  if(quantity.status!=='matched'||quantity.unit!==profile.unit){reasons.push(quantity.message||'每采购件数量或包装单位未明确');return result('needs_review');}
  const totals=skuMeasures.filter(m=>m.role==='total');
  if(totals.some(total=>total.dimension!==profile.netContent.dimension||BigInt(total.value.replace('.',''))*10n**BigInt((profile.netContent.value.split('.')[1]||'').length)!==BigInt(profile.netContent.value.replace('.',''))*BigInt(quantity.quantity)*10n**BigInt((total.value.split('.')[1]||'').length))){reasons.push('所选SKU总净含量与单件净含量、数量不一致');return result('needs_review');}
  reasons.push('品牌与核心品名匹配',source+'明确单件'+profile.netContent.text,'每采购件'+quantity.quantity+profile.unit+'，对应后台'+quantity.quantity+profile.unit);
  return result('matched',quantity.quantity);
}

/** Stable ranking; no price preference and no automatic selection or mutation. */
export function rankProductCandidates(profile,skus=[]){
  const order={matched:0,needs_review:1,rejected:2};
  return (Array.isArray(skus)?skus:[]).map((sku,index)=>{
    const {sku:_candidate,...matching}=matchProductSku(profile,sku);
    return {index,value:{...sku,matching,recommendationTarget:profile.targetIdentity}};
  }).sort((a,b)=>order[a.value.matching.status]-order[b.value.matching.status]||a.index-b.index).map(row=>row.value);
}
