/** Pure suggestions for a single new draft. No page writes, pricing guesses or approval side effects. */
const text=value=>String(value??'').trim();
const COUNT_UNITS='袋|桶|瓶|罐|盒|支|个|包|条|片|卷|枚|只|粒|杯|件|套|张|箱|提|组';
const own=(object,key)=>Object.prototype.hasOwnProperty.call(object||{},key);
const canonicalInteger=value=>value.replace(/^0+(?=\d)/,'');
function decimal(value){
 if(typeof value==='number'&&(!Number.isFinite(value)||value<0||value>Number.MAX_SAFE_INTEGER))return '';
 const s=text(value);return s.length<=200&&/^\d+(?:\.\d+)?$/.test(s)?s:'';
}
function canonicalDecimal(value,extraScale=0){
 const [whole,fraction='']=value.split('.'),scale=fraction.length+extraScale;
 let digits=(whole+fraction).replace(/^0+(?=\d)/,'');
 if(scale){digits=digits.padStart(scale+1,'0');const split=digits.length-scale;return digits.slice(0,split)+'.'+digits.slice(split).replace(/0+$/,'')||'0';}
 return digits;
}
function divideHundred(value){return canonicalDecimal(value,2).replace(/\.$/,'');}

/** Unit conversion only; a converted quotation is not evidence of a coupon-adjusted unit price. */
export function convertSkuPriceToYuan(price,priceUnit){
 const raw=decimal(price),source={value:text(price),unit:text(priceUnit),operation:priceUnit==='fen'?'divide_by_100':priceUnit==='yuan'?'identity':'none'};
 if(!raw)return {status:'invalid_price',value:'',unit:'unknown',exact:false,source,message:'报价不是可精确读取的非负十进制数'};
 if(!['fen','yuan'].includes(priceUnit))return {status:'unknown_unit',value:'',unit:'unknown',exact:false,source,message:'报价单位未知，未按数值猜测元或分'};
 return {status:'converted',value:priceUnit==='fen'?divideHundred(raw):raw,unit:'yuan',exact:true,source,message:'仅换算报价单位，未证明这是券后实际单价'};
}

function sourcePresent(source){
 return typeof source==='string'?!!source.trim():!!source&&typeof source==='object'&&['kind','field','label','description','selector'].some(key=>typeof source[key]==='string'&&source[key].trim());
}
/** The one-item checkout total is a unit cost only with this complete proof. */
export function validateCheckoutPriceSource(candidate={}){
 const s=candidate.actualPayPriceSource,fail=message=>({valid:false,message});
 if(!s||typeof s!=='object'||s.kind!=='checkout_payable_unit_quote')return fail('缺少当前SKU的确认订单页应付报价');
 if(!['rawData.store.orderInfo.payPrice','visible_pending_checkout_payable'].includes(s.field)||s.goodsId!==candidate.goodsId||s.skuId!==candidate.skuId||s.goodsNumber!=='1'||s.singleSku!==true||s.quantityVerified!==true||s.unsubmitted!==true)return fail('应付报价的商品、SKU、单件数量或未提交状态证据不完整');
 if(s.costBasis!=='single_sku_payable_including_shipping')return fail('应付报价未明确单件及运费口径');
 const fen=value=>typeof value==='string'&&/^\d+$/.test(value)&&value.length<=80;
 if(!['payableTotalFen','shippingCostFen','goodsPayableFen'].every(k=>fen(s[k])))return fail('应付报价金额或运费缺少明确分单位');
 const total=BigInt(s.payableTotalFen),shipping=BigInt(s.shippingCostFen),goods=BigInt(s.goodsPayableFen);
 if(total<=0n||shipping+goods!==total)return fail('应付金额与商品金额、运费不一致');
 if(s.visiblePayableFen!=null&&(!fen(s.visiblePayableFen)||s.visiblePayableFen!==s.payableTotalFen))return fail('可见结算金额与应付报价不一致');
 if(s.field==='visible_pending_checkout_payable'){
  const c=s.favoritesCoupon;let valid=false;
  try{const url=new URL(c?.sourceUrl),age=Date.parse(s.capturedAt)-Date.parse(c?.capturedAt);valid=s.visiblePayableFen===s.payableTotalFen&&s.pendingControlEvidence==='visible_unsubmitted_checkout_立即支付'&&s.unitEvidence==='visible_checkout_currency_yuan'&&c.goodsId===candidate.goodsId&&c.skuId===candidate.skuId&&c.goodsNumber==='1'&&fen(c.amountFen)&&BigInt(c.amountFen)===goods&&age>=-5000&&age<=60000&&url.origin==='https://mobile.yangkeduo.com'&&url.pathname==='/likes.html'&&!url.username&&!url.password;}catch{}
  if(!valid)return fail('可见应付价缺少同SKU、单件收藏券后价的独立核对');
 }
 const converted=convertSkuPriceToYuan(candidate.actualPayPrice,candidate.actualPayPriceUnit);
 if(converted.status!=='converted')return fail('应付报价缺少明确价格单位');
 const [whole,fraction='']=converted.value.split('.'),scale=10n**BigInt(fraction.length),amount=BigInt(whole+fraction);
 if(amount*100n!==total*scale)return fail('候选应付单价与页面应付总额不一致');
 try{
  const u=new URL(s.sourceUrl);if(u.origin!=='https://mobile.yangkeduo.com'||u.pathname!=='/order_checkout.html'||u.username||u.password)throw Error();
  for(const [key,value]of [['goods_id',candidate.goodsId],['sku_id',candidate.skuId],['goods_number','1']]){const values=u.searchParams.getAll(key);if(values.length!==1||values[0]!==value)throw Error();}
  const groups=u.searchParams.getAll('group_id');if(groups.length!==1||!/^\d+$/.test(groups[0]))throw Error();
  if(candidate.groupId!=null&&String(candidate.groupId)!==(groups[0]??''))throw Error();
  if(candidate.checkoutUrl){const link=new URL(candidate.checkoutUrl),expected=link.searchParams.getAll('group_id');if(expected.length>1||JSON.stringify(expected)!==JSON.stringify(groups))throw Error();}
 }catch{return fail('应付报价来源地址、SKU或拼团组与当前候选不一致');}
 if(typeof s.capturedAt!=='string'||!Number.isFinite(Date.parse(s.capturedAt)))return fail('应付报价缺少读取时间');
 return {valid:true,message:'已核对当前SKU单件应付金额',value:converted.value,unit:'yuan',source:s};
}
export function isFreshCheckoutPrice(candidate,now=Date.now(),maxAgeMs=60000){const result=validateCheckoutPriceSource(candidate);if(!result.valid)return false;const age=now-Date.parse(result.source.capturedAt);return age>=-5000&&age<=maxAgeMs;}
function sourceProblem(source,candidate){
 if(source?.kind==='checkout_payable_unit_quote'){const result=validateCheckoutPriceSource(candidate);return result.valid?'':result.message;}
 const description=typeof source==='string'?source:JSON.stringify(source||{});
 if(/orderInfo[.\/_]?payPrice|order[_ .-]?(?:total|amount)|cart[_ .-]?(?:total|amount)|整单|订单总|总金额|合计/i.test(description))return '整单或购物车总额不能作为所选SKU的实际单价';
 if(source&&typeof source==='object'){
  for(const key of ['goodsNumber','goods_number','quantity'])if(source[key]!=null&&!/^0*1(?:\.0+)?$/.test(text(source[key])))return '报价来源购买数量不是1，不能直接作为所选SKU的单件实际单价';
  if(source.skuId!=null&&String(source.skuId)!==String(candidate.skuId))return '券后报价的SKU来源与当前候选不一致';
  if(source.goodsId!=null&&String(source.goodsId)!==String(candidate.goodsId))return '券后报价的商品来源与当前候选不一致';
 }
 return '';
}
function rawReference(candidate,key){
 const trustedRaw=candidate.rawPriceSkuKey==null||candidate.rawPriceSkuKey===key;
 return {value:trustedRaw&&own(candidate,'rawPrice')?candidate.rawPrice:candidate.price,unit:trustedRaw&&own(candidate,'rawPriceUnit')?candidate.rawPriceUnit:candidate.priceUnit,basis:trustedRaw&&candidate.rawPriceBasis?candidate.rawPriceBasis:candidate.priceBasis==='before_coupon'?'before_coupon':'unknown'};
}
/** Resolve a documented SKU unit quotation. This does not claim an order has been paid. */
export function resolveSkuPriceEvidence(candidate={}){
 const key=String(candidate.goodsId??'')+':'+String(candidate.skuId??''),raw=rawReference(candidate,key),reference=convertSkuPriceToYuan(raw.value,raw.unit);
 const candidates=[['actualPayPrice','actualPayPriceUnit','actualPayPriceSource'],['afterCouponPrice','afterCouponPriceUnit','afterCouponPriceSource']];
 if(candidate.priceBasis==='actual_pay'&&candidate.priceSource)candidates.push(['price','priceUnit','priceSource']);
 const available=[],rejected=[];
 for(const [field,unitField,sourceField]of candidates){
  if(candidate[field]==null||text(candidate[field])==='')continue;
  const converted=convertSkuPriceToYuan(candidate[field],candidate[unitField]),problem=sourceProblem(candidate[sourceField],candidate);
  if(converted.status!=='converted'||!sourcePresent(candidate[sourceField])||problem){rejected.push({field,reason:problem||(!sourcePresent(candidate[sourceField])?'券后单价来源缺失':converted.message),conversion:converted});continue;}
  available.push({field,value:converted.value,unit:'yuan',source:candidate[sourceField],conversion:converted});
 }
 const checkout=available.find(item=>item.field==='actualPayPrice'&&item.source?.kind==='checkout_payable_unit_quote');
 if(checkout)return {status:'actual_quote',priceBasis:'actual_pay',value:checkout.value,unit:'yuan',requiresPriceConfirmation:false,field:checkout.field,source:checkout.source,conversion:checkout.conversion,referenceYuan:reference.value,reference,raw,rejected,otherQuotations:available.filter(item=>item!==checkout),message:'已读取所选SKU单件当前应付价（含明确运费）；不表示已付款'};
 const distinct=new Set(available.map(item=>canonicalDecimal(item.value).replace(/\.$/,'')));
 if(distinct.size>1)return {status:'conflicting_actual_prices',priceBasis:'unknown',value:'',unit:'unknown',requiresPriceConfirmation:true,referenceYuan:reference.value,reference,raw,rejected,actualCandidates:available,message:'所选SKU的明确券后单价来源互相冲突，请人工核对'};
 if(available.length){const selected=available[0];return {status:'actual_quote',priceBasis:'actual_pay',value:selected.value,unit:'yuan',requiresPriceConfirmation:false,field:selected.field,source:selected.source,conversion:selected.conversion,referenceYuan:reference.value,reference,raw,rejected,message:'读取到有来源的所选SKU券后单价；不表示已付款'};}
 return {status:'actual_price_required',priceBasis:raw.basis==='before_coupon'?'before_coupon':'unknown',value:'',unit:rejected.some(item=>item.conversion.status==='unknown_unit')?'unknown':reference.status==='converted'?'yuan':'unknown',requiresPriceConfirmation:true,referenceYuan:reference.value,reference,raw,rejected,message:(reference.value?'参考报价'+reference.value+'元；':'')+'未读取到有明确单位与来源的所选SKU券后单价，请填写实际付款单价'};
}

function backendUnitEvidence(backendSpec){
 const raw=text(backendSpec),normalized=raw.normalize('NFKC').replace(/[（(]\s*(?:g|克|kg|千克|ml|毫升|l|升)\s*[/／]\s*份\s*[)）]/gi,'');
 const units=[];
 for(const match of normalized.matchAll(new RegExp('(?:[/／]|每|单)\\s*('+COUNT_UNITS+')','g')))units.push(match[1]);
 for(const match of normalized.matchAll(new RegExp('(?:^|[xX×*\\s（(])1\\s*('+COUNT_UNITS+')','g')))units.push(match[1]);
 const exact=normalized.match(new RegExp('^(?:1\\s*)?('+COUNT_UNITS+')$'));if(exact)units.push(exact[1]);
 const unique=[...new Set(units)];return {source:'snapshot.backendSpec',raw,status:unique.length===1?'known':unique.length>1?'ambiguous':'unknown',unit:unique.length===1?unique[0]:'',units:unique};
}

/** Only candidate.spec is parsed. Product titles, IDs and unrelated numeric text are never considered. */
export function extractSpecQuantity(spec,backendSpec=''){
 const raw=text(spec),normalized=raw.normalize('NFKC'),backend=backendUnitEvidence(backendSpec),matches=[];
 const result=(status,message,quantity='',unit='')=>({status,quantity,unit,source:'candidate.spec',raw,normalized,matches,backend,message,requiresReview:true});
 if(!raw)return result('missing','缺少明确规格文字，未预填后台数量');
 for(const match of normalized.matchAll(new RegExp('(\\d+(?:\\.\\d+)?)\\s*('+COUNT_UNITS+')','g')))matches.push({text:match[0],quantity:match[1],unit:match[2],index:match.index});
 if(/赠|贈|(?:买|送)\s*\d+|加量|加赠/.test(normalized))return result('unsupported','规格含赠品或加量信息，未把赠品或主品数量当作默认换算量');
 // Flavor assortment describes contents, not the total package count. Remove
 // only explicit flavor descriptors; a bare bundle/random label still needs
 // review. All count, unit, gift and multiplier checks remain below.
 const quantityDescription=normalized.replace(/(?:混合|混装|随机|任选)(?:口味|味道)(?:随机发(?:货)?|随机|混装|任选)?|(?:口味|味道)(?:随机发(?:货)?|随机|混合|混装|任选)/g,'');
 if(/混合|混装|组合|套餐|随机|任选|拼装|每种|各\s*\d+/.test(quantityDescription))return result('unsupported','规格含混合或组合数量，需人工核对');
 if(new RegExp('\\d+\\s*(?:[-~～至到或+]|\\.\\.)\\s*\\d+\\s*(?:'+COUNT_UNITS+')').test(normalized))return result('ambiguous','规格包含数量范围、可选数量或未明确的合计，需人工核对');
 // Some official SKU names put the package noun first: 大桶红烧牛肉1*12.
 // Accept only a trailing 1*N with one explicit package-type clue in the
 // selected spec. A product title or a bare dimension such as 1*12 is not proof.
 if(!matches.length){
  const multiplier=normalized.match(/1\s*[xX×*]\s*(\d+)\s*$/);
  if(multiplier&&(multiplier.index===0||!/[\d.]/.test(normalized[multiplier.index-1]))){
   const prefix=normalized.slice(0,multiplier.index),clues=[...prefix.matchAll(/(?:大食|加大|标准|迷你|大|小)(桶|瓶|罐|盒|袋|包)|(桶|瓶|罐|盒|袋|包)装/g)].map(m=>m[1]||m[2]);
   const units=[...new Set(clues)],unexplained=prefix.replace(/\d+(?:\.\d+)?\s*(?:kg|ml|g|l|千克|毫升|克|升)(?![a-z])/gi,'');
   if(units.length===1&&!/\d|[*×+~～-]|SKU|编号|编码|货号|条码|型号|尺寸|厘米|毫米|长宽|长度|宽度|\b(?:cm|mm)\b/i.test(unexplained))matches.push({text:multiplier[0].trim(),quantity:multiplier[1],unit:units[0],index:multiplier.index,kind:'unit_prefixed_multiplier'});
  }
 }
 if(!matches.length)return result('missing','未发现明确件数；克重、容量或尺寸不作为包装件数');
 if(matches.some(match=>match.quantity.includes('.')||!/[1-9]/.test(match.quantity)||BigInt(match.quantity)>1000000n))return result('unsupported','规格件数不是可直接预填的明确正整数');
 if(new RegExp('\\d+(?:\\.\\d+)?\\s*[xX×*]\\s*\\d+\\s*(?:'+COUNT_UNITS+')').test(normalized))return result('ambiguous','规格含未明确单位的乘数，不能把尺寸或多层包装猜成件数');
 if(matches.some(match=>/(?:SKU|编号|编码|货号|条码)\s*[:：#]?\s*$/i.test(normalized.slice(Math.max(0,match.index-12),match.index))))return result('unsupported','编号附近的数字不能作为包装数量');
 const unique=new Map(matches.map(match=>[canonicalInteger(match.quantity)+':'+match.unit,{quantity:canonicalInteger(match.quantity),unit:match.unit}]));
 if(unique.size!==1)return result('ambiguous','规格包含混合单位或冲突数量，未自动换算');
 if(matches.slice(1).some((match,i)=>!/^[\s（(【\[]*(?:总共|总计|合计|共)\s*$/.test(normalized.slice(matches[i].index+matches[i].text.length,match.index))))return result('ambiguous','规格包含多个分项数量，未明确唯一总件数，需人工核对');
 const selected=[...unique.values()][0];
 // Backend unit labels do not gate the explicit count selected by the employee.
 return result('matched',backend.status==='unknown'?'规格数量明确；后台单位未解析，须员工核对单位对应关系':'仅从所选SKU规格提取明确数量，代填后请员工核对包装与后台数量',selected.quantity,selected.unit);
}

const edited=(map,key)=>map?.[key]===true||map?.['candidate.'+key]===true;
const skuKey=candidate=>['goodsId','skuId'].every(key=>typeof candidate?.[key]==='string'&&/^\d+$/.test(candidate[key])&&!/^0+$/.test(candidate[key]))?candidate.goodsId+':'+candidate.skuId:'';

/** Only quantities supported by the selected specification are filled. */
export function resolveFillQuantity(spec,backendSpec=''){
 const quantity=extractSpecQuantity(spec,backendSpec);
 if(quantity.status==='matched'||!quantity.raw)return quantity;
 return {...quantity,status:'unrecognized',message:'未能明确识别规格件数，请在牵牛花填写或核对数量。'};
}

/**
 * Immutable draft merge. Root input handlers should mark userEditedDefaults.
 * Price and priceUnit form one edited pair. A new SKU/reset clears old edit and
 * actual-price confirmation metadata. Without a count, use the current form values.
 */
export function applyNewDraftDefaults(snapshot,draft,{resetForSku=false}={}){
 const mode=snapshot?.routeMode??snapshot?.nativeEditor?.routeMode;
 if(mode!=='new'||text(snapshot?.relationId))return {draft,changed:false,appliedFields:[],keptFields:[],evidence:{eligible:false,reason:'仅对明确的新增表单应用预填，已有关系保留当前比例'}};
 const candidate=draft?.candidate||{},key=skuKey(candidate);
 if(!key)return {draft,changed:false,appliedFields:[],keptFields:[],evidence:{eligible:false,reason:'缺少可靠的当前商品或SKU字符串标识'}};
 const previous=draft.defaultEvidence||{},reset=resetForSku||(!!previous.skuKey&&previous.skuKey!==key);
 const userEditedDefaults=reset?{}:{...(draft.userEditedDefaults||{})};
 const next={...draft,candidate:{...candidate},userEditedDefaults,...(reset?{actualPriceConfirmed:false}:{})};
 const appliedFields=[],keptFields=[],changedFields=[];
 const put=(field,value)=>{const parts=field.split('.'),target=parts.length===2?next.candidate:next,prop=parts.at(-1);if(target[prop]!==value){changedFields.push(field);target[prop]=value;}appliedFields.push(field);};
 const raw=rawReference(candidate,key),price=resolveSkuPriceEvidence(candidate),quantity=resolveFillQuantity(candidate.spec,snapshot?.backendSpec||'');
 next.candidate.rawPrice=text(raw.value);next.candidate.rawPriceUnit=text(raw.unit);next.candidate.rawPriceBasis=raw.basis;next.candidate.rawPriceSkuKey=key;
 const same=!reset&&previous.skuKey===key,last=previous.appliedValues||{};
 const priceEdited=edited(userEditedDefaults,'price')||edited(userEditedDefaults,'priceUnit')||(!reset&&same&&candidate.rawPriceSkuKey===key&&own(last,'price')&&text(candidate.price)!==text(last.price));
 let priceEvidence=price;
 if(priceEdited){
  keptFields.push('candidate.price','candidate.priceUnit');
  const manual=convertSkuPriceToYuan(candidate.price,candidate.priceUnit),confirmed=next.actualPriceConfirmed===true&&manual.status==='converted'&&text(candidate.price)!=='';
  priceEvidence={...price,status:confirmed?'manual_actual_price':'manual_price_needs_confirmation',priceBasis:confirmed?'actual_pay':'unknown',value:text(candidate.price),unit:candidate.priceUnit,requiresPriceConfirmation:!confirmed,manual:true,source:confirmed?'user_confirmed_actual_price':'user_edited_price',message:confirmed?'员工明确确认的实际单价；未声称平台已付款':'保留员工输入的价格及单位，仍需确认所选SKU券后实际单价'};
  next.candidate.priceBasis=priceEvidence.priceBasis;if(confirmed)next.candidate.priceSource='user_confirmed_actual_price';
 }else{
  put('candidate.price',price.status==='actual_quote'?price.value:'');put('candidate.priceUnit',price.unit);
  put('candidate.priceBasis',price.priceBasis);
 }
 for(const [field,value]of [['ratioPdd',quantity.quantity?'1':text(snapshot.nativeFields?.ratioPdd)],['ratioQnh',quantity.quantity||text(snapshot.nativeFields?.ratioQnh)]]){
  const manual=edited(userEditedDefaults,field)||(same&&own(last,field)&&text(draft[field])!==text(last[field]));
  if(manual)keptFields.push(field);else put(field,value);
 }
 const evidence={eligible:true,skuKey:key,resetForSku:reset,price:priceEvidence,priceBasis:priceEvidence.priceBasis,requiresPriceConfirmation:priceEvidence.requiresPriceConfirmation,quantity,appliedValues:{price:next.candidate.price,priceUnit:next.candidate.priceUnit,ratioPdd:next.ratioPdd,ratioQnh:next.ratioQnh}};
 next.defaultEvidence=evidence;
 const changed=changedFields.length>0;
 if(changed||reset)next.approvedFingerprint='';
 return {draft:next,changed,appliedFields,keptFields,evidence};
}
