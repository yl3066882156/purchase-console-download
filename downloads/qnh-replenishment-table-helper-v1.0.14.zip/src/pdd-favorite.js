/**
 * Serialized MAIN-world setter using the supplied Haixiaobao client's API_Like
 * and API_FavoriteList requests. It sets favorites; it never toggles or deletes.
 * A mutation response alone is not proof: the exact product must be read back.
 */
export async function setPddFavorite({ goodsId, skuId, verifyOnly = false } = {}) {
  const origin = 'https://mobile.yangkeduo.com';
  const positiveId = value => typeof value === 'string' && /^[1-9]\d*$/.test(value);
  const allowed = () => location.origin === origin && /^\/(?:likes|goods\d*|search_result)\.html$/.test(location.pathname);
  let mutationAttempted = false;
  const base = () => ({ goodsId, skuId, mutationAttempted, verified: false });
  if (!allowed() || !positiveId(goodsId) || !positiveId(skuId) || typeof verifyOnly !== 'boolean') {
    return { ...base(), status: 'unsupported', message: '仅可在当前拼多多官网收藏、详情或搜索结果页收藏明确商品和SKU。' };
  }

  // The original client's GetUrl binds these same-origin requests to the named
  // non-token user ID. Never enumerate cookies or return/persist this identity.
  let uid = '';
  try {
    const identity = await globalThis.cookieStore?.get('pdd_user_id');
    if (positiveId(identity?.value)) uid = identity.value;
  } catch { /* Missing Cookie Store support leaves the original client's zero default. */ }

  const maxBytes = 2 * 1024 * 1024;
  const platformIssue = value => {
    const queue = [{ value, depth: 0 }];
    for (let i = 0; i < queue.length && i < 12; i++) {
      const { value: row, depth } = queue[i];
      if (!row || typeof row !== 'object' || Array.isArray(row)) continue;
      const message = String(row.error_msg ?? row.errorMsg ?? row.message ?? '').slice(0, 200);
      const code = row.error_code ?? row.errorCode;
      if (/登录|登陆|验证|风控|访问频繁|安全校验|异常访问|captcha|login|challenge/i.test(message) || ['40001', '54001'].includes(String(code))) {
        return { status: 'needs_user', message: '拼多多要求登录或平台验证，请在官网处理后重试验证收藏。' };
      }
      if (row.success === false || code != null && !['0', '200', ''].includes(String(code))) {
        return { status: 'not_ready', message: '官网暂未确认收藏列表或收藏请求，请打开官网核对。' };
      }
      if (depth < 2) for (const key of ['data', 'result', 'error']) if (row[key] && typeof row[key] === 'object') queue.push({ value: row[key], depth: depth + 1 });
    }
    return null;
  };

  const readResponse = async (path, body, documentRead = false) => {
    if (!allowed()) return { ok: false, status: 'not_ready', message: '官网页面已切换，已停止收藏和回读，请重新连接。' };
    const controller = new AbortController();
    let timer;
    const timeout = new Promise(resolve => {
      timer = setTimeout(() => { controller.abort(); resolve({ ok: false, status: 'not_ready', message: '官网收藏读取超时，请核对官网后重试验证。' }); }, 7000);
    });
    const request = (async () => {
      try {
        const response = await fetch(origin + path + (documentRead ? '' : '?pdduid=' + (uid || '0')), {
          method: documentRead ? 'GET' : 'POST', credentials: 'same-origin', redirect: 'error',
          ...(documentRead ? {} : { headers: { 'Content-Type': 'application/json' }, body }), signal: controller.signal });
        if (!response.ok) return { ok: false, status: [401, 403, 429].includes(response.status) ? 'needs_user' : 'not_ready',
          message: [401, 403, 429].includes(response.status) ? '官网未允许本次收藏读取，请打开官网核对。' : '官网收藏接口暂不可用，请稍后核对。' };
        if (documentRead && response.url) {
          let final; try { final = new URL(response.url); } catch { return { ok: false, status: 'not_ready', message: '官网收藏页面地址不可确认，请打开官网核对。' }; }
          if (final.origin !== origin) return { ok: false, status: 'not_ready', message: '收藏读取没有返回同一官网页面，已停止。' };
          if (/\/(?:login|captcha|verification|verify|challenge)\b/i.test(final.pathname)) return { ok: false, status: 'needs_user', message: '官网收藏页要求登录或验证，请打开官网处理后重试验证。' };
          if (final.pathname !== '/likes.html') return { ok: false, status: 'not_ready', message: '官网没有返回商品收藏页，请打开官网核对。' };
        }
        const declaredLength = response.headers?.get?.('content-length');
        if (declaredLength && /^\d+$/.test(declaredLength) && BigInt(declaredLength) > BigInt(maxBytes)) {
          controller.abort();
          return { ok: false, status: 'not_ready', message: '官网收藏响应超出读取范围，请打开官网核对。' };
        }
        let source = '';
        if (response.body?.getReader) {
          const reader = response.body.getReader(), decoder = new TextDecoder();
          let bytes = 0;
          try {
            while (true) {
              const chunk = await reader.read();
              if (chunk.done) break;
              bytes += chunk.value.byteLength;
              if (bytes > maxBytes) { controller.abort(); void reader.cancel().catch(() => {}); return { ok: false, status: 'not_ready', message: '官网收藏响应超出读取范围，请打开官网核对。' }; }
              source += decoder.decode(chunk.value, { stream: true });
            }
            source += decoder.decode();
          } finally { reader.releaseLock?.(); }
        } else {
          source = await response.text();
          if (source.length > maxBytes || new TextEncoder().encode(source).byteLength > maxBytes) {
            controller.abort();
            return { ok: false, status: 'not_ready', message: '官网收藏响应超出读取范围，请打开官网核对。' };
          }
        }
        if (documentRead) return { ok: true, source };
        // Preserve ID bytes before JSON.parse, including numeric long-ID tokens.
        const lossless = source.replace(/("(?:goods_id|goodsId|sku_id|skuId)"\s*:\s*)(\d{16,})(?=\s*[,}\]])/g, '$1"$2"');
        let data;
        try { data = JSON.parse(lossless); } catch { return { ok: false, status: 'not_ready', message: '官网收藏响应格式暂不可识别，请打开官网核对。' }; }
        const issue = platformIssue(data);
        return issue ? { ok: false, ...issue } : { ok: true, data };
      } catch {
        return { ok: false, status: 'not_ready', message: '官网收藏连接未完成，请打开官网核对后重试验证。' };
      }
    })();
    try { return await Promise.race([request, timeout]); } finally { clearTimeout(timer); }
  };
  const post = (path, body) => readResponse(path, body);

  const inspectList = data => {
    let visited = 0, recognized = Array.isArray(data), found = false, skuObserved = false, conflicted = false;
    const id = value => typeof value === 'number' && !Number.isSafeInteger(value) ? '' : positiveId(String(value ?? '')) ? String(value) : '';
    const ownId = (row, keys) => {
      const values = keys.filter(key => Object.prototype.hasOwnProperty.call(row, key)).map(key => id(row[key]));
      if (!values.length || values.some(value => !value) || new Set(values).size !== 1) {
        if (values.includes(goodsId) && keys[0] === 'goods_id') conflicted = true;
        return '';
      }
      return values[0];
    };
    const walk = (node, depth, collection) => {
      if (depth > 7 || ++visited > 2500 || !node || typeof node !== 'object') return;
      if (Array.isArray(node)) {
        for (const row of node.slice(0, 100)) walk(row, depth + 1, true);
        return;
      }
      const gid = ownId(node, ['goods_id', 'goodsId']);
      const flags = ['is_fav', 'isFav', 'is_favorite', 'isFavorite'].filter(key => Object.prototype.hasOwnProperty.call(node, key)).map(key => node[key]);
      const explicitlyFavorite = flags.some(value => value === true || value === 1 || value === '1');
      const explicitlyNotFavorite = flags.some(value => value === false || value === 0 || value === '0');
      if (gid && (collection || explicitlyFavorite)) {
        recognized = true;
        if (gid === goodsId && !explicitlyNotFavorite) { found = true; skuObserved ||= ownId(node, ['sku_id', 'skuId']) === skuId; }
      }
      for (const [key, child] of Object.entries(node).slice(0, 80)) {
        if (/^(?:request|request_params|params|query|trace|debug|recommendations|recommend|suggestions|ads?|orders?|addresses?|user|account)$/i.test(key)) continue;
        if (!child || typeof child !== 'object') continue;
        const isList = /^(?:goods(?:_?list|_?set)?|fav(?:orite)?(?:_?goods)?(?:_?list)?|items|list|rows)$/i.test(key) || ['data', 'result'].includes(key);
        if (isList && Array.isArray(child)) recognized = true;
        // An ID echoed directly in an envelope is not a list record. Nested
        // objects inherit collection membership only from an actual row.
        walk(child, depth + 1, collection || isList && Array.isArray(child));
      }
    };
    walk(data, 0, false);
    return { recognized: recognized && !conflicted, found: found && !conflicted, skuObserved };
  };

  const inspectDocument = source => {
    let doc;
    try { doc = new DOMParser().parseFromString(source, 'text/html'); } catch { return { recognized: false }; }
    let visibleText = '';
    const body = doc.body?.cloneNode?.(true);
    if (body) {
      for (const node of body.querySelectorAll('script,style,noscript,[hidden],[aria-hidden="true"]')) node.remove();
      visibleText = body.textContent || '';
    } else visibleText = doc.body?.textContent || '';
    if (/登录|验证|安全校验|访问受限|验证码/.test(doc.title || '') ||
        /请(?:先|重新)登[录陆]|登[录陆]后(?:查看|继续|使用)|扫码登[录陆]|手机号登[录陆]|短信验证码|请完成(?:安全)?验证|滑块验证|安全验证|访问过于频繁|访问受限|verify you are human|complete.{0,20}captcha/i.test(visibleText.slice(0, 30000))) {
      return { recognized: false, blocked: true, status: 'needs_user', message: '官网收藏页要求登录或验证，请打开官网处理后重试验证。' };
    }
    const safeId = value => typeof value === 'number' && !Number.isSafeInteger(value) ? '' : positiveId(String(value ?? '')) ? String(value) : '';
    for (const script of [...doc.querySelectorAll('script:not([src])')].slice(0, 80)) {
      const text = script.textContent || '', match = /(?:window\s*\.\s*)?rawData\s*=\s*/.exec(text);
      if (!match) continue;
      const start = match.index + match[0].length;
      if (text[start] !== '{') continue;
      let depth = 0, quoted = false, escaped = false, end = -1;
      for (let i = start; i < text.length; i++) {
        const char = text[i];
        if (quoted) { if (escaped) escaped = false; else if (char === '\\') escaped = true; else if (char === '"') quoted = false; continue; }
        if (char === '"') quoted = true;
        else if (char === '{') depth++;
        else if (char === '}' && --depth === 0) { end = i + 1; break; }
      }
      if (end < 0) continue;
      let raw;
      try { raw = JSON.parse(text.slice(start, end).replace(/("(?:goods_id|goodsId|sku_id|skuId)"\s*:\s*)(\d{16,})(?=\s*[,}\]])/g, '$1"$2"')); } catch { continue; }
      const store = raw?.baseStore, goodsSet = store?.goodsSet;
      if (store?.isLogin === false || store?.is_login === false) return { recognized: false, blocked: true, status: 'needs_user', message: '官网收藏页要求登录，请打开官网处理后重试验证。' };
      if (!Array.isArray(goodsSet) && (!goodsSet || typeof goodsSet !== 'object')) continue;
      const entries = (Array.isArray(goodsSet) ? goodsSet : Object.values(goodsSet)).slice(0, 200);
      let found = false, skuObserved = false;
      for (const goods of entries) {
        if (!goods || typeof goods !== 'object' || safeId(goods.goodsId) !== goodsId) continue;
        found = true;
        if (Array.isArray(goods.mergePayList)) skuObserved ||= goods.mergePayList.slice(0, 1000).some(sku => sku && safeId(sku.skuId) === skuId && (sku.goodsId == null || safeId(sku.goodsId) === goodsId));
      }
      return { recognized: true, found, skuObserved, source: 'official_favorites_html', coverage: 'loaded_favorites_html', complete: false };
    }
    return { recognized: false };
  };

  const lookup = async () => {
    const document = await readResponse('/likes.html', null, true);
    if (!document.ok) return document;
    const html = inspectDocument(document.source);
    if (html.blocked) return { ok: false, status: html.status, message: html.message };
    if (html.recognized) return { ok: true, ...html };
    // Only a successful page without known SSR can use this read-only fallback.
    // Explicit login/verification, HTTP refusal and read limits stop above.
    const response = await post('/proxy/api/api/zenon/goods/fav_list', '{"page":1,"size":50,"scene_id":"fav_list"}');
    if (!response.ok) return response;
    const result = inspectList(response.data);
    if (!result.recognized) return { ok: false, status: 'not_ready', message: '官网收藏列表结构尚未确认，已停止自动收藏，请打开官网核对。' };
    return { ok: true, ...result, source: 'official_favorite_list', coverage: 'first_page_50', complete: false };
  };
  const verified = (lookup, alreadyFavorite) => ({ ...base(), status: 'read', verified: true, alreadyFavorite,
    favoriteState: 'observed', evidence: { kind: lookup.source || 'official_favorite_list', goodsId, skuObserved: lookup.skuObserved,
      capturedAt: new Date().toISOString(), sourceUrl: origin + '/likes.html', coverage: lookup.coverage || 'first_page_50', complete: false },
    message: alreadyFavorite ? '已从官网收藏列表确认该商品，无需重复收藏。' : '已从官网收藏列表确认该商品收藏成功。' });

  try {
    const before = await lookup();
    if (!before.ok) return { ...base(), status: before.status, message: before.message };
    if (before.found) return verified(before, true);
    if (verifyOnly) return { ...base(), status: 'not_ready', favoriteState: 'not_observed',
      message: '当前读取的收藏列表尚未确认该商品，请打开官网核对后重试验证；本次没有重复发送收藏。' };
    if (!allowed()) return { ...base(), status: 'not_ready', message: '官网页面已切换，未发送收藏请求。' };
    mutationAttempted = true;
    // Never coerce IDs to Number, and never retry this mutation inside the call.
    const mutation = await post('/proxy/api/api/zenon/goods/fav', '{"goods_id":' + goodsId + ',"sku_id":' + skuId + ',"amount":1,"channel":35,"scene_id":1001}');
    const after = await lookup();
    if (after.ok && after.found) return verified(after, false);
    if (after.status === 'needs_user' || mutation.status === 'needs_user') return { ...base(), status: 'needs_user', favoriteState: 'unknown',
      message: '官网暂未允许确认收藏，请打开官网核对并处理提示；之后仅重试验证，不重复发送收藏。' };
    return { ...base(), status: 'unknown', favoriteState: 'unknown',
      message: '已尝试发送收藏，但尚未从官网收藏列表确认结果。请打开官网核对后重试验证，不会重复发送收藏。' };
  } catch {
    return { ...base(), status: mutationAttempted ? 'unknown' : 'not_ready', favoriteState: mutationAttempted ? 'unknown' : 'not_observed',
      message: mutationAttempted ? '收藏结果未知，请打开官网核对后仅重试验证。' : '收藏列表读取暂未完成，未发送收藏请求。' };
  }
}
