/**
 * Read-only, self-contained MAIN-world search reader. Search results identify
 * products only: each concrete SKU, price and package still needs a separate read.
 */
export async function readPddSearchPage({query,fetchDocument=false}={}) {
  function collectPddPromotions(record,source='explicit_promotion_fields'){
    const read=(object,key)=>{try{return Object.getOwnPropertyDescriptor(object,key)?.value;}catch{return undefined;}};
    const fields=['promotionTags','promotion_tags','tagList','tag_list','variedTagsList','varied_tags_list','propertyTagList','property_tag_list','prefixIcons','prefix_icons','pricePrefixInfo','price_prefix_info','priceInfo','price_info','activityTags','activity_tags','serviceTags','service_tags','tags'];
    const textKeys=new Set(['text','name','title','label','content','desc','description','value','alt','altText','tagText','tag_text','tagName','tag_name','tagDesc','tag_desc','displayText','display_text','contentText','content_text','htmlText','html_text','prefixText','prefix_text']);
    const childKeys=new Set(['children','parts','spans','items','list','tags','tagList','tag_list','contents']);
    const imageKeys=['url','imageUrl','image_url','imgUrl','img_url','iconUrl','icon_url'];
    const seen=new WeakSet(),tags=[],observed=[];let visited=0,unknownBadgeCount=0,truncated=false;
    const normalize=value=>value.normalize('NFKC').replace(/<[^>]{0,300}>/g,'').replace(/&nbsp;|&#160;/gi,' ').replace(/&#(?:x([0-9a-f]{1,6})|([0-9]{1,7}));/gi,(_,hex,dec)=>{const n=parseInt(hex||dec,hex?16:10);return n>0&&n<=0x10ffff?String.fromCodePoint(n):'';}).replace(/\s+/g,' ').trim();
    const looksUrl=value=>typeof value==='string'&&/^(?:[a-z][a-z\d+.-]*:|\/\/)/i.test(value.trim());
    const add=value=>{
      if(typeof value!=='string'||!value.trim())return false;
      if(looksUrl(value)){unknownBadgeCount++;return false;}
      if(value.length>500)truncated=true;
      const text=normalize(value.slice(0,500));
      if(!text||/^#[\da-f]{3,8}$/i.test(text)||/^\d+(?:\.\d+)?(?:px|%)?$/.test(text))return false;
      if(tags.length>=60){truncated=true;return true;}
      const bounded=text.slice(0,180);if(text.length>180)truncated=true;
      if(!tags.includes(bounded))tags.push(bounded);return true;
    };
    const walk=(value,depth)=>{
      if(typeof value==='string')return add(value);
      if(!value||typeof value!=='object')return false;
      if(depth>6||visited>=180){truncated=true;return false;}
      if(seen.has(value))return false;seen.add(value);visited++;
      let readable=false;const fragmentStart=tags.length;
      if(Array.isArray(value)){
        if(value.length>40)truncated=true;
        for(let index=0;index<Math.min(value.length,40);index++)readable=walk(read(value,String(index)),depth+1)||readable;
        return readable;
      }
      let keys;try{keys=Object.keys(value).slice(0,80);}catch{return false;}
      for(const key of keys)if(textKeys.has(key)||childKeys.has(key))readable=walk(read(value,key),depth+1)||readable;
      // Join rendering fragments only inside one explicit label, never across unrelated tags.
      if(keys.some(key=>['children','parts','spans','contents'].includes(key))){
        const fragments=tags.slice(fragmentStart).join('').replace(/\s+/g,'');
        for(const phrase of ['百亿补贴','多人团'])if(fragments.includes(phrase)&&!tags.some(text=>text.replace(/\s+/g,'').includes(phrase)))add(phrase);
      }
      if(!readable&&imageKeys.some(key=>looksUrl(read(value,key))))unknownBadgeCount++;
      return readable;
    };
    if(record&&typeof record==='object')for(const field of fields){
      const value=read(record,field);if(value==null)continue;observed.push(field);walk(value,0);
    }
    // Preserve text-only evidence when a goods-only API snapshot is parsed again.
    const inherited=record&&read(record,'promotionEvidence');
    if(inherited&&typeof inherited==='object'){
      const unknown=read(inherited,'unknownBadgeCount');if(Number.isSafeInteger(unknown)&&unknown>0)unknownBadgeCount+=Math.min(unknown,180);
      if(read(inherited,'truncated')===true)truncated=true;
    }
    const names=record&&typeof record==='object'?['name','title','goodsName','goods_name','goodsTitle','goods_title','short_name','spec','specName','spec_name','skuName','sku_name'].map(key=>read(record,key)).filter(value=>typeof value==='string').map(value=>normalize(value.slice(0,1000))):[];
    const all=tags.concat(names),exclusionReasons=[];
    for(const phrase of ['百亿补贴','多人团'])if(all.some(text=>text.replace(/\s+/g,'').includes(phrase)))exclusionReasons.push('包含“'+phrase+'”标签');
    const inheritedFields=read(inherited||{},'fields'),hadOriginalEvidence=Array.isArray(inheritedFields);
    const evidenceFields=[...new Set((hadOriginalEvidence?inheritedFields.filter(value=>typeof value==='string'&&fields.includes(value)):[]).concat(observed.filter(field=>!hadOriginalEvidence||!['promotionTags','promotion_tags'].includes(field))))].slice(0,40);
    return {promotionTags:tags.slice(0,60),exclusionReasons,promotionEvidence:{source:typeof source==='string'?source.slice(0,80):'explicit_promotion_fields',fields:evidenceFields,textOnly:true,unknownBadgeCount:Math.min(unknownBadgeCount,360),truncated,verified:exclusionReasons.length>0||evidenceFields.length>0&&!unknownBadgeCount&&!truncated}};
  }

  const origin='https://mobile.yangkeduo.com';
  const normalize=value=>typeof value==='string'?value.normalize('NFKC').replace(/\s+/g,' ').trim():'';
  const cleanQuery=normalize(query);
  const sourceUrl=origin+'/search_result.html?search_key='+encodeURIComponent(cleanQuery);
  const diagnostics={jsonRoots:0,visitedNodes:0,recognizedRecords:0,unsafeIds:0,conflicts:0,anchorCount:0};
  let truncated=false,sourceKind=fetchDocument?'official_search_document':'official_search_page';
  const result=(status,message,products=[])=>({status,query:cleanQuery,products,sourceUrl,sourceKind,message,
    coverage:{complete:false,scope:'currently_loaded_search_products',usableProductCount:products.length,truncated},diagnostics});
  if(typeof query!=='string'||!cleanQuery||cleanQuery.length>120||/[\u0000-\u001f\u007f]/.test(query))return result('not_ready','请输入有效的商品搜索词');
  let current;
  try{current=new URL(location.href);}catch{return result('not_ready','官网页面地址尚未确认');}
  if(current.origin!==origin||current.username||current.password||current.port)return result('not_ready','只能读取当前拼多多官网的搜索结果');
  if(fetchDocument?!/^\/(?:likes|goods\d*|search_result)\.html$/.test(current.pathname):current.pathname!=='/search_result.html')return result('not_ready','请在官网搜索页读取商品');
  const queryMatches=url=>url.origin===origin&&url.pathname==='/search_result.html'&&url.searchParams.getAll('search_key').length===1&&normalize(url.searchParams.get('search_key'))===cleanQuery;
  if(!fetchDocument&&!queryMatches(current))return result('not_ready','搜索页面与当前商品搜索词不一致，请重新搜索');

  const id=(value,zero=false)=>{
    if(typeof value==='number'&&!Number.isSafeInteger(value))return '';
    if(typeof value!=='number'&&typeof value!=='string')return '';
    const text=String(value);
    return /^\d+$/.test(text)&&(zero||!/^0+$/.test(text))?text:'';
  };
  const property=(object,name)=>{
    try{return Object.getOwnPropertyDescriptor(object,name)?.value;}catch{return undefined;}
  };
  const parseJson=text=>{
    if(typeof text!=='string'||!text.trim()||text.length>5000000)return null;
    try{return JSON.parse(text.replace(/("(?:goodsID|goodsId|goods_id|groupId|group_id)"\s*:\s*)(\d{16,})(?=\s*[,}\]])/g,'$1"$2"'));}catch{return null;}
  };
  const imageUrl=value=>{
    if(typeof value!=='string'||value.length>2048)return '';
    try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password&&!url.port&&(url.hostname==='pddpic.com'||url.hostname.endsWith('.pddpic.com'))?url.href:'';}catch{return '';}
  };
  let doc=globalThis.document,roots=[];
  if(fetchDocument){
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
    try{
      const response=await fetch(sourceUrl,{method:'GET',credentials:'same-origin',mode:'same-origin',redirect:'error',cache:'no-store',signal:controller.signal});
      if(response.status===401)return result('login_required','请在拼多多官网完成登录后重试');
      if(response.status===403||response.status===429)return result('needs_user','官网暂时限制搜索，请打开官网处理提示后重试');
      if(!response.ok)return result('not_ready','官网搜索暂不可用，请稍后重试');
      if(response.url){
        let returned;try{returned=new URL(response.url);}catch{return result('not_ready','搜索响应地址无法确认');}
        if(returned.origin===origin&&returned.pathname==='/login.html')return result('login_required','请在拼多多官网完成登录后重试');
        if(!queryMatches(returned))return result('needs_user','官网搜索跳转到了其他页面，请打开官网核对');
      }
      const declaredSize=Number(response.headers?.get?.('content-length')||0);
      if(declaredSize>5000000)return result('not_ready','搜索页面超出读取范围，请打开官网核对');
      const html=await response.text();
      if(typeof html!=='string'||html.length>5000000)return result('not_ready','搜索页面超出读取范围，请打开官网核对');
      if(typeof DOMParser!=='function')return result('not_ready','当前环境无法读取官网搜索页面');
      doc=new DOMParser().parseFromString(html,'text/html');
    }catch{return result('not_ready','官网搜索尚未完成，请稍后重试');}finally{clearTimeout(timer);}
  }else{
    const raw=property(globalThis.window||{},'rawData');
    if(raw&&typeof raw==='object')roots.push(raw);
    else if(typeof raw==='string'){const parsed=parseJson(raw);if(parsed&&typeof parsed==='object')roots.push(parsed);}
  }
  if(!doc)return result('not_ready','搜索页面尚未加载');
  // Extract JSON values only. Assignment code, JSON.parse calls and functions
  // are never evaluated, including in an inert fetched HTML document.
  const scripts=[...(doc.querySelectorAll?.('script')||[])];
  if(scripts.length>80)truncated=true;
  for(const script of scripts.slice(0,80)){
    const text=script.textContent||'';if(typeof text!=='string'||text.length>5000000)continue;
    const type=script.getAttribute?.('type')||script.type||'';
    if(type.toLowerCase()==='application/json'){
      const parsed=parseJson(text);if(parsed&&typeof parsed==='object')roots.push(parsed);continue;
    }
    const assignment=/(?:window\s*\.\s*)?rawData\s*=\s*/.exec(text);
    if(!assignment)continue;
    const start=assignment.index+assignment[0].length;
    if(!['{','['].includes(text[start]))continue;
    let depth=0,quoted=false,escaped=false,end=-1;
    for(let index=start;index<text.length;index++){
      const char=text[index];
      if(quoted){if(escaped)escaped=false;else if(char==='\\')escaped=true;else if(char==='"')quoted=false;continue;}
      if(char==='"')quoted=true;else if(char==='{'||char==='[')depth++;else if((char==='}'||char===']')&&--depth===0){end=index+1;break;}
    }
    if(end<0)continue;
    const parsed=parseJson(text.slice(start,end));if(parsed&&typeof parsed==='object')roots.push(parsed);
  }
  diagnostics.jsonRoots=roots.length;
  let pageText=typeof doc.body?.innerText==='string'?doc.body.innerText:'';
  if(fetchDocument&&!pageText){
    for(const node of [...(doc.querySelectorAll?.('script,style')||[])])node.remove?.();
    pageText=doc.body?.textContent||'';
  }
  pageText=pageText.slice(0,20000);
  const title=String(doc.title||'');
  if(/安全验证|人机验证|滑块验证|请完成验证|请验证后|访问过于频繁/.test(title+' '+pageText))return result('needs_user','官网要求验证，请打开官方标签页处理后重试');
  if(/(?:用户|账号|帐号|扫码|手机)登录/.test(title)||doc.querySelector?.('input[type="password"]'))return result('login_required','请在拼多多官网完成登录后重试');

  // Observed official search schema: only these rows are the current SSR search
  // results. dataMap and recommendation modules can contain duplicate or stale
  // products, so they must not compete with this authoritative list.
  let knownList=false;
  for(const root of roots){
    const data=property(property(property(root,'stores'),'store'),'data');
    const ssr=property(data,'ssrListData'),list=property(ssr,'list');
    if(!Array.isArray(list))continue;
    for(const key of [property(data,'searchKey'),property(ssr,'searchKey')]){
      if(key!=null&&(typeof key!=='string'||normalize(key)!==cleanQuery))return result('not_ready','搜索数据与当前商品搜索词不一致，请重新搜索');
    }
    knownList=true;diagnostics.schema='stores.store.data.ssrListData.list';
    if(list.length>1000)truncated=true;
    roots=list.slice(0,1000);break;
  }

  const products=new Map(),conflicts=new Set();
  const add=(product)=>{
    if(conflicts.has(product.goodsId))return;
    const old=products.get(product.goodsId);
    if(old&&(old.name!==product.name||(old.groupId&&product.groupId&&old.groupId!==product.groupId))){products.delete(product.goodsId);conflicts.add(product.goodsId);diagnostics.conflicts=conflicts.size;return;}
    if(old){for(const key of ['groupId','imageUrl','shopName'])if(!old[key]&&product[key])old[key]=product[key];old.promotionTags=[...new Set([...(old.promotionTags||[]),...(product.promotionTags||[])])];old.exclusionReasons=[...new Set([...(old.exclusionReasons||[]),...(product.exclusionReasons||[])])];old.promotionEvidence.unknownBadgeCount+=product.promotionEvidence.unknownBadgeCount;old.promotionEvidence.verified=old.exclusionReasons.length>0||old.promotionEvidence.verified&&product.promotionEvidence.verified;return;}
    if(products.size>=500){truncated=true;return;}
    products.set(product.goodsId,product);
  };
  const seen=new WeakSet(),stack=roots.slice().reverse().map(value=>({value,depth:0}));
  while(stack.length&&diagnostics.visitedNodes<15000){
    const {value,depth}=stack.pop();if(!value||typeof value!=='object'||seen.has(value))continue;
    seen.add(value);diagnostics.visitedNodes++;
    const declaredIds=['goodsID','goodsId','goods_id'].map(key=>property(value,key)).filter(value=>value!=null),rawId=declaredIds[0];
    const name=[property(value,'goodsName'),property(value,'goods_name'),property(value,'short_name')].find(v=>typeof v==='string'&&v.trim());
    if(rawId!=null&&name){
      const goodsId=id(rawId);if(!goodsId||declaredIds.some(value=>id(value)!==goodsId))diagnostics.unsafeIds++;
      else{
        diagnostics.recognizedRecords++;
        const product={goodsId,name:normalize(name).slice(0,500),detailUrl:origin+'/goods.html?goods_id='+goodsId,...collectPddPromotions(value,'official_search_tags')};
        const group=id(property(value,'groupId')??property(value,'group_id'),true);if(group)product.groupId=group;
        const photo=[property(value,'imgUrl'),property(value,'thumbUrl'),property(value,'thumb_url'),property(value,'hdThumbUrl'),property(value,'imageUrl')].map(imageUrl).find(Boolean);if(photo)product.imageUrl=photo;
        const shop=[property(value,'mallName'),property(value,'mall_name')].find(v=>typeof v==='string'&&v.trim());if(shop)product.shopName=normalize(shop).slice(0,150);
        add(product);
      }
    }
    if(knownList)continue;
    if(depth>=18){truncated=true;continue;}
    let keys;
    try{keys=Array.isArray(value)?Array.from({length:Math.min(value.length,1000)},(_,i)=>String(i)):Object.keys(value).slice(0,200);}catch{continue;}
    if(Array.isArray(value)&&value.length>1000)truncated=true;
    for(let index=keys.length-1;index>=0;index--){
      const key=keys[index];if(/token|user|account|address|phone|receiver|cookie|session|login/i.test(key))continue;
      const child=property(value,key);if(child&&typeof child==='object')stack.push({value:child,depth:depth+1});
    }
  }
  if(stack.length)truncated=true;
  // A live search may expose product identity only in links. Do not let short
  // DOM labels replace richer JSON product names or manufacture a SKU/price.
  if(!products.size&&!knownList){
    const anchors=[...(doc.querySelectorAll?.('a[href]')||[])];
    diagnostics.anchorCount=Math.min(anchors.length,3000);if(anchors.length>3000)truncated=true;
    for(const anchor of anchors.slice(0,3000)){
      if(anchor.hidden||anchor.closest?.('[hidden], [aria-hidden="true"]'))continue;
      if(!fetchDocument&&typeof anchor.getClientRects==='function'&&!anchor.getClientRects().length)continue;
      if(!fetchDocument&&typeof globalThis.getComputedStyle==='function'){const style=getComputedStyle(anchor);if(style.display==='none'||style.visibility==='hidden'||style.visibility==='collapse')continue;}
      let url;try{url=new URL(anchor.getAttribute?.('href'),sourceUrl);}catch{continue;}
      if(url.origin!==origin||!/^\/goods\d*\.html$/.test(url.pathname)||url.searchParams.getAll('goods_id').length!==1)continue;
      const goodsId=id(url.searchParams.get('goods_id'));if(!goodsId||conflicts.has(goodsId))continue;
      const img=anchor.querySelector?.('img');
      const name=normalize(anchor.getAttribute?.('title')||anchor.getAttribute?.('aria-label')||img?.getAttribute?.('alt')||anchor.textContent);
      if(name.length<2||/^(?:商品详情|查看详情|立即购买|点击查看|去看看|商品)$/.test(name))continue;
      const product={goodsId,name:name.slice(0,500),detailUrl:origin+'/goods.html?goods_id='+goodsId,...collectPddPromotions({name,tagList:[anchor.textContent||'']},'official_search_visible_text')};
      const photo=imageUrl(img?.getAttribute?.('src'));if(photo)product.imageUrl=photo;
      add(product);
    }
    if(products.size)sourceKind=fetchDocument?'official_search_document_links':'official_search_visible_links';
  }
  if(!products.size)return result('not_ready','未读取到归属明确的搜索商品；请打开官网确认搜索已加载，不能据此判断没有同款');
  return result('read','已读取当前搜索商品，具体SKU与包装仍需核对',[...products.values()]);
}
