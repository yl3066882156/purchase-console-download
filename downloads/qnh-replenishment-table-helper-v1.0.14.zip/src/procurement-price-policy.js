/** Exact procurement-cost comparison; reference/search prices never become payable prices. */
import {validateCheckoutPriceSource,isFreshCheckoutPrice} from './draft-defaults.js';

const str=value=>typeof value==='string'?value.trim():'';
const gcd=(a,b)=>{while(b)[a,b]=[b,a%b];return a;};
const fraction=(n,d=1n)=>{const g=gcd(n,d);return {n:n/g,d:d/g};};
function decimal(value,{zero=false}={}){
 const s=str(value);if(s.length>100||!/^\d+(?:\.\d+)?$/.test(s))return null;
 const [a,b='']=s.split('.'),n=BigInt(a+b),d=10n**BigInt(b.length);return n>0n||zero&&n===0n?fraction(n,d):null;
}
const multiply=(a,b)=>fraction(a.n*b.n,a.d*b.d);
const divide=(a,b)=>fraction(a.n*b.d,a.d*b.n);
const compare=(a,b)=>a.n*b.d<b.n*a.d?-1:a.n*b.d>b.n*a.d?1:0;
function decimalText(value,maxPlaces=20){
 let out=String(value.n/value.d),r=value.n%value.d;if(!r)return {value:out,exact:true};
 out+='.';for(let i=0;i<maxPlaces&&r;i++){r*=10n;out+=String(r/value.d);r%=value.d;}
 return {value:out.replace(/0+$/,'').replace(/\.$/,''),exact:r===0n};
}
function finiteText(value){
 let d=value.d,twos=0,fives=0;while(d%2n===0n){d/=2n;twos++;}while(d%5n===0n){d/=5n;fives++;}
 return decimalText(value,d===1n?Math.max(twos,fives):20);
}
function fixed(value,places,mode){
 const scale=10n**BigInt(places),amount=mode==='half_up'?(value.n*scale*2n+value.d)/(2n*value.d):value.n*scale/value.d;
 return places?`${amount/scale}.${String(amount%scale).padStart(places,'0')}`:String(amount);
}
function normalizedPrice(value){const parsed=decimal(value);return parsed?finiteText(parsed).value:'';}
const historicalRow=row=>{
 if(row?.sourceKind!=='native_last_purchase_reference')return false;
 const m=str(row.purchaseTimeText).match(/^(\d{4})[.\/-](\d{1,2})[.\/-](\d{1,2})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);if(!m)return false;
 const [year,month,day]=m.slice(1,4).map(Number),date=new Date(Date.UTC(year,month-1,day));
 return date.getUTCFullYear()===year&&date.getUTCMonth()===month-1&&date.getUTCDate()===day&&Number(m[4]||0)<24&&Number(m[5]||0)<60&&Number(m[6]||0)<60;
};
const historicalReference=reference=>reference?.sourceKind==='native_last_purchase_reference'&&(Array.isArray(reference.rows)&&reference.rows.length?reference.rows.every(historicalRow):historicalRow(reference));

/** A historical purchase cap is available before any candidate quote exists. */
export function procurementPriceLimit({reference,maxIncreasePercent='0',purchasePriceDecimals='2'}={}){
 const percent=decimal(maxIncreasePercent,{zero:true}),placesText=str(purchasePriceDecimals),baseline=decimal(reference?.priceYuan);
 if(!percent||compare(percent,{n:100n,d:1n})>0||!/^[0-6]$/.test(placesText)||reference?.status!=='read'||!baseline||!str(reference.unit)||!/^\d{8,14}$/.test(str(reference.upc))||!historicalReference(reference))return null;
 if(Array.isArray(reference.rows)&&reference.rows.some(row=>row.upc!==reference.upc||row.unit!==reference.unit||!decimal(row.priceYuan)||compare(decimal(row.priceYuan),baseline)!==0))return null;
 const cap=multiply(baseline,fraction(100n*percent.d+percent.n,100n*percent.d));
 return {referenceYuan:finiteText(baseline).value,maxAllowedExactYuan:finiteText(cap).value,maxAllowedYuan:fixed(cap,Number(placesText),'floor')};
}

/** Multiple prices/units remain ambiguous; no "latest" or cheapest row is guessed. */
export function selectReferenceForTarget(readResults,profile={}){
 const upc=str(profile.upc||profile.backendUpc),unit=str(profile.unit||profile.backendUnit),reads=Array.isArray(readResults)?readResults:[readResults];
 const rows=[];
 for(const r of reads){
  if(!r||r.upc!==upc||!['read','ambiguous'].includes(r.status))continue;
  const candidates=Array.isArray(r.rows)&&r.rows.length?r.rows:r.status==='read'?[r]:[];
  for(const row of candidates){
   if(row.upc&&row.upc!==upc)continue;
   const next={...row,upc,priceYuan:normalizedPrice(row.priceYuan),unit:str(row.unit),sourceKind:row.sourceKind||r.sourceKind||'',purchaseTimeText:row.purchaseTimeText||r.purchaseTimeText||row.evidence?.purchaseTimeText||'',lastPurchaseAt:row.lastPurchaseAt||r.lastPurchaseAt||row.evidence?.lastPurchaseAt||'',sourceUrl:row.sourceUrl||r.sourceUrl||row.evidence?.sourceUrl||'',capturedAt:row.capturedAt||r.capturedAt||row.evidence?.capturedAt||'',sourceTabId:row.sourceTabId??r.sourceTabId??null};
   if(!rows.some(old=>JSON.stringify(old)===JSON.stringify(next)))rows.push(next);
  }
 }
 const purchaseTimes=[...new Set(rows.map(row=>row.purchaseTimeText).filter(Boolean))];
 const base={upc,unit,priceYuan:'',rows,sourceKind:'native_last_purchase_reference',purchaseTimeText:purchaseTimes.length===1?purchaseTimes[0]:'',lastPurchaseAt:purchaseTimes.length===1?rows[0]?.lastPurchaseAt||'':'',purchaseTimes,capturedAt:rows[0]?.capturedAt||''};
 if(!/^\d{8,14}$/.test(upc)||!unit)return {...base,status:'ambiguous',message:'当前商品UPC或后台单位未明确，不能选择采购价基准'};
 if(reads.some(r=>r?.upc===upc&&r.status==='ambiguous'&&Array.isArray(r.issues)&&r.issues.length))return {...base,status:'ambiguous',message:'同UPC的原生参考行存在身份或采购价证据冲突，请先明确选择参考行'};
 if(!rows.length)return {...base,status:'not_found',message:'尚未读取到当前UPC的补货参考采购价'};
 if(rows.some(row=>!historicalRow(row)))return {...base,status:'ambiguous',message:'尚未明确读取最近补货信息中的上次采购时间与单价，当前采购价不能替代'};
 if(rows.some(row=>!row.priceYuan||!row.unit||row.unit!==unit))return {...base,status:'ambiguous',message:'同UPC的采购价单位存在未知或冲突，请明确选择同后台单位的参考行'};
 if(new Set(rows.map(row=>row.priceYuan)).size!==1)return {...base,status:'ambiguous',message:'同UPC有多个门店或供应商采购价，请选择本次要对照的一行，未自动取最低价或推测最近价'};
 return {...base,status:'read',priceYuan:rows[0].priceYuan,unit:rows[0].unit,sourceUrl:rows[0].sourceUrl,sourceTabId:rows[0].sourceTabId,
  message:rows.length===1?'已确认本次上次采购单价':'当前已读同UPC的上次采购单价与单位一致'};
}

/**
 * Actual single-PDD-item payable × left PDD ratio ÷ right backend ratio.
 * Both the exact cost and the native half-up field value must respect the exact cap.
 */
export function evaluateProcurementPrice({candidate={},reference,ratioQnh,ratioPdd='1',maxIncreasePercent='0',purchasePriceDecimals='2',profile,now=Date.now(),compareReference=true}={}){
 const percent=decimal(maxIncreasePercent,{zero:true}),placesText=str(purchasePriceDecimals),places=/^[0-6]$/.test(placesText)?Number(placesText):null;
 const expectedUpc=str(profile?.upc||profile?.backendUpc||candidate.backendUpc),expectedUnit=str(profile?.unit||profile?.backendUnit||candidate.backendUnit||reference?.unit);
 const base={status:'unpriced',unitCostYuan:'',unitCostDisplayYuan:'',unitCostExact:false,unitCostNumerator:'',unitCostDenominator:'',payableYuan:'',referenceYuan:'',maxAllowedYuan:'',maxAllowedExactYuan:'',maxIncreasePercent:str(maxIncreasePercent),unit:expectedUnit,capturedAt:'',reason:'尚未读取所选SKU的有效实际付款价'};
 const proof=validateCheckoutPriceSource(candidate);
 if(!proof.valid||!isFreshCheckoutPrice(candidate,now))return {...base,reason:proof.valid?'该SKU实价已过期，请重新读取':'尚未读取所选SKU的有效实际付款价：'+proof.message};
 const payable=decimal(proof.value),left=decimal(ratioPdd),right=decimal(ratioQnh??candidate.matching?.ratioQnh);
 if(!payable||!left||!right||places===null)return {...base,capturedAt:proof.source.capturedAt,reason:'下单比例或原生采购价精度未明确，不能换算后台单位实价'};
 const cost=divide(multiply(payable,left),right),unitText=finiteText(cost),display=fixed(cost,places,'half_up');
 const calculated={...base,status:'unknown_reference',unitCostYuan:unitText.value,unitCostDisplayYuan:display,unitCostExact:unitText.exact,unitCostNumerator:String(cost.n),unitCostDenominator:String(cost.d),payableYuan:finiteText(payable).value,capturedAt:proof.source.capturedAt,
  ratioPdd:finiteText(left).value,ratioQnh:finiteText(right).value,purchasePriceDecimals:placesText,reason:'补货参考采购价或单位尚未确认，不能校验价格上限'};
 if(!compareReference)return {...calculated,status:decimal(display)?.n>0n?'eligible':'unpriced',comparisonEnabled:false,reason:'已换算所选SKU的后台单位实付价；不比较历史采购价'};
 if(!percent||compare(percent,{n:100n,d:1n})>0)return {...calculated,reason:'允许上浮比例必须是0至100的明确百分数'};
 const baseline=decimal(reference?.priceYuan);
 if(reference?.status!=='read'||!baseline||!str(reference.unit)||!expectedUnit||reference.unit!==expectedUnit)return calculated;
 if(!historicalReference(reference))return {...calculated,reason:'未读取最近补货信息中的上次采购时间与单价，不能使用当前采购价作为预算'};
 if(!/^\d{8,14}$/.test(str(reference.upc))||expectedUpc&&reference.upc!==expectedUpc)return {...calculated,reason:'补货参考UPC与当前牵牛花商品不一致'};
 const limit=procurementPriceLimit({reference,maxIncreasePercent,purchasePriceDecimals});
 if(!limit)return {...calculated,reason:'上次采购基准、原生精度或历史行证据存在冲突，不能计算预算上限'};
 const cap=decimal(limit.maxAllowedExactYuan),rounded=decimal(display,{zero:true});
 const fields={...calculated,...limit,referencePurchaseTimeText:reference.purchaseTimeText||'',referenceLastPurchaseAt:reference.lastPurchaseAt||''};
 if(!rounded||rounded.n<=0n)return {...fields,status:'unpriced',reason:'后台单位价格按原生精度舍入后为0，不能代填'};
 if(compare(cost,cap)>0||compare(rounded,cap)>0)return {...fields,status:'over_limit',reason:compare(cost,cap)<=0?'原生采购价舍入后超过允许上限，不能按较低的未舍入值放行':'后台单位实际付款价超过补货参考允许上限'};
 return {...fields,status:'eligible',reason:'后台单位实价及原生代填价格均未超过补货参考允许上限'};
}

/** Stable exact ordering; callers should only label eligible current quotes recommended. */
export function sortProcurementCandidates(candidates=[]){
 const priority={eligible:0,over_limit:1,unknown_reference:2,unpriced:3};
 const rational=cost=>{
  if(typeof cost?.unitCostNumerator==='string'&&/^\d+$/.test(cost.unitCostNumerator)&&typeof cost.unitCostDenominator==='string'&&/^[1-9]\d*$/.test(cost.unitCostDenominator))return {n:BigInt(cost.unitCostNumerator),d:BigInt(cost.unitCostDenominator)};
  return decimal(cost?.unitCostYuan);
 };
 return (Array.isArray(candidates)?candidates:[]).map((candidate,index)=>({candidate,index})).sort((a,b)=>{
  const x=a.candidate.cost,y=b.candidate.cost,rank=(priority[x?.status]??3)-(priority[y?.status]??3);if(rank)return rank;
  const p=rational(x),q=rational(y);if(p&&q)return compare(p,q)||a.index-b.index;if(p||q)return p?-1:1;return a.index-b.index;
 }).map(row=>row.candidate);
}
