import {findExistingCartonUnit} from './qnh-carton-unit.js';
import {requestQnhCartonApi,parseCartonJson} from './qnh-carton-runtime.js';
import {selectQnhCartonUnit} from './qnh-carton-select.js';
import {resolveFillQuantity} from './draft-defaults.js';
import {targetIdentity} from './auto-fill.js';

const fail=message=>Object.assign(new Error(message),{code:'CARTON_SELECTION_CHANGED'});
/** Select an existing unit after the five relation fields have been filled.
 * Only products/units APIs may be read. No unit creation or master saves.
 */
export async function selectExistingCartonForDraft({api,send,tab,snapshot,candidate}){
 const quantity=resolveFillQuantity(candidate?.spec,snapshot.backendSpec||'');
 if(quantity.status!=='matched')return {status:'skipped',message:'包装单位不明确，箱规请手动核对'};
 let token;
 try{
  const first=(await send(tab.id,{type:'QNH_INSPECT_EDITOR'})).snapshot;
  if(targetIdentity({...first,sourceTabId:tab.id})!==targetIdentity(snapshot))throw fail('当前商品或表单已变化，未选择箱规');
  const current=await api.tabs.sendMessage(tab.id,{type:'QNH_CARTON_GET_TARGET'},{frameId:0});
  if(!current?.ok||current.data?.target?.tenantId!==first.tenantId||current.data.target.upc!==first.backendUpc||!current.data.anchor)throw fail('箱规控件或关联商品未确认，请手动核对');
  const {target,anchor}=current.data;
  const guard=async()=>{
   const live=await api.tabs.get(tab.id);if(live.url!==tab.url)throw fail('页面已切换，未选择箱规');
   const read=await send(tab.id,{type:'QNH_INSPECT_EDITOR'});
   if(read.snapshot?.fingerprint!==first.fingerprint)throw fail('表单已被修改，未继续选择箱规');
   const c=await api.tabs.sendMessage(tab.id,{type:'QNH_CARTON_GET_TARGET'},{frameId:0});
   if(!c?.ok||c.data?.anchor!==anchor||c.data.target?.tenantId!==target.tenantId||c.data.target.upc!==target.upc)throw fail('箱规控件已切换，未继续选择');
  };
  const call=async(operation,body)=>{
   if(!['products','units'].includes(operation))throw fail('已有箱规匹配只允许读取');
   const outputs=await api.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},world:'MAIN',func:requestQnhCartonApi,args:[{operation,body}]});
   const result=outputs[0]?.result;if(!result?.ok||result.httpStatus<200||result.httpStatus>=300)throw fail('已有箱规读取失败，请手动核对');
   const json=parseCartonJson(result.text);if(![0,'0'].includes(json?.code)||json.success===false||!Object.hasOwn(json,'data'))throw fail('已有箱规接口未成功，请手动核对');
   await guard();return json.data;
  };
  const matched=await findExistingCartonUnit({target,quantity:quantity.quantity,packUnit:quantity.unit},{call,checkpoint:guard});
  if(matched.status!=='matched')return matched;
  await guard();const begun=await send(tab.id,{type:'QNH_BEGIN_CARTON_SELECTION',rowRef:first.rowRef,expectedFingerprint:first.fingerprint,anchor});token=begun.token;
  const outputs=await api.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},world:'MAIN',func:selectQnhCartonUnit,args:[{anchor,target,result:matched.result,deadline:Date.now()+6000}]});
  if(!outputs[0]?.result?.ok)throw fail(outputs[0]?.result?.message||'已有箱规未确认选中，请手动核对');
  const accepted=await send(tab.id,{type:'QNH_END_CARTON_SELECTION',token});token=null;
  return {...matched,status:'selected',snapshot:accepted.snapshot,message:'箱规已选中：'+matched.result.unitName+(quantity.quantity==='1'?'':'（'+quantity.quantity+matched.result.baseUnit+'/'+matched.result.unitName+'）')+'，下单比例保持不变'};
 }catch(error){
  if(token)await send(tab.id,{type:'QNH_ABORT_CARTON_SELECTION',token}).catch(()=>{});
  return {status:'needs_review',message:error.message||'箱规请手动核对'};
 }
}
