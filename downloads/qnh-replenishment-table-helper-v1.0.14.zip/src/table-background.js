import {classifyTab,createRouter} from './background.js';
const pddCommands=new Set([
 'GET_PDD_CATALOG','START_PDD_TAB_WORKSPACE','NAVIGATE_PDD_TAB_WORKSPACE',
 'SYNC_PDD_TAB_WORKSPACE','READ_PDD_FAVORITE_SPECS'
]);
const qnhCommands=new Set(['INSPECT_EDITOR','FILL_MAINTENANCE']);
const qnhUrl=raw=>{try{const u=new URL(raw);return u.origin==='https://qnh.meituan.com'&&['/home.html','/'].includes(u.pathname)?u:null;}catch{return null;}};
export function isReference(raw){return qnhUrl(raw)?.hash.split('?')[0]==='#/purchase/replenishment/refer';}
const contentFiles=['content/qnh.js','content/qnh-carton-ui.js','content/table-host.js'];
function installPageReconnect(api){
 const attach=async tab=>{
  if(!Number.isInteger(tab?.id)||!qnhUrl(tab.url))return;
  // The isolated content scripts have their own guards. Never navigate or
  // reload the merchant tab, so the native draft stays intact.
  await api.scripting.executeScript({target:{tabId:tab.id},files:contentFiles}).catch(()=>{});
 };
 api.runtime.onInstalled?.addListener(async ({reason})=>{
  if(!['install','update'].includes(reason))return;
  try{await Promise.all((await api.tabs.query({url:'https://qnh.meituan.com/*'})).map(attach));}catch{/* Tab closed or site access disabled. */}
 });
 api.action?.onClicked.addListener(attach);
}
const fail=m=>{throw new Error(m);};
export function installTableBackground(api){
 const pdd=createRouter(api),sessions=new Map();let fills=Promise.resolve();
 const sender={id:api.runtime.id,url:api.runtime.getURL('src/table-panel.js')};
 const listener=(m,s,reply)=>{
  if(m?.type!=='QRTH_REQUEST')return false;
  (async()=>{
   if(s.id!==api.runtime.id||s.frameId!==0||!Number.isInteger(s.tab?.id)||!isReference(s.url)||!m.token||!(pddCommands.has(m.command)||qnhCommands.has(m.command)))fail('仅允许当前补货参考浮层发起此操作');
   const id=s.tab.id,token=m.token;
   const sendPage=async message=>api.tabs.sendMessage(id,message,s.documentId?{documentId:s.documentId}:{frameId:0});
   const check=async()=>{
    const t=await api.tabs.get(id);
    if(!isReference(t.url))fail('补货参考已切换');
    const r=await sendPage({type:'QRTH_ELIGIBILITY'});
    if(!r?.data?.eligible||r.data.token!==token)fail('编辑抽屉已关闭或更换，请重新点击代填');
    return t;
   };
   await check();
   if(m.command==='SYNC_PDD_TAB_WORKSPACE'&&!m.payload?.refreshFavorites&&!m.payload?.advanceFavorites&&!m.payload?.stopFavoritesLoad)
    return pdd({type:'GET_PDD_CATALOG'},sender);
   if(m.command==='READ_PDD_FAVORITE_SPECS'&&m.payload?.requestedByUser!==true)fail('请在商品行点击「读取规格」。');
   if(pddCommands.has(m.command))return pdd({type:m.command,payload:m.payload},sender);
   const p={...(m.payload||{}),tabId:id};
   if(m.command==='FILL_MAINTENANCE'&&(p.snapshot?.sourceTabId!==id||p.snapshot?.routeMode!=='edit'||!isReference(p.snapshot?.nativeEditor?.routeKey)||p.draft?.manualPurchasePrice!==true||p.draft?.newCompletionConfirmed===true))fail('仅允许补货参考编辑，采购价必须手填');
   const key=id+':'+token;let route=sessions.get(key);
   if(!route){
    const scoped={runtime:api.runtime,storage:api.storage,scripting:{executeScript:async options=>{if(options.target.tabId!==id)fail('禁止跨标签页维护');await check();return api.scripting.executeScript(options);}},tabs:{get:tabId=>api.tabs.get(tabId),sendMessage:async(tabId,message)=>{
     if(tabId!==id)fail('禁止跨标签页维护');await check();
     if(message.type==='QNH_CARTON_GET_TARGET')return sendPage({type:'QRTH_CARTON_GET_TARGET',tableToken:token});
     return sendPage({...message,action:message.action??message.type,type:'QRTH_ADAPTER_1_0_0',tableToken:token});
    }}};
    route=createRouter(scoped,{enforceProcurementPolicy:false});sessions.set(key,route);
    for(const k of sessions.keys())if(k.startsWith(id+':')&&k!==key)sessions.delete(k);
   }
   const dispatch=()=>route({type:m.command,payload:p},sender);
   if(m.command==='INSPECT_EDITOR')return dispatch();
   const next=fills.then(dispatch);fills=next.catch(()=>{});return next;
  })().then(data=>reply({ok:true,data}),e=>reply({ok:false,error:{message:e.message,code:e.code||'TABLE_BLOCKED'}}));
  return true;
 };
 installPageReconnect(api);
 api.runtime.onMessage.addListener(listener);
 api.tabs.onUpdated?.addListener((tabId,change,tab)=>{
  if(change.status==='complete'&&['pdd_login','pdd_account','pdd_favorites'].includes(classifyTab(tab.url)))
   void pdd({type:'PDD_WORKSPACE_LOGIN_LOADED',payload:{tabId}},sender).catch(()=>{});
 });
 api.tabs.onRemoved?.addListener(id=>{for(const k of sessions.keys())if(k.startsWith(id+':'))sessions.delete(k);});
 return listener;
}
if(globalThis.chrome?.runtime?.onMessage)installTableBackground(chrome);
