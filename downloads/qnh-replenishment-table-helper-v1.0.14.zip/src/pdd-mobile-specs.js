/** Mobile rendering only for our one read-only SKU-render URL in the owned tab. */
export async function ensureMobileSpecReader(api,tabId){
 if(!Number.isInteger(tabId))throw Error('invalid spec reader tab');
 if(!api.declarativeNetRequest?.updateSessionRules)return false;
 await api.declarativeNetRequest.updateSessionRules({removeRuleIds:[770101],addRules:[{
  id:770101,priority:1,action:{type:'modifyHeaders',requestHeaders:[
   {header:'user-agent',operation:'set',value:'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36'},
   {header:'sec-ch-ua-mobile',operation:'set',value:'?1'},
   {header:'sec-ch-ua-platform',operation:'set',value:'"Android"'}
  ]},condition:{tabIds:[tabId],requestDomains:['mobile.yangkeduo.com'],regexFilter:'^https://mobile\\.yangkeduo\\.com/proxy/api/api/oak/integration/render/sku\\?pdduid=[0-9]+&qnh_spec_reader=1$',resourceTypes:['xmlhttprequest']}
 }]});return true;
}
