/** A connected tab stays idle until the employee requests an operation. */
export function createPddTabWorkspace({request,onCollection,onStatus,onLoadState=()=>{}}){
 let tabId=null,disposed=false,scanning=false,createdForSync=false,timer,wake;
 let favoriteIds=null;
 const publish=result=>{
  if(Array.isArray(result.favoriteIds))favoriteIds=new Set(result.favoriteIds);
  if(favoriteIds&&result.goodsId&&result.status==='read')favoriteIds.add(result.goodsId);
  if(result.catalog){
   const catalog=result.catalog;
   const accepts=row=>!favoriteIds||favoriteIds.has(row.goodsId);
   onCollection({...catalog,products:catalog.products.filter(accepts),skus:catalog.skus.filter(accepts)});
  }
  if(result.favoritesLoad)onLoadState(result.favoritesLoad);
  const message=result.favoritesLoad?.message||result.message;
  if(message)onStatus(message);
 };
 const cancelWait=()=>{clearTimeout(timer);wake?.();wake=null;};
 async function stopLoading(){
  scanning=false;
  cancelWait();
  if(tabId)publish(await request('SYNC_PDD_TAB_WORKSPACE',{stopFavoritesLoad:true}));
 }
 return {
  get tabId(){return tabId;},
  async start(options){
   const result=await request('START_PDD_TAB_WORKSPACE',options);
   tabId=result.tabId;
   createdForSync=result.created===true&&options.forSync===true;
   if(options.preferLogin)onStatus('请在拼多多官网完成登录，返回后点击「立即同步」。');
  },
  async favorites(){
   await request('NAVIGATE_PDD_TAB_WORKSPACE',{active:true});
   onStatus('已打开拼多多收藏页。点击「立即同步」读取列表。');
  },
  async product(goodsId){
   const result=await request('NAVIGATE_PDD_TAB_WORKSPACE',{goodsId,readDetail:true});
   publish(result);
  },
  async specs(goodsId){
   const result=await request('READ_PDD_FAVORITE_SPECS',{goodsId,requestedByUser:true});
   publish(result);
  },
  async read(){
   scanning=true;
   let started=false;
   const startupDeadline=Date.now()+20000;
   onLoadState({state:'running',message:'正在读取拼多多收藏列表…'});
   try{
    while(scanning&&!disposed){
     const result=await request('SYNC_PDD_TAB_WORKSPACE',started?{advanceFavorites:true}:{
      refreshFavorites:true,scanWorkspaceTab:createdForSync
     });
     if(!scanning||disposed)return;
     started ||= result.refreshStarted===true;
     if(started)createdForSync=false;
     publish(result);
     if(started?result.favoritesLoad?.state!=='running':result.status!=='loading')return;
     if(!started&&Date.now()>=startupDeadline){
      onStatus('收藏页尚未加载完成，请在拼多多官网核对后再同步。');
      return;
     }
     await new Promise(resolve=>{wake=resolve;timer=setTimeout(resolve,3000);});
     wake=null;
    }
   }catch(error){
    if(started&&!disposed)await stopLoading().catch(()=>{});
    throw error;
   }finally{
    scanning=false;
    if(!disposed)onLoadState(null);
   }
  },
  stopLoading,
  dispose(){disposed=true;scanning=false;cancelWait();}
 };
}
