import {readPddSkuCatalog} from './pdd-sku-api.js';
import {readPddPage} from './pdd-reader.js';
import {readPddProductDocument} from './pdd-product-document.js';

/** Read only. Caller owns the official-operation lock. Never changes a user tab. */
export async function resolvePddSpecifications({api,ownedTab,goodsId,initialResult,allowNavigation=true,singleRequest=false,isCurrent=()=>true,wait=()=>new Promise(r=>setTimeout(r,400))}){
 if(typeof goodsId!=='string'||!/^[1-9]\d*$/.test(goodsId))throw Error('invalid goodsId');
 const tab=await ownedTab(),before=tab.url,attempts=[];
 const sameOrigin=url=>{try{return new URL(url).origin==='https://mobile.yangkeduo.com';}catch{return false;}};
 const detail=url=>{try{const u=new URL(url);return sameOrigin(url)&&/^\/goods\d*\.html$/.test(u.pathname)&&u.searchParams.getAll('goods_id').length===1&&u.searchParams.get('goods_id')===goodsId;}catch{return false;}};
 if(!sameOrigin(before))return {status:'unsupported',message:'请先连接拼多多官网'};
 const run=async(func,args)=>{if(!isCurrent())return {status:'superseded'};const t=await ownedTab();if(t.id!==tab.id)throw Error('官网连接已变化');let r;try{r=(await api.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func,args:args?[args]:[]}))?.[0]?.result;}catch{r={status:'not_ready',message:'页面读取中断'};}const after=await ownedTab();if(after.id!==tab.id||after.url!==t.url)r={status:'needs_user',message:'读取期间官网页面发生变化，请核对后重读规格'};attempts.push({method:func.name,status:r?.status||'empty'});return r;};
 const valid=r=>r?.status==='read'&&r.goodsId===goodsId&&r.skus?.some(s=>s.goodsId===goodsId&&s.skuId&&s.spec&&s.specComplete!==false);
 const parse=r=>r?.status==='snapshot'?readPddPage(r):r;
 const terminal=r=>['needs_user','login_required','superseded'].includes(r?.status);
 if(singleRequest&&detail(before)){
  const page=await run(readPddPage);
  if(valid(page)||terminal(page))return {...page,specReadAttempts:attempts};
 }
 let raw=initialResult||await run(readPddSkuCatalog,{goodsId}),result=parse(raw);
 if(valid(result))return {...result,specReadAttempts:attempts};
 if(terminal(raw)||raw?.status==='unavailable')return {...raw,specReadAttempts:attempts};
 if(singleRequest)return {status:'not_ready',goodsId,message:'本次未读到完整规格。如需核对，可手动打开该商品详情。',specReadAttempts:attempts};
 if(!allowNavigation&&!detail(before)){
  raw=await run(readPddProductDocument,{goodsId});result=parse(raw);
  if(valid(result))return {...result,specReadAttempts:attempts};
  if(terminal(raw))return {...raw,specReadAttempts:attempts};
  return {status:'not_ready',goodsId,message:'暂未读到完整规格，可点击商品详情查看',specReadAttempts:attempts};
 }
 const expected='https://mobile.yangkeduo.com/goods.html?goods_id='+goodsId;
 let moved=false,preserve=false,lastUrl=before;
 try{
  if(!detail(before)){
   const current=await ownedTab();if(current.id!==tab.id||current.url!==before||!isCurrent())return {status:'superseded'};
   await api.tabs.update(tab.id,{url:expected,active:false});moved=true;lastUrl=expected;
  }
  for(let i=0;i<16&&isCurrent();i++){
   const t=await ownedTab();if(t.id!==tab.id)return {status:'superseded'};
   if(t.status==='loading'){await wait();continue;}
   if(!detail(t.url)){preserve=true;return {status:'needs_user',message:'商品详情已跳转，请在官网完成登录或验证后重读规格',specReadAttempts:attempts};}
   lastUrl=t.url;
   result=await run(readPddPage);if(valid(result))return {...result,specReadAttempts:attempts};
   if(terminal(result)){preserve=true;return {...result,specReadAttempts:attempts};}
   break;
  }
  if(!isCurrent())return {status:'superseded'};
  const t=await ownedTab();if(!detail(t.url)||t.status==='loading')return {status:'not_ready',message:'商品详情仍在加载，尚未获得SKU，不能认定商品售罄',specReadAttempts:attempts};
  raw=await run(readPddSkuCatalog,{goodsId});result=parse(raw);
  if(valid(result))return {...result,specReadAttempts:attempts};
  if(terminal(raw)){preserve=true;return {...raw,specReadAttempts:attempts};}
  raw=await run(readPddProductDocument,{goodsId});result=parse(raw);
  if(valid(result))return {...result,specReadAttempts:attempts};
  if(terminal(raw)){preserve=true;return {...raw,specReadAttempts:attempts};}
  return {status:'not_ready',goodsId,message:'规格接口、详情页和页面文档均未提供完整SKU；未认定商品售罄，请打开官网查看登录或APP限制',specReadAttempts:attempts};
 }finally{
  if(moved&&!preserve){try{const t=await ownedTab();if(t.id===tab.id&&t.url===lastUrl&&detail(t.url))await api.tabs.update(tab.id,{url:before,active:false});}catch{}}
 }
}
