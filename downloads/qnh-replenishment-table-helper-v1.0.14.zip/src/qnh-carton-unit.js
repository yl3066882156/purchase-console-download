/** Single-product master-unit operation. No supply relation or native form writes. */
const clone=value=>structuredClone(value);
const fail=(code,message,extra={})=>Object.assign(new Error(message),{code,...extra});
const must=(value,message,code='CARTON_SCHEMA_CHANGED')=>{if(!value)throw fail(code,message);};
const exactId=value=>typeof value==='string'&&/^[1-9]\d*$/.test(value)?value:typeof value==='number'&&Number.isSafeInteger(value)&&value>0?String(value):'';
const same=(a,b)=>stable(a)===stable(b);
const contract=Object.freeze({
  "spuKeys": [
    "tenantId",
    "spuId",
    "spuName",
    "specType",
    "weightType",
    "weightTypeDesc",
    "saleInfo",
    "onlineStatus",
    "jumpPageType",
    "createTime",
    "updateTime",
    "abnormalCodeList",
    "abnormalMarkMsg",
    "noSaleChannelInfoList",
    "productPlace",
    "backendCategoryCode",
    "brandCode",
    "sellPoint",
    "description",
    "coverageInfo",
    "originPlace",
    "deliveryRequirement",
    "picUrlList",
    "picContentList",
    "properties",
    "videoInfo",
    "aiRecommendInfo",
    "medicalDeviceQuaInfo",
    "nameSupplementInfo",
    "specialty",
    "depleteMaterial",
    "erpTenantSpuExtend",
    "skus",
    "spuChannelInfoList",
    "spuChannelCustomizedInfoList",
    "storeFrontCategoryList"
  ],
  "skuKeys": [
    "skuId",
    "specName",
    "saleUnit",
    "suggestPrice",
    "onlineStatus",
    "onlineChannelType",
    "goodsPriceInfo",
    "upcList",
    "externalCode",
    "goodsCode",
    "customizeNoUpcCode",
    "useSkuAsUpc",
    "manageSNCode",
    "headquartersControlledGoods",
    "weightForUnit",
    "weightUnit",
    "expirationForUnit",
    "expirationUnit",
    "volume",
    "cartonMeasureConvertFactorList",
    "enableExpiredCheck",
    "comboGroupList",
    "comboType",
    "skuChannelInfoList",
    "erpTenantSkuExtend",
    "skuSaleType",
    "isSavePromotion",
    "instoreCodes",
    "childSkuList"
  ]
});
const array=value=>value??[];
const clean=value=>value&&typeof value==='object'&&Object.keys(value).some(key=>key!=='clean'&&value[key]!=null&&value[key]!=='')?clone(value):{clean:true};
const select=(value,keys)=>Object.fromEntries(keys.map(key=>[key,clone(value[key])]));
function withoutNull(value){
 if(Array.isArray(value))return value.map(withoutNull);
 if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).filter(([,item])=>item!=null).map(([key,item])=>[key,withoutNull(item)]));
 return value;
}
function makeMasterBody(master){
 const pick=(object,keys,label)=>Object.fromEntries(keys.map(key=>{must(Object.hasOwn(object,key),label+'缺少保存字段：'+key);return [key,clone(object[key])];}));
 const tenantSpu=pick(master,contract.spuKeys,'主档');tenantSpu.skus=master.skus.map(sku=>pick(sku,contract.skuKeys,'规格'));
 return {tenantSpu,coverageRequest:{},submitReason:'',actCheckType:1,recommendId:null};
}
function normalizeMaster(detail) {
  const master=clone(detail);
  // The native master save omits backendCategoryCode for an uncategorized
  // product. A missing category must not block unit-only changes or cause us
  // to invent/clear a category. Keep an existing code exactly as returned.
  const categoryCode=detail.backendCategory?.categoryCode;
  master.backendCategoryCode=categoryCode==null||categoryCode===''?undefined:categoryCode;
  master.brandCode=detail.brand?.brandCode??'';
  master.properties=array(detail.properties);
  for(const k of ['videoInfo','medicalDeviceQuaInfo','nameSupplementInfo'])master[k]=clean(detail[k]);
  master.aiRecommendInfo={aiRecommendSellingPoint:detail.aiRecommendInfo?.aiRecommendSellingPoint===true};
  master.erpTenantSpuExtend=detail.erpTenantSpuExtend??{fromErp:1};
  master.spuChannelCustomizedInfoList=detail.spuChannelCustomizedInfoList??[];
  for(const k of ['originPlace','deliveryRequirement'])if(detail[k]!=null)master[k]=String(detail[k]);
  master.storeFrontCategoryList=array(detail.storeFrontCategoryList).map(group=>({
    groupId:group.groupId,
    storeCategoryList:array(group.storeCategoryList).map(c=>select(c,['categoryCode','name'])),
    auxiliaryStoreCategoryList:array(group.auxiliaryStoreCategoryList).map(c=>select(c,['categoryCode','name']))
  }));
  let unitIndex=0;
  master.skus=detail.skus.map(raw=>{
    const sku=clone(raw);
    for(const k of ['externalCode','goodsCode'])sku[k]=raw[k]??'';
    sku.suggestPrice=raw.suggestPrice?withoutNull(select(raw.suggestPrice,['tenantSuggestPrice','areaSuggestPriceList'])):{clean:true};
    if(!Object.keys(sku.suggestPrice).length)sku.suggestPrice={clean:true};
    sku.volume=clean(raw.volume);
    sku.childSkuList=array(raw.childSkuList);
    sku.erpTenantSkuExtend=clone(raw.erpTenantSkuExtend??{});delete sku.erpTenantSkuExtend.canNotEditUnitConvertFactor;
    sku.instoreCodes=array(raw.skuChannelInfoList).flatMap(channel=>array(channel.channelSkuList).map(c=>({appId:c.appId??null,appName:c.appName??null,channelId:channel.channelId,customSkuId:c.customSkuId})));
    sku.skuChannelInfoList=array(raw.skuChannelInfoList).filter(c=>array(c.saleAttrValueList).length||array(c.skuPicUrlList).length||c.upc).map(c=>({
      channelId:c.channelId,skuPicUrlList:array(c.skuPicUrlList),saleAttrValueList:array(c.saleAttrValueList),...(c.upc?{upc:c.upc}:{})
    }));
    sku.cartonMeasureConvertFactorList=array(raw.cartonMeasureConvertFactorList).map(unit=>({
      cartonMeasureName:unit.cartonMeasureName,basicUnitConvertFactor:unit.basicUnitConvertFactor,
      basicDistributePrice:unit.basicDistributePrice??null,defaultDistributeUnitFlag:unit.defaultDistributeUnitFlag??0,
      canChangeFactor:unit.canChangeFactor??null,uuid:`unitCode${unitIndex++}`,boxCodeList:array(unit.boxCodeList),areaConfigInfoList:array(unit.areaConfigInfoList),weight:unit.weight??null
    }));
    return sku;
  });
  master.spuChannelInfoList=detail.spuChannelInfoList.map(raw=>{
    const channel=clone(raw);
    channel.categoryProperties=array(raw.categoryProperties).map(p=>{
      const keys=['attrId','attrName','attrValueType','characterType','maxTextLength','isRequired','attrSequence','customValue','optionList','structAttrTemplateList','originalInputValue','optionMaxSize','supportExtend','hasFallbackValue','fallbackValueText'];
      const property=select(p,keys);
      if(typeof p.attrId==='string'&&/^\d+$/.test(p.attrId)&&Number.isSafeInteger(Number(p.attrId)))property.attrId=Number(p.attrId);
      property.hasFallbackValue=p.hasFallbackValue??false;
      for(const k of ['customValue','optionList','structAttrTemplateList'])property[k]=array(p[k]);
      return property;
    });
    channel.categoryId=raw.categoryCode;channel.idPath=raw.categoryCodePath;channel.namePath=raw.categoryNamePath;
    channel.afterSaleServiceType=raw.afterSaleServiceType??'';channel.brandInfo=clean(raw.brandInfo);
    if(raw.channelId===100)channel.specialPictureList=clone(array(detail.mtSpecialPictureList));
    if(raw.channelId===200)channel.specialPictureList=clone(array(detail.elmSpecialPictureList));
    return channel;
  });
  return makeMasterBody(master).tenantSpu;
}

function stable(value) {
  if(Array.isArray(value))return '['+value.map(stable).join(',')+']';
  if(value&&typeof value==='object')return '{'+Object.keys(value).filter(k=>value[k]!==undefined).sort().map(k=>JSON.stringify(k)+':'+stable(value[k])).join(',')+'}';
  return JSON.stringify(value);
}
function semanticMaster(master) {
  const result=clone(master);
  // Server-generated timestamps and validation hints are not editable content.
  for(const key of ['updateTime','createTime','abnormalCodeList','abnormalMarkMsg','noSaleChannelInfoList','coverageInfo','jumpPageType'])delete result[key];
  // Captured save/readback pairs fill an absent ERP extension with these exact
  // defaults, and represent optional empty text as null. Canonicalize only
  // those equivalent representations; explicit nondefault values remain checked.
  for(const key of ['sellPoint','description','productPlace'])if(result[key]==null||result[key]==='')result[key]=null;
  for(const sku of result.skus){
   if(sku.specName==null||sku.specName==='')sku.specName=null;
   const defaults={tenantSkuErpGoodsRelList:null,erpSaleStatus:null,shareStockType:0,stockUpRoundStatus:2,stockUpRoundRatio:''};
   sku.erpTenantSkuExtend={...defaults,...sku.erpTenantSkuExtend};
   sku.cartonMeasureConvertFactorList=sku.cartonMeasureConvertFactorList.map(unit=>({
    cartonMeasureName:unit.cartonMeasureName,basicUnitConvertFactor:Number(unit.basicUnitConvertFactor),
    basicDistributePrice:unit.basicDistributePrice??null,defaultDistributeUnitFlag:unit.defaultDistributeUnitFlag??0,
    canChangeFactor:unit.canChangeFactor??null,boxCodeList:unit.boxCodeList??[],areaConfigInfoList:unit.areaConfigInfoList??[],weight:unit.weight??null
   }));
  }
  for(const channel of result.spuChannelInfoList) {
    const brand=clone(channel.brandInfo);delete brand.channelId;
    channel.brandInfo=brand;
    channel.categoryProperties=channel.categoryProperties.map(p=>({attrId:String(p.attrId),customValue:clone(p.customValue)}));
    if(channel.specialPictureList)channel.specialPictureList=channel.specialPictureList.map(p=>({pictureType:p.pictureType,pictureUrl:array(p.pictureUrl)}));
    for(const key of ['auditInfo','materialAuditList','qualificationList','categoryCanModify','channelOnlineStatus','recommendId'])delete channel[key];
  }
  return result;
}

async function semanticFingerprint(semantic){
 const bytes=await globalThis.crypto.subtle.digest('SHA-256',new TextEncoder().encode(stable(semantic)));
 return [...new Uint8Array(bytes)].map(value=>value.toString(16).padStart(2,'0')).join('');
}

function mismatchPaths(expected,actual,path='',out=[]){
 if(out.length>=12||same(expected,actual))return out;
 if(expected&&actual&&typeof expected==='object'&&typeof actual==='object'){
  for(const key of new Set([...Object.keys(expected),...Object.keys(actual)]))mismatchPaths(expected[key],actual[key],path+'/'+key,out);
 }else out.push(path||'/');
 return out;
}

function validateTarget(target,quantity){
 must(target&&exactId(target.tenantId),'无法确认当前租户','CARTON_TARGET_INVALID');
 must(typeof target.upc==='string'&&/^\d{8,20}$/.test(target.upc),'当前商品UPC不完整','CARTON_TARGET_INVALID');
 const raw=typeof quantity==='number'&&Number.isInteger(quantity)?String(quantity):quantity;
 must(typeof raw==='string'&&/^\d{1,5}$/.test(raw)&&Number(raw)>=2&&Number(raw)<=99999,'箱规数量只能输入2～99999的整数','CARTON_QUANTITY_INVALID');
 return {tenantId:exactId(target.tenantId),upc:target.upc,name:typeof target.name==='string'?target.name.slice(0,500):'',quantity:Number(raw)};
}
async function resolveProduct(call,target){
 const matches=new Map();let seen=0,total=null;
 for(let page=1;page<=10;page++){
  const data=await call('products',{upcList:[target.upc],labelInfoList:[],storeFrontGroupCategoryList:[],channelCategory:{channelId:100,categoryProperty:{}},page,pageSize:20,backendCategoryList:[]});
  must(data&&Array.isArray(data.list)&&Number.isSafeInteger(data.total)&&data.total>=0,'主档查询未返回完整分页信息');
  if(total==null)total=data.total;else must(total===data.total,'主档查询分页期间商品列表已变化','CARTON_PRODUCT_CHANGED');
  seen+=data.list.length;
  for(const product of data.list){
   must(Array.isArray(product.skus),'主档查询缺少SKU列表');
   for(const sku of product.skus){
    if(!Array.isArray(sku.upcList)||!sku.upcList.includes(target.upc))continue;
    must(exactId(product.tenantId)===target.tenantId,'主档查询租户与当前页面不一致','CARTON_TARGET_MISMATCH');
    const spuId=exactId(product.spuId),skuId=exactId(sku.skuId);must(spuId&&skuId,'主档商品标识符不可靠');
    matches.set(spuId+':'+skuId,{...target,spuId,skuId});
   }
  }
  must(matches.size<=1,'同一UPC对应多个商品或规格，未新增单位','CARTON_PRODUCT_AMBIGUOUS');
  if(seen>=total){must(matches.size===1,'未找到当前已关联商品的唯一主档SKU','CARTON_PRODUCT_NOT_FOUND');return [...matches.values()][0];}
  must(data.list.length>0,'主档分页未完整返回');
 }
 throw fail('CARTON_PRODUCT_AMBIGUOUS','主档查询结果过多，未新增单位');
}
function exactSku(detail,item){
 must(detail&&exactId(detail.tenantId)===item.tenantId,'主档租户与当前页面不一致','CARTON_TARGET_MISMATCH');
 must(exactId(detail.spuId)===item.spuId,'主档SPU与当前商品不一致','CARTON_TARGET_MISMATCH');
 must(Array.isArray(detail.skus)&&detail.skus.length>0,'主档未返回完整规格列表');
 const ids=new Set();
 for(const sku of detail.skus){const id=exactId(sku.skuId);must(id&&!ids.has(id),'主档SKU标识符不可靠或重复');ids.add(id);}
 const matches=detail.skus.filter(sku=>Array.isArray(sku.upcList)&&sku.upcList.includes(item.upc));
 must(matches.length===1&&exactId(matches[0].skuId)===item.skuId,'主档UPC和SKU未唯一匹配当前商品','CARTON_TARGET_MISMATCH');
 const sku=matches[0];
 must(typeof sku.saleUnit==='string'&&sku.saleUnit.length>0,'主档缺少商品基本单位');
 must(Array.isArray(sku.cartonMeasureConvertFactorList)&&sku.cartonMeasureConvertFactorList.length>0,'主档缺少货品单位列表');
 const base=sku.cartonMeasureConvertFactorList.filter(unit=>unit.cartonMeasureName===sku.saleUnit&&Number(unit.basicUnitConvertFactor)===1);
 must(base.length===1,'主档基本单位及其换算不唯一');
 return sku;
}
function matchingUnits(sku,quantity){return sku.cartonMeasureConvertFactorList.filter(unit=>unit.cartonMeasureName!==sku.saleUnit&&Number(unit.basicUnitConvertFactor)===quantity);}
function chooseUnit(sku,options,quantity){
 const units=sku.cartonMeasureConvertFactorList;
 const matches=matchingUnits(sku,quantity);
 if(matches.length===1)return {unitName:matches[0].cartonMeasureName,reused:true};
 must(Array.isArray(options)&&options.every(name=>typeof name==='string'&&name.length>0),'箱规可选单位格式发生变化');
 const name=options.find(name=>name!==sku.saleUnit&&!units.some(unit=>unit.cartonMeasureName===name));
 must(name,'没有可新增的未使用货品单位名称','CARTON_NO_UNIT_NAME');
 return {unitName:name,reused:false};
}
function planMaster(detail,item,unitName,quantity){
 const sku=exactSku(detail,item);
 must(sku.headquartersControlledGoods!==1&&sku.headquartersControlledGoods!==true,'总部统管商品不能新增货品单位','CARTON_UNIT_READONLY');
 must(!sku.erpTenantSkuExtend?.canNotEditUnitConvertFactor,'该商品不允许编辑单位换算','CARTON_UNIT_READONLY');
 const normalized=normalizeMaster(detail),target=normalized.skus.find(sku=>exactId(sku.skuId)===item.skuId);
 must(!target.cartonMeasureConvertFactorList.some(unit=>unit.cartonMeasureName===unitName),'选定的货品单位名称已被占用','CARTON_PRODUCT_CHANGED');
 const used=new Set(normalized.skus.flatMap(sku=>sku.cartonMeasureConvertFactorList.map(unit=>unit.uuid)));
 let index=0;while(used.has('unitCode'+index))index++;
 target.cartonMeasureConvertFactorList.push({uuid:'unitCode'+index,cartonMeasureName:unitName,basicUnitConvertFactor:quantity,boxCodeList:[],areaConfigInfoList:[]});
 return {body:makeMasterBody(normalized),semantic:semanticMaster(normalized)};
}
function persistedUnit(units,unitName,quantity){
 must(Array.isArray(units),'货品单位列表未完整返回');
 const named=units.filter(unit=>unit.cartonMeasureName===unitName);
 must(named.length===1&&Number(named[0].basicUnitConvertFactor)===quantity&&exactId(named[0].cartonMeasureCode),'没有读到唯一的真实货品单位编码','CARTON_UNIT_UNVERIFIED');
 return {...named[0],cartonMeasureCode:exactId(named[0].cartonMeasureCode)};
}
function verifiedOptions(units){
 must(Array.isArray(units)&&units.length>0,'箱规接口未返回完整单位列表','CARTON_UNIT_UNVERIFIED');
 const names=new Set(),codes=new Set();
 return units.map(raw=>{
  const name=raw?.cartonMeasureName,code=exactId(raw?.cartonMeasureCode),factor=raw?.basicUnitConvertFactor;
  const reliableFactor=(typeof factor==='number'&&Number.isFinite(factor))||(typeof factor==='string'&&/^\d+(?:\.\d+)?$/.test(factor));
  must(typeof name==='string'&&name.trim().length>0&&code&&reliableFactor&&Number(factor)>0&&Number.isFinite(Number(factor)),'单位列表含无法核实的名称、编码或换算','CARTON_UNIT_UNVERIFIED');
  must(!names.has(name)&&!codes.has(code),'单位列表含重复名称或编码，无法安全更新选择框','CARTON_UNIT_UNVERIFIED');
  names.add(name);codes.add(code);
  return {...clone(raw),cartonMeasureCode:code};
 });
}
async function verifyUnit(call,detail,item,unitName,quantity){
 const inMaster=persistedUnit(exactSku(detail,item).cartonMeasureConvertFactorList,unitName,quantity);
 const rows=await call('units',{skuIdList:[item.skuId]});
 must(Array.isArray(rows),'箱规接口未返回列表');
 const found=rows.filter(row=>exactId(row.skuId)===item.skuId);
 must(found.length===1,'箱规接口未唯一匹配当前商品','CARTON_UNIT_UNVERIFIED');
 const unitOptions=verifiedOptions(found[0].cartonMeasureConvertFactorList);
 const unit=persistedUnit(unitOptions,unitName,quantity);
 must(unit.cartonMeasureCode===inMaster.cartonMeasureCode,'主档和箱规接口的单位编码不一致','CARTON_UNIT_UNVERIFIED');
 return {unit,unitOptions};
}

/** Read-only lookup for a SKU click. Never adds a unit or saves master data. */
export async function findExistingCartonUnit(input,{call,checkpoint=async()=>{}}){
 const quantity=String(input?.quantity??''),target=input?.target;
 must(target&&typeof target.tenantId==='string'&&/^\d{1,20}$/.test(target.tenantId)&&typeof target.upc==='string'&&/^\d{8,20}$/.test(target.upc)&&/^[1-9]\d{0,4}$/.test(quantity),'包装数量未明确','CARTON_INVALID_MATCH');
 const read=async(operation,body)=>{must(['products','units'].includes(operation),'匹配已有箱规只允许读取');await checkpoint();return call(operation,body);};
 const item=await resolveProduct(read,target);
 const rows=await read('units',{skuIdList:[item.skuId]});
 must(Array.isArray(rows),'箱规接口未返回列表','CARTON_UNIT_UNVERIFIED');
 const found=rows.filter(row=>exactId(row.skuId)===item.skuId);must(found.length===1,'箱规接口未唯一匹配当前商品','CARTON_UNIT_UNVERIFIED');
 const unitOptions=verifiedOptions(found[0].cartonMeasureConvertFactorList),bases=unitOptions.filter(u=>Number(u.basicUnitConvertFactor)===1);
 must(bases.length===1,'箱规基本单位不唯一','CARTON_UNIT_UNVERIFIED');
 const baseUnit=bases[0].cartonMeasureName;
 // Match the unique existing conversion factor; unit names are reviewed by staff.
 const matches=unitOptions.filter(u=>Number(u.basicUnitConvertFactor)===Number(quantity));
 if(matches.length!==1)return {status:matches.length?'ambiguous':'not_found',baseUnit,message:matches.length?'多个已有箱规对应相同数量，请手动选择':'没有换算为'+quantity+baseUnit+'的已有箱规，请手动核对'};
 const unit=matches[0];return {status:'matched',message:'已匹配箱规：'+unit.cartonMeasureName+'（'+quantity+baseUnit+'/'+unit.cartonMeasureName+'）',result:{skuId:item.skuId,spuId:item.spuId,unitName:unit.cartonMeasureName,unitCode:unit.cartonMeasureCode,quantity:Number(quantity),baseUnit,unitOptions}};
}
const pendingInfo=(item,unitName,quantity)=>({tenantId:item.tenantId,upc:item.upc,skuId:item.skuId,spuId:item.spuId,unitName,quantity});
const isExplicitRejection=error=>error?.explicitRejection===true||error?.response?.success===false||(error?.response?.code!=null&&!['0',0].includes(error.response.code));

/** call() returns unwrapped, losslessly parsed response data from a fixed API allowlist. */
export async function addCartonUnit(input,{call,checkpoint=async()=>{},wait=ms=>new Promise(resolve=>setTimeout(resolve,ms))}={}){
 must(typeof call==='function','缺少主档接口连接');
 const target=validateTarget(input?.target,input?.quantity),quantity=target.quantity;
 await checkpoint({stage:'start',tenantId:target.tenantId,upc:target.upc});
 const item=await resolveProduct(call,target);
 let detail=await call('master',{spuId:item.spuId}),sku=exactSku(detail,item);
 // Reusing an already verified unit does not require a unit-name lookup.
 const options=matchingUnits(sku,quantity).length===1?null:await call('options',null),selection=chooseUnit(sku,options,quantity),{unitName}=selection;
 const result=(status,{unit,unitOptions})=>({status,unitName,quantity,baseUnit:sku.saleUnit,skuId:item.skuId,spuId:item.spuId,unitCode:unit.cartonMeasureCode,unitOptions});
 if(selection.reused){
  const unit=await verifyUnit(call,detail,item,unitName,quantity);
  const actualSemanticFingerprint=await semanticFingerprint(semanticMaster(normalizeMaster(detail)));
  await checkpoint({stage:'verified',...pendingInfo(item,unitName,quantity),actualSemanticFingerprint});
  return result('reused',unit);
 }
 const beforeSemantic=semanticMaster(normalizeMaster(detail)),plan=planMaster(detail,item,unitName,quantity);
 const check=await call('check',{tenantSpu:plan.body.tenantSpu});
 must(check===0,'主档活动校验要求人工处理，未保存商品','CARTON_ACTIVITY_REVIEW_REQUIRED');
 // A fresh full master read rejects concurrent changes before the one save.
 detail=await call('master',{spuId:item.spuId});sku=exactSku(detail,item);
 must(same(semanticMaster(normalizeMaster(detail)),beforeSemantic),'商品主档在操作期间发生变化，请重新核对','CARTON_PRODUCT_CHANGED');
 const current=planMaster(detail,item,unitName,quantity);
 const pending=pendingInfo(item,unitName,quantity);
 // The host persists this minimal marker and rejects unresolved prior writes.
 const expectedSemanticFingerprint=await semanticFingerprint(current.semantic);
 await checkpoint({stage:'before_save',...pending,expectedSemanticFingerprint});
 let saveError=null;
 try{
  const saved=await call('saveMaster',current.body);
  if(saved?.errorCode!=null&&!['0',0].includes(saved.errorCode))throw fail('CARTON_SAVE_REJECTED','主档保存失败：'+String(saved.errorMsg??saved.errorCode),{explicitRejection:true});
  if(saved?.success===false)throw fail('CARTON_SAVE_REJECTED','主档保存未成功',{explicitRejection:true});
 }catch(error){saveError=error;}
 // Even a timeout can have committed server-side. Retry only reads of stale
 // results; the save is never repeated. The successful fast path has no delay.
 try{
  for(let attempt=0;attempt<3;attempt++){
   if(attempt)await wait(attempt===1?200:500);
   detail=await call('master',{spuId:item.spuId});sku=exactSku(detail,item);
   const actual=semanticMaster(normalizeMaster(detail));
   if(saveError&&isExplicitRejection(saveError)&&same(actual,beforeSemantic))throw fail('CARTON_SAVE_REJECTED',saveError.message||'主档明确拒绝保存',{explicitRejection:true,pending});
   if(!same(actual,current.semantic)){
    if(attempt<2&&same(actual,beforeSemantic))continue;
    throw fail('CARTON_SAVE_UNCONFIRMED','主档回读未完整匹配新增单位及原有商品信息',{mismatchPaths:mismatchPaths(current.semantic,actual)});
   }
   try{return result('added',await verifyUnit(call,detail,item,unitName,quantity));}
   catch(error){if(attempt<2&&error.code==='CARTON_UNIT_UNVERIFIED')continue;throw error;}
  }
 }catch(error){
  if(error.code==='CARTON_SAVE_REJECTED'&&error.explicitRejection)throw error;
  throw fail('CARTON_SAVE_UNCONFIRMED','主档保存结果尚未确认，请先核对商品主档，勿重复新增。'+(error.message?' '+error.message:''),{pending,cause:error,...(error.mismatchPaths?{mismatchPaths:error.mismatchPaths}:{})});
 }
}
