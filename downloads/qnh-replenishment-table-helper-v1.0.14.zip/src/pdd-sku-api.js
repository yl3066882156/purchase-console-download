/** Same read-only SKU-render endpoint used by the supplied Haixiaobao client.
 * Its POST renders product specifications; it does not alter favorites or orders.
 * Browser authentication stays in the official first-party page.
 */
export async function readPddSkuCatalog({goodsId}={}){
  function collectPddPromotions(record,source='explicit_promotion_fields'){
    const read=(object,key)=>{try{return Object.getOwnPropertyDescriptor(object,key)?.value;}catch{return undefined;}};
    const fields=['promotionTags','promotion_tags','tagList','tag_list','variedTagsList','varied_tags_list','propertyTagList','property_tag_list','prefixIcons','prefix_icons','pricePrefixInfo','price_prefix_info','priceInfo','price_info','activityTags','activity_tags','serviceTags','service_tags','tags'];
    const textKeys=new Set(['text','name','title','label','content','desc','description','value','alt','altText','tagText','tag_text','tagName','tag_name','tagDesc','tag_desc','displayText','display_text','contentText','content_text','htmlText','html_text','prefixText','prefix_text']);
    const childKeys=new Set(['children','parts','spans','items','list','tags','tagList','tag_list','contents']);
    const imageKeys=['url','imageUrl','image_url','imgUrl','img_url','iconUrl','icon_url'];
    const seen=new WeakSet(),tags=[],observed=[];let visited=0,unknownBadgeCount=0,truncated=false;
    const normalize=value=>value.normalize('NFKC').replace(/<[^>]{0,300}>/g,'').replace(/&nbsp;|&#160;/gi,' ').replace(/&#(?:x([0-9a-f]{1,6})|([0-9]{1,7}));/gi,(_,hex,dec)=>{const n=parseInt(hex||dec,hex?16:10);return n>0&&n<=0x10ffff?String.fromCodePoint(n):'';}).replace(/\s+/g,' ').trim();
    const looksUrl=value=>typeof value==='string'&&/^(?:[a-z][a-z\d+.-]*:|\/\/)/i.test(value.trim());
    const add=value=>{
      if(typeof value!=='string'||!value.trim())return false;
      if(looksUrl(value)){unknownBadgeCount++;return false;}
      if(value.length>500)truncated=true;
      const text=normalize(value.slice(0,500));
      if(!text||/^#[\da-f]{3,8}$/i.test(text)||/^\d+(?:\.\d+)?(?:px|%)?$/.test(text))return false;
      if(tags.length>=60){truncated=true;return true;}
      const bounded=text.slice(0,180);if(text.length>180)truncated=true;
      if(!tags.includes(bounded))tags.push(bounded);return true;
    };
    const walk=(value,depth)=>{
      if(typeof value==='string')return add(value);
      if(!value||typeof value!=='object')return false;
      if(depth>6||visited>=180){truncated=true;return false;}
      if(seen.has(value))return false;seen.add(value);visited++;
      let readable=false;const fragmentStart=tags.length;
      if(Array.isArray(value)){
        if(value.length>40)truncated=true;
        for(let index=0;index<Math.min(value.length,40);index++)readable=walk(read(value,String(index)),depth+1)||readable;
        return readable;
      }
      let keys;try{keys=Object.keys(value).slice(0,80);}catch{return false;}
      for(const key of keys)if(textKeys.has(key)||childKeys.has(key))readable=walk(read(value,key),depth+1)||readable;
      // Join rendering fragments only inside one explicit label, never across unrelated tags.
      if(keys.some(key=>['children','parts','spans','contents'].includes(key))){
        const fragments=tags.slice(fragmentStart).join('').replace(/\s+/g,'');
        for(const phrase of ['百亿补贴','多人团'])if(fragments.includes(phrase)&&!tags.some(text=>text.replace(/\s+/g,'').includes(phrase)))add(phrase);
      }
      if(!readable&&imageKeys.some(key=>looksUrl(read(value,key))))unknownBadgeCount++;
      return readable;
    };
    if(record&&typeof record==='object')for(const field of fields){
      const value=read(record,field);if(value==null)continue;observed.push(field);walk(value,0);
    }
    // Preserve text-only evidence when a goods-only API snapshot is parsed again.
    const inherited=record&&read(record,'promotionEvidence');
    if(inherited&&typeof inherited==='object'){
      const unknown=read(inherited,'unknownBadgeCount');if(Number.isSafeInteger(unknown)&&unknown>0)unknownBadgeCount+=Math.min(unknown,180);
      if(read(inherited,'truncated')===true)truncated=true;
    }
    const names=record&&typeof record==='object'?['name','title','goodsName','goods_name','goodsTitle','goods_title','short_name','spec','specName','spec_name','skuName','sku_name'].map(key=>read(record,key)).filter(value=>typeof value==='string').map(value=>normalize(value.slice(0,1000))):[];
    const all=tags.concat(names),exclusionReasons=[];
    for(const phrase of ['百亿补贴','多人团'])if(all.some(text=>text.replace(/\s+/g,'').includes(phrase)))exclusionReasons.push('包含“'+phrase+'”标签');
    const inheritedFields=read(inherited||{},'fields'),hadOriginalEvidence=Array.isArray(inheritedFields);
    const evidenceFields=[...new Set((hadOriginalEvidence?inheritedFields.filter(value=>typeof value==='string'&&fields.includes(value)):[]).concat(observed.filter(field=>!hadOriginalEvidence||!['promotionTags','promotion_tags'].includes(field))))].slice(0,40);
    return {promotionTags:tags.slice(0,60),exclusionReasons,promotionEvidence:{source:typeof source==='string'?source.slice(0,80):'explicit_promotion_fields',fields:evidenceFields,textOnly:true,unknownBadgeCount:Math.min(unknownBadgeCount,360),truncated,verified:exclusionReasons.length>0||evidenceFields.length>0&&!unknownBadgeCount&&!truncated}};
  }

 const id=v=>{if(typeof v==='number'&&!Number.isSafeInteger(v))return '';const s=String(v??'');return /^[1-9]\d*$/.test(s)?s:'';};
 if(location.origin!=='https://mobile.yangkeduo.com'||!/^\/(?:likes|search_result|goods\d*)\.html$/.test(location.pathname)||id(goodsId)!==goodsId)return {status:'unsupported',message:'仅可读取当前官网商品的规格'};
 let endpoint='https://mobile.yangkeduo.com/proxy/api/api/oak/integration/render/sku';
 let uid='';try{const identity=await globalThis.cookieStore?.get('pdd_user_id');if(typeof identity?.value==='string'&&/^[1-9]\d*$/.test(identity.value))uid=identity.value;}catch{}endpoint+='?pdduid='+(uid||'0')+'&qnh_spec_reader=1';
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),7000);
 try{
  // Numeric ID bytes are preserved without first coercing them to a JS Number.
  const body='{"goods_id":'+goodsId+',"front_supports":["front_promo_price","sku_selector_toast","group_tip_end_time","custom_sku","goods_reminder","morgan_suffix","goods_reminder_click"],"hostname":"mobile.yangkeduo.com","page_from":0,"page_version":7,"_component_version":2,"_oak_stage":"mall_page"}';
  const response=await fetch(endpoint,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body,signal:controller.signal,redirect:'error'});
  if(response.status===429)return {status:'needs_user',message:'拼多多提示访问频繁，本次读取已停止。请在官网确认恢复后再读取。'};
  if(!response.ok)return {status:'needs_user',message:'官网规格接口暂不可用，请确认拼多多登录状态后重试'};
  const text=await response.text();if(text.length>5000000)return {status:'not_ready',message:'规格数据超出读取范围，请打开官网核对'};
  const lossless=text.replace(/("(?:goods_id|goodsId|sku_id|skuId|group_id|groupId)"\s*:\s*)(\d{16,})(?=\s*[,}\]])/g,'$1"$2"');
  let data;try{data=JSON.parse(lossless);}catch{return {status:'not_ready',message:'官网规格响应格式暂不可识别'};}
  const payload=data?.goods?data:data?.result?.goods?data.result:data?.data?.goods?data.data:null;
  const rows=payload?.sku??payload?.goods?.sku??payload?.goods?.skus??payload?.goods?.sku_list;
  if(!payload||!Array.isArray(rows)){
   const rawCode=data?.error_code??data?.code??payload?.goods?.status,code=['string','number'].includes(typeof rawCode)?String(rawCode).slice(0,30):'unknown';
   const messages=[['error_msg',data?.error_msg],['message',data?.message],['result.error_msg',data?.result?.error_msg],['result.message',data?.result?.message],['data.error_msg',data?.data?.error_msg],['data.message',data?.data?.message],['goods.status_explain',payload?.goods?.status_explain]].filter(([,text])=>typeof text==='string'&&text.trim()).map(([field,text])=>({field,text:text.slice(0,240)}));
   const message=messages.map(row=>row.text).join('；').slice(0,500),challenge=/(?:登录|登陆|扫码|验证码|人机|校验|验证|captcha|log[ -]?in|verification|challenge|sign[ -]?in)/i.test(message);
   const unavailable=messages.find(row=>{const explicit=row.text.replace(/(?:尚未|并未|没有|未|不|非)(?:已(?:经)?)?(?:售罄|售完|下架)/g,'');return /已(?:经)?(?:售罄|售完|下架)|(?:商品|宝贝|货品|库存)售罄|^售罄(?:[，,。!！]|$)/.test(explicit)&&!/(?:是否|可能|疑似|确认.{0,4})(?:已)?(?:售罄|售完|下架)/.test(explicit);});
   const declaredGoodsId=payload?.goods?.goods_id??payload?.goods?.goodsId??payload?.goods?.goodsID;if(declaredGoodsId!=null&&id(declaredGoodsId)!==goodsId)return {status:'not_ready',message:'官网规格返回的商品与当前商品不一致，未使用'};
   if(unavailable&&!challenge)return {status:'unavailable',reason:'product_unavailable',goodsId,message:'该商品已售罄或下架，已跳过；继续核对其他商品',availability:{status:'unavailable',goodsId,source:'official_sku_render_message',field:unavailable.field,text:unavailable.text,errorCode:code,capturedAt:new Date().toISOString()}};
   return {status:'needs_user',message:'官网规格返回 '+code+(message?'：'+message:'（字段 '+Object.keys(payload?.goods||data||{}).slice(0,20).join(',')+'）')+'（身份'+(uid?'已绑定':'未绑定')+'）；请处理官网提示后同步'};
  }
  const g=payload.goods,gid=id(g.goods_id??g.goodsId??g.goodsID);
  if(gid!==goodsId)return {status:'not_ready',message:'官网规格返回的商品与当前商品不一致，未使用'};
  const groupRows=Array.isArray(g.group)?g.group:Array.isArray(g.groupTypes)?g.groupTypes:[];
  const groupTypes=groupRows.slice(0,20).map(row=>({groupId:row.group_id??row.groupId??''}));
  const integer=v=>typeof v==='number'&&Number.isSafeInteger(v)&&v>=0?String(v):typeof v==='string'&&/^\d+$/.test(v)?v:'';
  const skus=rows.slice(0,500).filter(row=>row&&id(row.goods_id??row.goodsId??gid)===goodsId&&id(row.sku_id??row.skuId)).map(row=>({goodsId,skuId:id(row.sku_id??row.skuId),...collectPddPromotions(row,'official_sku_render_tags'),specs:Array.isArray(row.specs)?row.specs.slice(0,10).map(s=>({spec_value:typeof s?.spec_value==='string'?s.spec_value.slice(0,150):typeof s?.specValue==='string'?s.specValue.slice(0,150):''})):[],groupPrice:integer(row.group_price??row.groupPrice),normalPrice:integer(row.normal_price??row.normalPrice),priceUnit:'fen',quantity:integer(row.quantity),isOnsale:row.is_sku_onsale??row.isOnsale}));
  if(!skus.length)return {status:'not_ready',message:'未读取到归属明确的具体SKU'};
  return {status:'snapshot',kind:'pdd_product_document',sourceUrl:'https://mobile.yangkeduo.com/goods.html?goods_id='+goodsId,rawData:{store:{initDataObj:{goods:{goodsId,goodsName:String(g.goods_name??g.goodsName??'').slice(0,500),...collectPddPromotions(g,'official_sku_render_goods_tags'),groupTypes,skus}}}},sourceKind:'official_sku_render',capturedAt:new Date().toISOString()};
 }catch{return {status:'not_ready',message:'官网规格读取暂未完成，请稍后同步'};}finally{clearTimeout(timer);}
}
