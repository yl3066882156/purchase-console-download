import {addCartonUnit} from './qnh-carton-unit.js';
import {selectQnhCartonUnit} from './qnh-carton-select.js';

const fail=(code,message)=>Object.assign(new Error(message),{code});
const pageUrl=raw=>{try{const u=new URL(raw);return u.origin==='https://qnh.meituan.com'&&['/','/home.html'].includes(u.pathname)&&!u.username&&!u.password?u:null;}catch{return null;}};
const routeIdentity=url=>{
 const parts=url.hash.slice(1).split('?'),params=new URLSearchParams(parts.slice(1).join('?'));
 return JSON.stringify([url.origin,'/home.html',parts[0],...['relationId','spu','spuId','sku','skuId'].map(key=>[key,params.getAll(key)])]);
};
const identity=t=>JSON.stringify([t?.tenantId,t?.upc]);
export function parseCartonJson(text){
 return JSON.parse(text.replace(/"(?:\\[\s\S]|[^"\\])*"|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/g,token=>token[0]==='"'||/[.eE]/.test(token)||Number.isSafeInteger(Number(token))?token:JSON.stringify(token)));
}

/** Execute only the captured, same-origin product-master endpoints in the page. */
export async function requestQnhCartonApi({operation,body}){
 const paths={products:'/qnh-gw3/api/product/tenant/page-query',master:'/qnh-gw3/api/product/tenant/detail',options:'/qnh-gw3/api/product/tenant/query-purchase-unit',check:'/qnh-gw3/api/product/tenant/update-check-act/v2',saveMaster:'/qnh-gw3/api/product/tenant/update/v2',units:'/api/v1/common/sku/queryCartonMeasure'};
 if(location.origin!=='https://qnh.meituan.com'||!['/','/home.html'].includes(location.pathname)||!Object.hasOwn(paths,operation))return {ok:false,message:'当前页面或接口不支持添加箱规'};
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5000);
 try{
  const r=await fetch(paths[operation]+'?yodaReady=h5&csecplatform=4&csecversion=4.3.0',{method:'POST',credentials:'include',redirect:'error',headers:{'content-type':'application/json'},body:body==null?'':JSON.stringify(body),signal:controller.signal});
  const text=await r.text();if(text.length>12000000)throw Error('商品接口响应过大，未继续处理');
  return {ok:true,httpStatus:r.status,text};
 }catch(e){return {ok:false,message:e.name==='AbortError'?'箱规接口超时，请先核对实际保存结果':e.message||'箱规接口请求失败'};}
 finally{clearTimeout(timer);}
}

/** Content-script entry point; product-master writes are separate from relation drafts. */
export function createCartonUnitRuntime({api,addUnit=addCartonUnit,clock=()=>Date.now()}){
 let queue=Promise.resolve();const active=new Set();
 const authorize=sender=>{
  if(sender?.id!==api.runtime.id||!Number.isInteger(sender?.tab?.id)||sender.frameId!==0||!pageUrl(sender.url))throw fail('INVALID_SENDER','仅允许牵牛花页面中的添加箱规按钮发起操作');
 };
 const handle=async function handle(payload,sender){
  authorize(sender);
  const target=payload?.target,raw=String(payload?.quantity??'');
  if(!target||typeof target.tenantId!=='string'||!/^\d{1,20}$/.test(target.tenantId)||typeof target.upc!=='string'||!/^\d{8,20}$/.test(target.upc)||!/^\d{1,5}$/.test(raw)||Number(raw)<2||Number(raw)>99999)throw fail('INVALID_CARTON_INPUT','请输入2～99999的整数，并选择唯一商品');
  const deadline=clock()+60000;
  const quantity=Number(raw),tabId=sender.tab.id,key=identity(target),operationId=crypto.randomUUID();
  if(active.has(key))throw fail('CARTON_BUSY','该商品正在添加箱规，请稍候');active.add(key);
  const work=queue.then(async()=>{
   let pendingKey,registered=false,submitted=false,verified=false,boundRoute=null;
   const docOptions={frameId:0,...(sender.documentId?{documentId:sender.documentId}:{})};
   const guard=async()=>{
    if(clock()>=deadline)throw fail('CARTON_TIMEOUT','添加箱规操作超时，请核对商品主档的实际结果后再试');
    const tab=await api.tabs.get(tabId),url=pageUrl(tab.url);
    if(!url)throw fail('CARTON_TARGET_CHANGED','页面已切换，请在当前商品处重新操作');
    // Sender.url can precede a client-side navigation. Bind this operation to
    // the live document and current route, ignoring transient list filters.
    const route=routeIdentity(url);
    if(boundRoute!==null&&route!==boundRoute)throw fail('CARTON_TARGET_CHANGED','页面已切换，请在当前商品处重新操作');
    let r;
    try{r=await api.tabs.sendMessage(tabId,{type:'QNH_CARTON_GET_TARGET'},docOptions);}
    catch{throw fail('CARTON_TARGET_CHANGED','当前表单已关闭或替换，请在当前商品处重新操作');}

    if(!r?.ok||identity(r.data?.target)!==key||(payload.anchor&&r.data.anchor!==payload.anchor))throw fail('CARTON_TARGET_CHANGED','当前关联商品、租户或表单已变化，已停止添加箱规');
    boundRoute??=route;
   };
   const readJournal=async()=>{const {cartonUnitOperations={}}=await api.storage.local.get('cartonUnitOperations');return cartonUnitOperations;};
   const saveEntry=async(entry)=>{
    const all=await readJournal();all[pendingKey]={...all[pendingKey],...entry,updatedAt:new Date().toISOString()};
    // Retain all uncertain writes; trim only completed history.
    const entries=Object.entries(all),completed=entries.filter(([,v])=>['verified','rejected'].includes(v.state)).sort((a,b)=>b[1].updatedAt.localeCompare(a[1].updatedAt)).slice(0,50);
    await api.storage.local.set({cartonUnitOperations:Object.fromEntries([...entries.filter(([,v])=>!['verified','rejected'].includes(v.state)),...completed])});
   };
   const checkpoint=async(info={})=>{
    await guard();
    if(info.stage==='verified'){
     pendingKey=JSON.stringify([target.tenantId,String(info.skuId)]);
     const old=(await readJournal())[pendingKey];
     if(old&&['saving','unknown'].includes(old.state)&&old.expectedSemanticFingerprint&&old.expectedSemanticFingerprint===info.actualSemanticFingerprint)await saveEntry({state:'verified',unitName:info.unitName,quantity:info.quantity});
    }
    if(info.stage==='before_save'){
     if(!info.skuId||!info.spuId||!/^[a-f0-9]{64}$/.test(info.expectedSemanticFingerprint||''))throw fail('CARTON_ID_MISSING','主档SKU或SPU未确认');
     pendingKey=JSON.stringify([target.tenantId,String(info.skuId)]);
     const old=(await readJournal())[pendingKey];
     if(old&&['saving','unknown'].includes(old.state))throw fail('CARTON_SAVE_UNCONFIRMED','此商品上次保存结果待核实，已禁止重复提交；请先到商品主档核对箱规');
     await saveEntry({state:'saving',operationId,target:{tenantId:target.tenantId,upc:target.upc},quantity,skuId:String(info.skuId),spuId:String(info.spuId),unitName:info.unitName,expectedSemanticFingerprint:info.expectedSemanticFingerprint});registered=true;
    }
   };
   const call=async(operation,body)=>{
    if(!['products','master','options','check','saveMaster','units'].includes(operation))throw fail('CARTON_API_DENIED','不支持的箱规接口');
    if(operation==='saveMaster'&&!registered)throw fail('CARTON_NO_INTENT','箱规保存尚未登记');
    // The workflow already awaits each response and serializes user actions.
    // Manual additions do not need the batch runner's artificial request gap.
    await guard();if(operation==='saveMaster')submitted=true;
    const outputs=await api.scripting.executeScript({target:{tabId,...(sender.documentId?{documentIds:[sender.documentId]}:{frameIds:[0]})},world:'MAIN',func:requestQnhCartonApi,args:[{operation,body}]});
    const r=outputs[0]?.result;
    if(!r?.ok)throw fail('CARTON_TRANSPORT_ERROR',r?.message||'箱规接口未响应，未确认保存结果');
    if(r.httpStatus<200||r.httpStatus>=300)throw fail('CARTON_HTTP_ERROR','箱规接口返回HTTP '+r.httpStatus);
    const parsed=parseCartonJson(r.text);
    if(!parsed||!['0',0].includes(parsed.code)||parsed.success===false||!Object.hasOwn(parsed,'data')){
     const e=fail('CARTON_API_ERROR','箱规接口未成功：'+String(parsed?.message??parsed?.msg??parsed?.code??'响应无效'));e.explicitRejection=parsed?.success===false;throw e;
    }
    return parsed.data;
   };
   try{
    await guard();const result=await addUnit({target:{...target},quantity},{call,checkpoint});
    pendingKey=JSON.stringify([target.tenantId,String(result.skuId)]);
    if(registered)await saveEntry({state:'verified',operationId,unitName:result.unitName,quantity,unitCode:result.unitCode});
    verified=true;
    let refreshToken,refreshError;
    if(/^[a-zA-Z0-9-]{8,80}$/.test(payload.anchor||'')){
     try{
      refreshToken=operationId;
      const {cartonFormRefreshes={}}=await api.storage.local.get('cartonFormRefreshes');
      const entries=Object.entries(cartonFormRefreshes).filter(([,v])=>v.expires>clock()).slice(-30);
      entries.push([refreshToken,{target,result,anchor:payload.anchor,tabId,documentId:sender.documentId||null,route:boundRoute,expires:clock()+600000}]);
      await api.storage.local.set({cartonFormRefreshes:Object.fromEntries(entries)});
     }catch{refreshToken=undefined;refreshError='主档箱规已处理，但本机刷新记录保存失败，请重新进入当前商品查看箱规';}
    }
    return {...result,refreshToken,refreshError,message:(result.status==='reused'?'已复用':'已新增')+'货品单位：'+result.unitName+'＝'+quantity+result.baseUnit};
   }catch(e){if(registered&&!verified)await saveEntry({state:!submitted||e.explicitRejection?'rejected':'unknown',errorCode:e.code||'CARTON_ERROR',mismatchPaths:e.mismatchPaths||[]}).catch(()=>{});throw e;}
  });
  queue=work.catch(()=>{});
  try{return await work;}finally{active.delete(key);}
 };
 // A retry can only apply a previously verified result to the same document and
 // field. There is deliberately no route from here to any master write API.
 handle.refresh=async(payload,sender)=>{
  authorize(sender);
  const {cartonFormRefreshes={}}=await api.storage.local.get('cartonFormRefreshes'),entry=cartonFormRefreshes[payload?.refreshToken];
  if(!entry||entry.expires<=clock()||entry.tabId!==sender.tab.id||entry.documentId!==(sender.documentId||null))throw fail('CARTON_REFRESH_EXPIRED','箱规刷新记录已失效，请重新进入当前商品查看箱规');
  const tab=await api.tabs.get(sender.tab.id),url=pageUrl(tab.url);
  if(!url||routeIdentity(url)!==entry.route)throw fail('CARTON_TARGET_CHANGED','页面已切换，已停止刷新箱规');
  const current=await api.tabs.sendMessage(sender.tab.id,{type:'QNH_CARTON_GET_TARGET'},{frameId:0,...(sender.documentId?{documentId:sender.documentId}:{})});
  if(!current?.ok||identity(current.data?.target)!==identity(entry.target)||current.data.anchor!==entry.anchor)throw fail('CARTON_TARGET_CHANGED','当前商品、租户或箱规表单已变化，已停止刷新');
  const outputs=await api.scripting.executeScript({target:{tabId:sender.tab.id,...(sender.documentId?{documentIds:[sender.documentId]}:{frameIds:[0]})},world:'MAIN',func:selectQnhCartonUnit,args:[{anchor:entry.anchor,target:entry.target,result:entry.result,deadline:Date.now()+6000}]});
  const result=outputs[0]?.result;
  if(!result?.ok)throw fail('CARTON_FORM_REFRESH_FAILED',result?.message||'原生箱规列表刷新失败');
  return {...result,message:'箱规已更新并自动选中：'+entry.result.unitName+'＝'+entry.result.quantity+entry.result.baseUnit};
 };
 return handle;
}
