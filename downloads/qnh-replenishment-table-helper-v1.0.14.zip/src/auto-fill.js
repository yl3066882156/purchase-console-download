import {computeBackendPrice,maintenanceFingerprint,validateMaintenanceDraft,validPreserveQuantityConfirmation} from './maintenance.js';
import {resolveFillQuantity,isFreshCheckoutPrice,validateCheckoutPriceSource} from './draft-defaults.js';

const fail=(code,message)=>Object.assign(new Error(message),{code});
export function targetIdentity(snapshot){return JSON.stringify([snapshot?.sourceTabId??null,snapshot?.tenantId||'',snapshot?.relationId||'',snapshot?.backendUpc||'',snapshot?.nativeEditor?.bindingId||snapshot?.rowRef||'',snapshot?.nativeEditor?.routeKey||'']);}
export function assertSameTarget(before,after){
 if(!after?.tenantId||!after.nativeEditor)throw fail('NO_EDITOR','请先在牵牛花打开当前商品的新增或编辑表单。');
 if(before?.nativeEditor&&targetIdentity(before)!==targetIdentity(after))throw fail('TARGET_CHANGED','牵牛花已切换到其他商品或表单，请重新选择对应的SKU。');
}

/** A SKU click can connect directly; no sidebar snapshot or UPC query is required. */
export async function connectFormForSku({tabs,tabId,selection,request,checkpoint=()=>{},onTarget=()=>{},wait=ms=>new Promise(resolve=>setTimeout(resolve,ms)),attempts=4}){
 const targets=tabs.filter(t=>['qnh','qnh_reference','demo'].includes(t.kind)),active=targets.filter(t=>t.active);
 const target=active.length===1?active[0]:targets.find(t=>t.id===tabId)||(targets.length===1?targets[0]:null);
 if(!target)throw fail('NO_EDITOR','请先在牵牛花选好商品并打开新增或编辑表单，再点击规格。');
 checkpoint();onTarget(target.id);
 const quantity=resolveFillQuantity(selection?.spec);
 const planQuantity=quantity.status==='unrecognized'?{ratioQnh:'',preserveQuantity:true}:{ratioQnh:quantity.quantity};
 const isReference=target.kind==='qnh_reference';
 const transient=new Set(['NO_EDITOR','EDITOR_NOT_OPENED','NO_NEW_FORM','UNBOUND_NEW_PRODUCT']);
 if(isReference)transient.add('EDITOR_REPLACED');
 for(let attempt=0;attempt<attempts;attempt++){
  checkpoint();
  try{
   let data;
   try{data=await request('INSPECT_EDITOR',{tabId:target.id,newSelection:true});}
   catch(error){
    checkpoint();
    if(!['NO_EDITOR','EDITOR_NOT_OPENED'].includes(error.code)||target.kind==='qnh_reference')throw error;
    try{data=await request('PLAN_NEW_FORM_COMPLETION',{tabId:target.id,...planQuantity});}
    catch(planError){if(planError.code==='NEW_FORM_ONLY')throw error;throw planError;}
   }
   checkpoint();
   if(data.snapshot?.routeMode==='new'&&!data.completionPlan){
    data=await request('PLAN_NEW_FORM_COMPLETION',{tabId:target.id,...planQuantity});checkpoint();
   }
   const s=data.snapshot;if(!s)throw fail('NO_EDITOR','当前表单仍在加载，请打开目标商品的新增或编辑表单后再选规格。');
   const referenceLoading=isReference&&s.nativeEditor?.reasons?.some(reason=>reason==='REFERENCE_PRODUCT_UNVERIFIED'||reason==='REFERENCE_SUPPLIER_UNVERIFIED');
   const loading=referenceLoading||!s.tenantId||!s.nativeEditor||!s.backendUpc||s.backendUpcSource!=='native_product'||s.nativeEditor.fieldsComplete===false;
   if(!loading||data.canApply===true||attempt===attempts-1)return {tabId:target.id,...data};
  }catch(error){
   checkpoint();
   if(!transient.has(error.code)||attempt===attempts-1){
    if(target.kind==='qnh_reference'&&['NO_EDITOR','EDITOR_NOT_OPENED'].includes(error.code))throw fail('NO_EDITOR','请先在补货参考中打开目标商品的网采关系编辑抽屉，再选择规格。');
    throw error;
   }
  }
  await wait(250);checkpoint();
 }
}

/** A click on a specific SKU authorizes filling, never native Save/Submit. */
export function prepareAutomaticDraft(snapshot,input,{actionId,manualQuantity=false,defaultUnknownToOne=false}={}){
 if(typeof actionId!=='string'||!actionId)throw fail('NO_SELECTION_INTENT','请先选择一个商品规格。');
 const draft=structuredClone(input),c=draft.candidate||{},isNew=snapshot.routeMode==='new';
 if(!c.goodsId||!c.skuId||!c.spec)throw fail('INCOMPLETE_SKU','当前商品缺少明确规格，请在官网打开详情补全。');
 if(draft.manualPurchasePrice===true){draft.autoActualPrice=false;draft.pricingPolicy='manual_purchase';}
 else if(draft.autoActualPrice!==false){
  if(!isFreshCheckoutPrice(c))throw fail('QUOTE_REQUIRED','尚未读取到该SKU的有效实价，请处理官网提示后继续。');
  c.price=validateCheckoutPriceSource(c).value;c.priceUnit='yuan';draft.pricingPolicy='checkout_payable';
 }else if(!draft.manualPriceOverride)throw fail('QUOTE_REQUIRED','请先读取实价，或主动选择手动改价。');
 const quantity=resolveFillQuantity(c.spec,snapshot.backendSpec||snapshot.backendUnit||'');
 const defaultQuantity=!manualQuantity&&defaultUnknownToOne&&quantity.status==='unrecognized';
 const preserveQuantity=!defaultQuantity&&!manualQuantity&&draft.manualPurchasePrice===true&&quantity.status==='unrecognized';
 if(preserveQuantity){
  if(!validPreserveQuantityConfirmation(snapshot,draft))throw fail('PRESERVE_QUANTITY_CONFIRMATION_REQUIRED','规格数量未知：原比例可能来自上个SKU，请核对原值后专门确认，或展开填写两侧人工比例。');
  draft.ratioPdd=snapshot.nativeFields?.ratioPdd??'';
  draft.ratioQnh=snapshot.nativeFields?.ratioQnh??'';
 }else{
  if(!manualQuantity){draft.ratioPdd='1';draft.ratioQnh=defaultQuantity?'1':quantity.quantity;}
  if(!draft.ratioPdd||!draft.ratioQnh)throw fail('QUANTITY_REQUIRED','请填写两侧下单比例后继续代填。');
 }
 if(preserveQuantity||defaultQuantity)draft.selectExistingCartonUnit=false;
 const precision=String(snapshot.nativeEditor?.purchasePriceDecimals??draft.purchasePriceDecimals??'2');
 draft.purchasePriceDecimals=precision;draft.priceRoundingConfirmed=true;
 const calculation=draft.manualPurchasePrice===true?null:computeBackendPrice({price:c.price,priceUnit:c.priceUnit,ratioPdd:draft.ratioPdd,ratioQnh:draft.ratioQnh,purchasePriceDecimals:precision,priceRoundingConfirmed:true});
 if(calculation&&(!calculation.purchasePrice||!/[1-9]/.test(calculation.purchasePrice)))throw fail('INVALID_PRICE','换算后的采购价无效，请核对数量与金额。');
 Object.assign(draft,{specConfirmed:true,ratioConfirmed:!preserveQuantity,scopeConfirmed:true,actualPriceConfirmed:true,newRelationConfirmed:isNew,newCompletionConfirmed:isNew&&draft.autoCompleteNewForm===true});
 draft.selectionIntent={version:1,mode:'sku_selection',actionId,goodsId:c.goodsId,skuId:c.skuId,targetIdentity:targetIdentity(snapshot),quantitySource:manualQuantity?'employee_input':preserveQuantity?'preserve':defaultQuantity?'default_one':'sku_spec',rounding:'native_precision_half_up'};
 draft.approvedFingerprint='';const validation=validateMaintenanceDraft(snapshot,draft);
 if(!validation.ok)throw fail('AUTO_FILL_BLOCKED',validation.errors.join('；'));
 draft.approvedFingerprint=maintenanceFingerprint(snapshot,draft);
 return {draft,calculation,quantity};
}

/** Only the latest selection may reach the write stage. Startup/sync never starts a job. */
export function createAutoFillFlow({connect,quote,prepare,fill,onState=()=>{}}){
 let serial=0,active=null,writer=null,lastState={stage:'idle'};
 const current=job=>active===job&&job.serial===serial;
 const checkpoint=job=>{if(!current(job))throw fail('SUPERSEDED','已切换到其他SKU。');};
 const report=(job,stage,extra={})=>{if(current(job)){lastState={stage,selection:job.selection,actionId:job.actionId,...extra};onState(lastState);}};
 return {
  get active(){return !!active;},get writing(){return !!writer;},
  cancel(){if(writer)return false;serial++;active=null;onState({stage:'idle'});return true;},
  async start(selection,options={}){
   if(writer)return {status:'busy'};
   const job={serial:++serial,actionId:crypto.randomUUID(),selection:structuredClone(selection),options};job.current=()=>current(job);job.checkpoint=()=>checkpoint(job);active=job;
   try{
    report(job,'connecting');const context=await connect(job);checkpoint(job);
    report(job,'quoting');const quoted=await quote(context,job);checkpoint(job);
    report(job,'checking');const prepared=await prepare(context,quoted,job);checkpoint(job);
    writer=job;report(job,'filling');const result=await fill(prepared,job);checkpoint(job);
    report(job,'done',{result});return {status:'done',result};
   }catch(error){if(error.code==='SUPERSEDED'||!current(job))return {status:'superseded'};report(job,'blocked',{error,message:error.message||'本次代填暂停，请检查提示。'});return {status:'blocked',error};}
   finally{if(writer===job)writer=null;if(current(job)){active=null;onState(lastState);}}
  }
 };
}
