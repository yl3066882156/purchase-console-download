/** Read-only proof for one narrowly identified native-default false positive.
 * This module neither writes a field nor treats an unsaved form as saved.
 */
import {parsePddLink,stableStringify} from './core.js';
import {targetIdentity} from './auto-fill.js';

const SIX=['channelName','url','channelSpec','ratioPdd','ratioQnh','purchasePrice'];
const STEPS=['channelOther','supplierFirst','multiple','scopeAll','sixFields'];
const RULES={channelOther:true,supplier:'first_available',orderMultiple:'ratioQnh',scope:'all_selectable_stores',defaultSupply:'preserve'};
const str=value=>typeof value==='string'?value:'';
const norm=value=>str(value).normalize('NFKC').replace(/\r\n?/g,'\n').trim();
const compact=value=>norm(value).replace(/\s+/g,'');
const equal=(a,b)=>stableStringify(a)===stableStringify(b);
const check=(condition,message)=>{if(!condition)throw Error(message);};
const id=value=>typeof value==='string'&&/^[1-9]\d*$/.test(value);
function number(value){
  if(typeof value!=='string'||value.length>100||!/^\d+(?:\.\d+)?$/.test(value))return '';
  const [head,tail='']=value.split('.'),whole=head.replace(/^0+(?=\d)/,'');
  const fraction=tail.replace(/0+$/,'');return whole+(fraction?'.'+fraction:'');
}
const decimalEqual=(a,b)=>number(a)!==''&&number(a)===number(b);
function supplier(value){
  const lines=norm(value).split('\n').map(s=>s.trim()).filter(Boolean);
  while(['供应商','供应商名称','拼'].includes(lines[0]))lines.shift();
  if(/^\(\s*\d+\s*天\s*\)$/.test(lines.at(-1)||''))lines.pop();
  return lines.length===1?lines[0].replace(/\s+/g,''):lines.length===0?'':null;
}
const supplierEqual=(a,b)=>supplier(a)!==null&&supplier(a)===supplier(b);
const valueText=value=>Array.isArray(value)&&value.length===1&&typeof value[0]==='string'?value[0]:typeof value==='string'?value:null;
const emptyArray=value=>Array.isArray(value)&&value.length===0;
function protectedEntries(snapshot){
  const rows=snapshot?.nativeEditor?.protectedFields;
  check(Array.isArray(rows)&&rows.length>0,'缺少完整保持字段证据，不能恢复草稿');
  const map=new Map(),keys=[];
  for(const row of rows){
    check(Array.isArray(row)&&typeof row[0]==='string','保持字段证据格式不完整');
    const control=row[0]==='business-control';
    check(control?row.length===8&&Number.isInteger(row[1])&&row[1]>=0:row.length===2,'保持字段或控件证据格式不完整');
    const key=control?'business-control:'+row[1]:row[0];check(!map.has(key),'保持字段证据存在重复项');
    map.set(key,control?row:row[1]);keys.push(key);
  }
  return {map,keys,rows};
}
function compareObjects(before,after,ignored,label){
  for(const key of new Set([...Object.keys(before),...Object.keys(after)]))if(!ignored.has(key))check(equal(before[key],after[key]),label+'发生变化：'+key);
}
function identity(receipt,before,after,current){
  check(Number.isInteger(receipt.tabId)&&receipt.tabId>=0&&id(receipt.tenantId)&&norm(receipt.rowRef),'维护记录缺少原标签页或表单身份');
  const binding=norm(before?.nativeEditor?.bindingId),route=norm(before?.nativeEditor?.routeKey),upc=str(before?.backendUpc);
  check(binding&&route&&/^\d{8,18}$/.test(upc),'原记录缺少完整绑定、路由或UPC');
  check(!receipt.relationId,'已有关系不能按新增草稿恢复');
  for(const s of [before,after,current]){
    check(s&&typeof s==='object'&&s.nativeEditor&&typeof s.nativeEditor==='object','缺少完整原生表单快照');
    check(s.sourceTabId===receipt.tabId&&s.tenantId===receipt.tenantId&&s.rowRef===receipt.rowRef,'标签页、租户或原表单行已变化');
    check(s.routeMode==='new'&&!s.relationId&&s.nativeEditor.routeMode==='new'&&s.nativeEditor.identityLevel==='new_relation_form'&&s.nativeEditor.writeMode==='new_draft','当前不是原来的未提交新增表单');
    check(s.backendUpc===upc&&s.backendUpcSource==='native_product','已关联商品UPC或其原生来源已变化');
    check(s.nativeEditor.bindingId===binding&&s.nativeEditor.routeKey===route,'原生表单绑定或路由已变化；不能按UPC推测恢复');
    check(s.nativeEditor.fieldsComplete===true,'原生六项控件尚未完整识别');
    check(s.sourceTabUrl===receipt.tabUrl&&norm(s.sourceTabUrl),'原标签页地址已变化');
  }
}
function expectedFields(receipt,after,current){
  const expected=receipt.expected,fields=expected?.fields,keys=expected?.manualPurchasePrice===true?SIX.filter(k=>k!=='purchasePrice'):SIX;
  check(fields&&equal(Object.keys(fields).sort(),[...keys].sort()),'维护记录缺少完整预期值');
  if(expected?.manualPurchasePrice===true)check(receipt.beforeSnapshot?.nativeFields?.purchasePrice===after.nativeFields?.purchasePrice,'代填期间人工采购价发生变化');
  check(id(fields.channelName)&&id(fields.channelSpec)&&id(expected.goodsId)&&id(expected.skuId)&&fields.channelName===expected.goodsId&&fields.channelSpec===expected.skuId,'预期商品或SKU身份不完整');
  check(keys.filter(k=>['ratioPdd','ratioQnh','purchasePrice'].includes(k)).every(k=>number(fields[k])&&/[1-9]/.test(number(fields[k]))),'预期数量或采购价无效');
  const url=new URL(fields.url),parsed=parsePddLink(fields.url);
  check(parsed.kind==='checkout'&&parsed.goodsId===expected.goodsId&&parsed.skuId===expected.skuId&&parsed.goodsNumber==='1'&&parsed.groupId!==''&&['goods_id','sku_id','goods_number','group_id'].every(k=>url.searchParams.getAll(k).length===1),'预期结算链接身份不完整');
  check(expected.url===fields.url,'预期结算链接记录互相矛盾');
  for(const s of [after,current]){
    check(s.nativeFields&&typeof s.nativeFields==='object','缺少当前六项值');
    for(const key of keys)check(['ratioPdd','ratioQnh','purchasePrice'].includes(key)?decimalEqual(s.nativeFields[key],fields[key]):s.nativeFields[key]===fields[key],(expected?.manualPurchasePrice===true?'已填值':'六项值')+'未完整符合预期：'+key);
    check(s.nativeFields.channelCode===expected.goodsId,'原生联动商品编码与预期不一致');
  }
  return fields;
}
function recordedSteps(receipt,before,after,fields){
  const operations=receipt.operations,plan=receipt.expected?.completionPlan;
  check(Array.isArray(operations)&&operations.length===5,'补齐步骤记录不完整，不能略过未执行步骤');
  for(let i=0;i<STEPS.length;i++)check(operations[i]?.id===STEPS[i]&&operations[i]?.step===STEPS[i]&&operations[i]?.status===(i===4?'failed':'completed'),'补齐步骤顺序或完成状态不符合本次恢复条件');
  check(plan?.version===1&&plan.mode==='new_draft_completion'&&equal(plan.rules,RULES)&&norm(plan.planFingerprint),'缺少明确批准的四项补齐规则');
  const b=plan.binding||{};
  for(const [key,value]of Object.entries({tenantId:before.tenantId,backendUpc:before.backendUpc,rowRef:before.rowRef,bindingId:before.nativeEditor.bindingId,routeKey:before.nativeEditor.routeKey,beforeFingerprint:before.fingerprint}))check(typeof value==='string'&&value&&b[key]===value,'补齐计划与原表单绑定不一致：'+key);
  check(decimalEqual(plan.ratioQnh,fields.ratioQnh),'补齐计划数量与预期不一致');
  const [channelStep,supplierStep,multipleStep,scopeStep,sixStep]=operations;
  check(norm(channelStep.after)==='其他采购平台'&&norm(after.procurementChannelText)==='其他采购平台'&&norm(channelStep.before)===norm(before.procurementChannelText),'采购渠道完成记录不一致');
  const procurement=after.nativeEditor.sourceEvidence?.procurement;
  check(procurement?.conflict===false&&equal(procurement.selected,['其他采购平台'])&&procurement.options?.filter(o=>o.selected===true).length===1&&procurement.options.some(o=>o.selected===true&&norm(o.text)==='其他采购平台'&&o.conflict===false),'缺少原生其他采购平台的唯一选中证据');
  check(supplier(supplierStep.after)&&supplierEqual(supplierStep.after,after.supplier)&&supplierEqual(supplierStep.before,before.supplier),'供应商步骤与记录后的唯一供应商不一致');
  check(decimalEqual(multipleStep.after,fields.ratioQnh),'起订倍数步骤未填写预期数量');
  check(compact(scopeStep.before)===compact(before.scopeText)&&compact(scopeStep.after)&&compact(scopeStep.after)===compact(after.scopeText)&&compact(after.completionScopeSummary)===compact(after.scopeText),'门店供货范围完成记录与快照不一致');
  check(plan.before&&norm(plan.before.channel)===norm(before.procurementChannelText)&&supplierEqual(plan.before.supplier,before.supplier)&&compact(plan.before.scope)===compact(before.scopeText)&&norm(plan.before.orderMultiple)===norm(multipleStep.before),'补齐计划的原始值与步骤记录不一致');
  check(sixStep.after==null&&equal(sixStep.before,before.nativeFields),'六项失败步骤与原生起始值不一致');
  for(const [index,field]of [[1,'supplier'],[2,'orderMultiple'],[3,'scopeText']]){
    const step=operations[index],changes=step.changedFields;
    check(Array.isArray(changes)&&changes.length<=1,'补齐步骤缺少可核对的字段变化记录');
    check(changes.every(c=>c?.field===field&&equal(c.before,step.before)&&equal(c.after,step.after)),'补齐步骤包含未批准或不一致的变化');
    if(!equal(step.before,step.after))check(changes.length===1,'补齐步骤遗漏了实际变化记录');
  }
  check(Array.isArray(channelStep.changedFields)&&channelStep.changedFields.length===0,'采购渠道步骤包含额外变化');
  return {channelStep,supplierStep,multipleStep,scopeStep};
}

/** {ok,reasons,nativeDefaultChanges}; no platform writes, replay or saved-state claim. */
export function validateDraftRecovery(receipt,currentSnapshot){
  try{
    check(receipt?.state==='completion_partial'&&receipt.errorCode==='PROTECTED_FIELDS_CHANGED'&&receipt.writeMode==='new_draft_completion'&&receipt.submitted===false,'仅可只读重核本次保持字段误报的未提交新增草稿');
    const before=receipt.beforeSnapshot,after=receipt.afterSnapshot,current=currentSnapshot;
    identity(receipt,before,after,current);
    const fields=expectedFields(receipt,after,current),steps=recordedSteps(receipt,before,after,fields),quantity=fields.ratioQnh;
    const logged=new Map(),allowedChanges=[...SIX.map(key=>'nativeFields.'+key),'supplier','procurementChannelText','scopeText'];
    check(Array.isArray(receipt.changedFields),'缺少本轮字段变化记录');
    for(const entry of receipt.changedFields){
      check(entry&&allowedChanges.includes(entry.field)&&!logged.has(entry.field),'本轮记录包含额外或重复的字段变化');
      const read=s=>entry.field.startsWith('nativeFields.')?s.nativeFields[entry.field.slice(13)]:s[entry.field];
      check(equal(entry.before,read(before))&&equal(entry.after,read(after)),'本轮字段变化记录与前后快照不一致');logged.set(entry.field,entry);
    }
    for(const field of allowedChanges){const read=s=>field.startsWith('nativeFields.')?s.nativeFields[field.slice(13)]:s[field];if(norm(read(before))!==norm(read(after)))check(logged.has(field),'本轮字段变化记录遗漏了实际变化：'+field);}
    if(receipt.selectionIntent)check(receipt.selectionIntent.mode==='sku_selection'&&norm(receipt.selectionIntent.actionId)&&receipt.selectionIntent.goodsId===receipt.expected.goodsId&&receipt.selectionIntent.skuId===receipt.expected.skuId&&receipt.selectionIntent.targetIdentity===targetIdentity(before),'选规格意图与原始商品或表单不一致');
    const prior=protectedEntries(before),recorded=protectedEntries(after),observed=protectedEntries(current);
    check(equal(prior.keys,recorded.keys),'前后保持字段清单或控件顺序变化，不能推测控件身份');
    check(equal(recorded.rows,observed.rows),'当前保持字段、供货范围或控件值与已记录结果不同');
    check(emptyArray(prior.map.get('起订量')),'原起订量并非明确空值，不能将其变化视为原生默认');
    const minimum=valueText(recorded.map.get('起订量'));
    check(decimalEqual(minimum,quantity)&&Array.isArray(recorded.map.get('起订量'))&&recorded.map.get('起订量').length===1,'原生起订量未唯一联动为后台数量');
    const roles=current.nativeEditor.recoveryControlRoles;
    check(Array.isArray(roles)&&roles.length>0,'缺少当前DOM的起订量/起订倍数控件角色证据');
    const roleMap=new Map(),seenRoles=new Set();
    for(const item of roles){
      check(item&&Number.isInteger(item.index)&&['orderMinimum','orderMultiple'].includes(item.role)&&!roleMap.has(item.index)&&!seenRoles.has(item.role)&&observed.map.has('business-control:'+item.index),'当前控件角色证据不唯一或无对应控件');
      roleMap.set(item.index,item.role);seenRoles.add(item.role);
    }
    const changedControls=[],minimumControls=[];
    for(const key of prior.keys){
      const b=prior.map.get(key),a=recorded.map.get(key);if(equal(b,a))continue;
      if(key.startsWith('business-control:')){
        const index=b[1],role=roleMap.get(index);
        check(role&&changedControls.length<2&&b[5]===''&&decimalEqual(a[5],quantity)&&equal(b.slice(0,5),a.slice(0,5))&&equal(b.slice(6),a.slice(6)),'有不相关、非空或状态改变的保持控件：'+index);
        if(role==='orderMinimum')minimumControls.push(index);
        else check(norm(steps.multipleStep.before)===''&&emptyArray(prior.map.get('起订倍数'))&&decimalEqual(valueText(recorded.map.get('起订倍数')),quantity),'起订倍数控件变化缺少对应的空值补齐记录');
        changedControls.push(index);continue;
      }
      if(['供应商','供应商名称','supplier'].includes(key)){
        const priorText=valueText(b),afterText=valueText(a);check((priorText!==null&&supplierEqual(priorText,before.supplier)||emptyArray(b)&&['','输入供应商名称搜索','请选择'].includes(norm(before.supplier)))&&afterText!==null&&supplierEqual(afterText,after.supplier),'供应商保持证据存在额外变化');continue;
      }
      if(key==='起订量')continue;
      if(['起订倍数','下单倍数'].includes(key)){
        check(emptyArray(b)&&norm(steps.multipleStep.before)===''&&Array.isArray(a)&&a.length===1&&decimalEqual(a[0],quantity),'非空或无步骤对应的起订倍数变化');continue;
      }
      if(['采购渠道','channel'].includes(key)){
        check(norm(valueText(b))===norm(steps.channelStep.before)&&norm(valueText(a))===norm(steps.channelStep.after),'采购渠道保持证据出现额外变化');continue;
      }
      if(['供货范围','门店','中心仓','scopeText'].includes(key)){
        check(valueText(b)!==null&&valueText(a)!==null&&compact(valueText(b))===compact(steps.scopeStep.before)&&compact(valueText(a))===compact(steps.scopeStep.after),'供货范围保持证据出现额外变化');continue;
      }
      check(false,'未批准的保持字段变化：'+key);
    }
    check(minimumControls.length===1,'未能从同一DOM控件证明起订量的空值联动');
    const multipleBefore=prior.map.get('起订倍数'),multipleAfter=recorded.map.get('起订倍数');
    check(equal(multipleBefore,multipleAfter)||emptyArray(multipleBefore)&&norm(steps.multipleStep.before)===''&&decimalEqual(valueText(multipleAfter),quantity),'起订倍数记录与保持证据不一致');
    check(decimalEqual(valueText(multipleAfter),quantity),'记录后起订倍数不是预期后台数量');
    check(equal(before.nativeEditor.sourceEvidence?.product,after.nativeEditor.sourceEvidence?.product),'补齐期间关联商品卡片发生变化');
    const derived=new Set(['channel','channelSpec','completionScopeSummary','constraintsText','fingerprint','nativeFields','nativeEditor','oldUrl','pddGoodsId','pddSkuId','ratioRaw','scopeText','supplier']);
    compareObjects(before,after,derived,'补齐期间未授权的商品或保持信息');
    check(before.channel===after.channel||before.channel==='1688'&&after.channel==='pdd'&&norm(before.procurementChannelText)==='其他采购平台','采购渠道分类出现无法解释的变化');
    for(const [key,value]of Object.entries({channelSpec:fields.channelSpec,pddGoodsId:fields.channelName,pddSkuId:fields.channelSpec,oldUrl:fields.url}))check(after[key]===value,'六项派生信息与预期不一致：'+key);
    check(compact(after.ratioRaw)===compact(fields.ratioPdd+'='+fields.ratioQnh),'六项派生下单比例与预期不一致');
    check(norm(before.constraintsText)===''&&compact(after.constraintsText)===compact('起订量：'+quantity+'；起订倍数：'+quantity),'采购规则包含无法解释的原生联动变化');
    compareObjects(before.nativeFields,after.nativeFields,new Set([...SIX,'channelCode']),'六项外的原生字段');
    compareObjects(after,current,new Set(['fingerprint','nativeFields','nativeEditor','issues','readOnlyFallbackFields','identityVerified']),'当前商品或保持信息');
    compareObjects(after.nativeFields,current.nativeFields,new Set([...SIX]),'当前六项外的原生字段');
    compareObjects(after.nativeEditor,current.nativeEditor,new Set(['protectionFingerprint','formFingerprint','evidenceFingerprint','reasons','warnings','canFill','recoveryControlRoles']),'当前原生编辑器保持证据');
    return {ok:true,reasons:[],nativeDefaultChanges:[{field:'orderMinimum',label:'起订量',before:'',after:quantity,controlIndexes:minimumControls}]};
  }catch(error){return {ok:false,reasons:[error?.message||'只读恢复证据不完整，请人工核对现有草稿'],nativeDefaultChanges:[]};}
}
