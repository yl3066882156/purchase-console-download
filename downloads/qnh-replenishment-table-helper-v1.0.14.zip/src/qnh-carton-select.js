/** MAIN-world adapter for the native GoodsUnitSelect/form contract.
 * Evidence: tests/native-unit-evidence/{sgfe.59aea0c5.chunk.js,
 * purchase-chunk-51.js,ahooks.c8864015.chunk.js}. No network or form submit.
 * Fail closed if that contract changes; never patch React hook state directly.
 */
export async function selectQnhCartonUnit({anchor,target,result,deadline=Date.now()+6000}) {
 const error=message=>({ok:false,message});
 try {
  if(location.origin!=='https://qnh.meituan.com'||location.pathname!=='/home.html'||location.hash.split('?')[0]!=='#/purchase/replenishment/refer')return error('仅补货参考编辑允许选择已有箱规');
  if(Date.now()>deadline)return error('箱规刷新请求已超时，请重新点击刷新箱规');
  if(!/^[a-zA-Z0-9-]{8,80}$/.test(anchor||''))return error('箱规表单标记已失效');
  const nodes=[...document.querySelectorAll('[data-qrth-carton-anchor]')].filter(n=>n.getAttribute('data-qrth-carton-anchor')===anchor);
  if(nodes.length!==1||!nodes[0].isConnected)return error('原箱规表单已关闭或替换');
  const node=nodes[0],options=result?.unitOptions,code=String(result?.unitCode||'');
  const tenants=new Set([...document.querySelectorAll('header, [role="banner"], span')].filter(n=>n.getClientRects().length).flatMap(n=>[...n.textContent.matchAll(/租户\s*ID\s*[:：]\s*([1-9]\d*)/gi)].map(m=>m[1])));
  if(tenants.size!==1||!tenants.has(target?.tenantId))return error('当前租户已变化或无法确认，已停止选择箱规');
  const selected=options?.filter(o=>String(o.cartonMeasureCode)===code);
  if(!Array.isArray(options)||!options.length||selected?.length!==1||selected[0].cartonMeasureName!==result.unitName||Number(selected[0].basicUnitConvertFactor)!==Number(result.quantity))return error('新增箱规的编码或换算未确认');
  const fiberFor=()=>{
   const key=Object.keys(node).find(k=>/^__reactFiber\$|^__reactInternalInstance\$/.test(k));
   const fiber=node[key];if(!fiber)return null;
   const path=[];for(let f=fiber;f;f=f.return)path.push(f);
   let current=path.at(-1).stateNode?.current;if(!current)return null;
   // DOM retains its original fiber pointer across React's alternate commits.
   // Resolve every ancestor through the mounted root rather than assuming the
   // original pointer (or its immediate alternate) is the committed branch.
   for(const expected of path.reverse().slice(1)){
    let child=current.child;
    while(child&&child!==expected&&child!==expected.alternate)child=child.sibling;
    if(!child)return null;current=child;
   }
   return current;
  };
  const inspect=()=>{
   let unit,form;const forms=new Set();
   for(let f=fiberFor(),depth=0;f&&depth<100;f=f.return,depth++){
    const p=f.memoizedProps;
    if(typeof f.type?.formatOptions==='function'&&Array.isArray(p?.params?.skuIdList)&&p.params.skuIdList.length===1&&String(p.params.skuIdList[0])===String(result.skuId)&&typeof p.onChange==='function'){
     if(unit)throw Error('存在多个原生箱规组件');unit=f;
    }
    if(p?.form&&typeof p.form.getFieldValue==='function'&&typeof p.form.setFieldsValue==='function')forms.add(p.form);
   }
   for(const candidate of forms){
    const product=candidate.getFieldValue('qnhGoodsInfo');
    if(String(product?.qnhGoodsId)!==String(result.skuId))continue;
    const upcs=product.qnhUpc;
    if(!Array.isArray(upcs)||!upcs.some(v=>String(v)===target.upc))continue;
    if(form&&form!==candidate)throw Error('存在多个对应商品表单');form=candidate;
   }
   if(!unit||!form)throw Error('未识别到可安全更新的原生箱规组件，请重新打开当前编辑页');
   return {unit,form};
  };
  const {unit,form}=inspect(),requests=new Set();
  // ahooks useCreation stores its Fetch instance in a ref's {obj}. Discover
  // by the captured public methods, not a numeric React hook position.
  for(let hook=unit.memoizedState,count=0;hook&&count<150;hook=hook.next,count++){
   const ref=hook.memoizedState?.current;
   for(const candidate of [ref,ref?.obj])if(candidate&&typeof candidate.mutate==='function'&&typeof candidate.cancel==='function'&&typeof candidate.runAsync==='function'&&typeof candidate.subscribe==='function'&&candidate.serviceRef&&candidate.options?.manual===true&&candidate.state&&Object.hasOwn(candidate.state,'data'))requests.add(candidate);
  }
  if(requests.size!==1||unit.memoizedProps.options)throw Error('原生箱规列表刷新接口不可用，请重新打开当前编辑页');
  const request=[...requests][0];
  const base=options.filter(o=>Number(o.basicUnitConvertFactor)===1);
  if(base.length!==1)throw Error('箱规基本单位不唯一');
  const formatted=unit.type.formatOptions(options,base[0].cartonMeasureName,{label:'cartonMeasureName',ratio:'basicUnitConvertFactor',value:'cartonMeasureCode'});
  const nativeOptions=Array.isArray(formatted)?formatted.filter(o=>String(o.unitCode)===code&&Number(o.ratio)===Number(result.quantity)):[];
  if(!Array.isArray(formatted)||formatted.length!==options.length||nativeOptions.length!==1||nativeOptions[0].label==null)throw Error('原生箱规选项转换失败');
  const nativeOption=nativeOptions[0];
  // Cancel only this component's pending read, so an old response cannot replace
  // the verified list. This does not touch another tab or background task.
  request.cancel();request.mutate(formatted);
  const previous=form.getFieldValue('purchaseUnitInfo');
  // labelInValue renders the stored label, not the menu option's text. Keep the
  // formatter's React label (including its secondary conversion suffix).
  form.setFieldsValue({purchaseUnitInfo:{...previous,unit:{value:nativeOption.value,label:nativeOption.label,unitCode:nativeOption.unitCode,unitName:nativeOption.realLabel??result.unitName,ratio:nativeOption.ratio}}});
  // setFieldsValue updates the submitted store; wait for the controlled select
  // to consume it as well before telling the employee the operation completed.
  const until=Date.now()+1200;
  do {
   const now=inspect(),stored=now.form.getFieldValue('purchaseUnitInfo')?.unit,rendered=now.unit.memoizedProps.value?.unit;
   const matches=u=>String(u?.unitCode)===code&&Number(u?.ratio)===Number(result.quantity);
   if(now.form===form&&matches(stored)&&matches(rendered)&&request.state.data?.some(o=>String(o.unitCode)===code))return {ok:true,unitCode:code,unitName:result.unitName};
   await new Promise(resolve=>setTimeout(resolve,25));
  }while(Date.now()<until);
  return error('箱规列表已更新，但未确认原生表单选中结果，请点击刷新箱规重试');
 } catch(e){return error(e.message||'箱规列表刷新失败');}
}
