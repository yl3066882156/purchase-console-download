/** Six native business fields only. Pure, credential-free review/calculation logic. */
import {parsePddLink, fingerprint} from './core.js';
import {validateCheckoutPriceSource,isFreshCheckoutPrice,resolveFillQuantity} from './draft-defaults.js';

export const MAINTENANCE_FIELDS = Object.freeze(['channelName','url','channelSpec','ratioPdd','ratioQnh','purchasePrice']);
export const LINK_FIELDS = Object.freeze(MAINTENANCE_FIELDS.filter(k=>k!=='purchasePrice'));
const titles={channelName:'渠道商品名称（商品ID）',url:'结算链接',channelSpec:'规格（SKU ID）',ratioPdd:'下单比例：拼多多',ratioQnh:'下单比例：牵牛花',purchasePrice:'采购价（后台单价/元）'};
const str=v=>String(v??'').trim();
function decimal(v,label){
  const s=str(v);if(!/^\d+(?:\.\d+)?$/.test(s)||s.length>80)throw new Error(`${label}必须是明确的正十进制数`);
  if(typeof v==='number'&&(!Number.isFinite(v)||v>Number.MAX_SAFE_INTEGER))throw new Error(`${label}数值不安全`);
  const [a,b='']=s.split('.'),n=BigInt(a+b),d=10n**BigInt(b.length);
  if(n<=0n)throw new Error(`${label}必须大于0`);return {n,d,text:s};
}
function gcd(a,b){while(b)[a,b]=[b,a%b];return a;}
function moneyText(n,d,max=12){
  let s=String(n/d),r=n%d;if(!r)return {text:s,exact:true};s+='.';
  for(let i=0;i<max&&r;i++){r*=10n;s+=String(r/d);r%=d;}return {text:s,exact:r===0n};
}
/** No Number arithmetic: PDD price × left PDD quantity ÷ right QNH quantity. */
export function computeBackendPrice({price,priceUnit,ratioPdd,ratioQnh,purchasePriceDecimals='2',priceRoundingConfirmed=false}={}){
  const p=decimal(price,'拼多多价格'),l=decimal(ratioPdd,'拼多多比例'),r=decimal(ratioQnh,'牵牛花比例');
  let n=p.n*l.n*r.d,d=p.d*l.d*r.n;
  if(['fen','分'].includes(priceUnit))d*=100n;
  else if(!['yuan','元','CNY'].includes(priceUnit))throw new Error('请确认拼多多价格单位为元或分');
  const g=gcd(n,d);n/=g;d/=g;
  const exact=moneyText(n,d),cents=(n*100n*2n+d)/(2n*d);
  const precision=String(purchasePriceDecimals);if(!/^[0-6]$/.test(precision))throw new Error('采购价精度必须是0至6位小数');
  const places=Number(precision),tail=exact.text.split('.')[1]||'',roundingRequired=!exact.exact||tail.length>places;
  const scale=10n**BigInt(places),rounded=(n*scale*2n+d)/(2n*d);
  const roundedText=places?`${rounded/scale}.${String(rounded%scale).padStart(places,'0')}`:String(rounded);
  const accepted=roundingRequired?(priceRoundingConfirmed===true?roundedText:''):exact.text;
  // A repeating rational cannot be represented by an input. Require a reviewed
  // explicit rounding choice instead of silently inventing platform precision.
  return {formula:'拼多多价格（元）× 拼多多比例 ÷ 牵牛花比例',ratioDirection:'pdd_left_equals_qnh_right',
    numerator:String(n),denominator:String(d),decimalText:exact.text+(exact.exact?'':'…'),decimalIsExact:exact.exact,
    purchasePrice:accepted,roundingRequired,purchasePriceDecimals:precision,priceRoundingConfirmed:priceRoundingConfirmed===true,roundedText,roundingMode:'half_up',display:`${cents/100n}.${String(cents%100n).padStart(2,'0')}`,
    displayRounding:'half_up_2_decimals_preview_only',currency:'CNY',priceUnit:'yuan'};
}
function prepare(draft={}){
  const parsed=parsePddLink(str(draft.url));if(parsed.kind!=='checkout'||!parsed.skuId)throw new Error('请选择明确SKU的完整结算链接');
  if(!parsed.groupId)throw new Error('结算链接缺少group_id，请重新选择SKU生成完整链接');
  if(parsed.goodsNumber!=='1')throw new Error('当前结算购买数量不是1，请从官方商品页重新读取SKU；不会自动改写原链接数量');
  const c=draft.candidate||{};
  if(['goodsId','skuId'].some(k=>typeof c[k]==='number'&&!Number.isSafeInteger(c[k])))throw new Error('候选商品ID和SKU ID必须保留完整字符串');
  if(!str(c.goodsId)||!str(c.skuId))throw new Error('候选商品缺少明确商品ID或SKU ID');
  if(str(c.goodsId)!==parsed.goodsId||str(c.skuId)!==parsed.skuId)throw new Error('候选商品/SKU与结算链接不一致');
  if(draft.manualPurchasePrice===true){
    if(draft.selectionIntent?.quantitySource==='preserve')return {parsed,calculation:null,fields:{channelName:parsed.goodsId,url:str(draft.url),channelSpec:parsed.skuId}};
    decimal(draft.ratioPdd,'拼多多比例');decimal(draft.ratioQnh,'牵牛花比例');
    return {parsed,calculation:null,fields:{channelName:parsed.goodsId,url:str(draft.url),channelSpec:parsed.skuId,ratioPdd:str(draft.ratioPdd),ratioQnh:str(draft.ratioQnh)}};
  }
  const calculation=computeBackendPrice({price:c.price,priceUnit:c.priceUnit,ratioPdd:draft.ratioPdd,ratioQnh:draft.ratioQnh,purchasePriceDecimals:draft.purchasePriceDecimals??'2',priceRoundingConfirmed:draft.priceRoundingConfirmed});
  if(!calculation.purchasePrice)throw Object.assign(new Error('后台单价需要舍入；请明确采购价小数位数并单独确认四舍五入，包装比例保持真实含义'),{calculation});
  if(!/[1-9]/.test(calculation.purchasePrice))throw Object.assign(new Error('舍入后采购价为0，请核对允许精度及原始价格，不会改变包装比例'),{calculation});
  const fields={channelName:parsed.goodsId,url:str(draft.url),channelSpec:parsed.skuId,ratioPdd:str(draft.ratioPdd),ratioQnh:str(draft.ratioQnh),purchasePrice:calculation.purchasePrice};
  return {parsed,calculation,fields};
}
export function preserveQuantityBinding(snapshot,candidate){return JSON.stringify([snapshot?.fingerprint, snapshot?.sourceTabId??null,snapshot?.tenantId||'',snapshot?.relationId||'',snapshot?.backendUpc||'',snapshot?.nativeEditor?.bindingId||snapshot?.rowRef||'',snapshot?.nativeEditor?.routeKey||'',candidate?.goodsId,candidate?.skuId,candidate?.spec,String(snapshot?.nativeFields?.ratioPdd??''),String(snapshot?.nativeFields?.ratioQnh??'')]);}
export function validPreserveQuantityConfirmation(snapshot,draft,now=Date.now()){
 const c=draft?.preserveQuantityConfirmation;
 return !!c&&c.version===1&&Number.isFinite(c.confirmedAt)&&now>=c.confirmedAt&&now-c.confirmedAt<=120000&&c.binding===preserveQuantityBinding(snapshot,draft.candidate);
}
export function maintenanceFingerprint(snapshot,draft){
  return fingerprint({version:'maintenance-v3',snapshot,draft:{url:draft?.url,candidate:draft?.candidate,ratioPdd:draft?.ratioPdd,ratioQnh:draft?.ratioQnh,
    selectExistingCartonUnit:draft?.selectExistingCartonUnit===true,preserveQuantityConfirmation:draft?.preserveQuantityConfirmation||null,manualPurchasePrice:draft?.manualPurchasePrice===true,pricingPolicy:draft?.pricingPolicy||'',autoActualPrice:draft?.autoActualPrice!==false,actualPriceConfirmed:draft?.actualPriceConfirmed===true,selectionIntent:draft?.selectionIntent||null,
    autoCompleteNewForm:draft?.autoCompleteNewForm===true,newCompletionConfirmed:draft?.newCompletionConfirmed===true,completionPlan:draft?.completionPlan||null,completionCanApply:draft?.completionCanApply===true,
    newRelationConfirmed:draft?.newRelationConfirmed===true,specConfirmed:draft?.specConfirmed===true,ratioConfirmed:draft?.ratioConfirmed===true,scopeConfirmed:draft?.scopeConfirmed===true,purchasePriceDecimals:draft?.purchasePriceDecimals??'2',priceRoundingConfirmed:draft?.priceRoundingConfirmed===true}});
}
export function maintenanceDiff(snapshot,draft){
  const {fields}=prepare(draft),rows=Object.keys(fields).map(field=>({field,label:titles[field],before:str(snapshot?.nativeFields?.[field]),after:fields[field],changed:str(snapshot?.nativeFields?.[field])!==fields[field]}));
  if(draft.newCompletionConfirmed===true){
    const plan=draft.completionPlan||{},before=plan.before||{},supplier=plan.supplierEvidence||{},scope=plan.scopeEvidence||{};
    const afterSupplier=supplier.status==='read'?str(supplier.label):'执行时当前第一个可选供应商（预览未枚举候选）';
    const afterScope=scope.status==='read'?'按门店全选全部可选门店（'+str(scope.count)+'家）':'按门店全选执行时全部可选门店（预览未读取数量）';
    const preserveQuantity=draft.selectionIntent?.quantitySource==='preserve';
    for(const [field,label,current,after]of [['completion.channel','采购渠道',before.channel??snapshot?.procurementChannelText,'其他采购平台'],['completion.supplier','供应商',before.supplier??snapshot?.supplier,afterSupplier],...(preserveQuantity?[]:[['completion.orderMultiple','起订倍数',before.orderMultiple,str(draft.ratioQnh)]]),['completion.scope','门店供货范围',before.scope,afterScope]])rows.push({field,label,before:str(current)||'当前值未读取',after,changed:str(current)!==after});
  }
  return rows;
}
export const buildMaintenanceDiff=maintenanceDiff;
export function validateMaintenanceDraft(snapshot={},draft={}){
  const errors=[],warnings=[],assistErrors=[],isNew=snapshot.routeMode==='new'||snapshot.nativeEditor?.writeMode==='new_draft',completion=draft.newCompletionConfirmed===true;let parsed=null,fields={},calculation=null,diff=[];
  try{({parsed,fields,calculation}=prepare(draft));diff=maintenanceDiff(snapshot,draft);}catch(e){errors.push(e.message);calculation=e.calculation||null;}
  if(!str(draft.candidate?.spec))errors.push('缺少候选SKU的包装规格描述，不能仅凭SKU ID确认包装');
  if(draft.specConfirmed!==true)errors.push('请确认商品包装及具体规格，规格文字不会写入SKU ID字段');
  const preserveQuantity=draft.selectionIntent?.quantitySource==='preserve';
  if(!preserveQuantity&&draft.ratioConfirmed!==true)errors.push('请确认左侧拼多多数量等于右侧牵牛花数量');
  if(draft.scopeConfirmed!==true)errors.push('请确认本次网采关系的供货范围及保持字段');
  const c=draft.candidate||{};
  if(draft.selectionIntent){const i=draft.selectionIntent,identity=JSON.stringify([snapshot.sourceTabId??null,snapshot.tenantId||'',snapshot.relationId||'',snapshot.backendUpc||'',snapshot.nativeEditor?.bindingId||snapshot.rowRef||'',snapshot.nativeEditor?.routeKey||'']);if(i.version!==1||i.mode!=='sku_selection'||typeof i.actionId!=='string'||!i.actionId||i.goodsId!==c.goodsId||i.skuId!==c.skuId||i.targetIdentity!==identity||!['employee_input','sku_spec','preserve','default_one'].includes(i.quantitySource)||i.rounding!=='native_precision_half_up')assistErrors.push('自动代填意图与当前SKU或目标表单不一致，请重新选择规格');}
  if(draft.selectionIntent?.quantitySource==='default_one'&&(draft.manualPurchasePrice!==true||str(draft.ratioPdd)!=='1'||str(draft.ratioQnh)!=='1'||resolveFillQuantity(c.spec,snapshot.backendSpec||snapshot.backendUnit||'').status!=='unrecognized'))assistErrors.push('仅未识别到数量时可使用默认比例 1＝1');
  if(preserveQuantity&&!validPreserveQuantityConfirmation(snapshot,draft))errors.push('未知规格需重新确认保留当前原生比例（确认有效期2分钟）');
  if(preserveQuantity&&(draft.manualPurchasePrice!==true||resolveFillQuantity(c.spec,snapshot.backendSpec||'').status!=='unrecognized'))assistErrors.push('当前规格不能使用数量手填模式，请重新选择规格');
  if(draft.manualPurchasePrice!==true&&draft.pricingPolicy==='actual_after_coupon'&&draft.actualPriceConfirmed!==true)errors.push('请确认SKU报价为券后实际单价，券前参考价不能直接作为采购成本');
  if(draft.manualPurchasePrice!==true&&draft.pricingPolicy==='checkout_payable'){
    const quote=validateCheckoutPriceSource(c);
    if(!quote.valid)errors.push('尚未读取当前SKU的应付价：'+quote.message);
    else if(!isFreshCheckoutPrice(c))errors.push('当前应付报价已过期，请重新读取实价');
    else try{if((parsePddLink(str(draft.url)).groupId??'')!==(new URL(quote.source.sourceUrl).searchParams.get('group_id')??''))errors.push('应付报价的拼团组与拟填写结算链接不一致');const exact=computeBackendPrice({price:c.price,priceUnit:c.priceUnit,ratioPdd:'1',ratioQnh:'1'}),quoted=computeBackendPrice({price:c.actualPayPrice,priceUnit:c.actualPayPriceUnit,ratioPdd:'1',ratioQnh:'1'});if(exact.numerator!==quoted.numerator||exact.denominator!==quoted.denominator)errors.push('拟用报价与当前SKU自动读取的应付价不一致，请重新读取实价');}catch{errors.push('应付价单位或金额尚未核对');}
  }
  if(c.onSale===false||c.onSale==='false')errors.push('候选商品已下架，不能辅助填入');
  if(calculation?.roundingRequired)warnings.push(`采购价按${calculation.purchasePriceDecimals}位小数四舍五入：${calculation.roundedText}`);
  const nativePrecision=snapshot.nativeEditor?.purchasePriceDecimals;if(nativePrecision!=null&&calculation&&Number(calculation.purchasePriceDecimals)>Number(nativePrecision)&&calculation.roundingRequired)assistErrors.push('所选采购价精度超过原生表单允许的小数位数');
  if(c.stock!==''&&c.stock!=null){if(!/^\d+$/.test(str(c.stock)))errors.push('库存必须是明确的非负整数或未知');else if(BigInt(str(c.stock))===0n)errors.push('候选SKU库存为0，不能辅助填入');}
  else warnings.push('库存未知，请在拼多多原页面确认可购买');
  if(isNew){
    if(snapshot.routeMode!=='new'||snapshot.relationId||snapshot.nativeEditor?.writeMode!=='new_draft'||snapshot.nativeEditor?.identityLevel!=='new_relation_form')assistErrors.push('新增草稿与已有关系的身份或写入模式不一致');
    if(draft.newRelationConfirmed!==true)errors.push('请明确确认：本次向当前表单新增网采关系草稿，提交由你完成');
    if(snapshot.backendUpcSource!=='native_product'||!snapshot.backendUpc)assistErrors.push('新增表单未确认已关联后台商品UPC；查询条件不能作为关联证据');
    if(!completion&&snapshot.nativeEditor?.newChannelSupported!==true)assistErrors.push('新增表单尚未选择其他采购平台或确认拼多多来源');
    if(!snapshot.rowRef||!snapshot.nativeEditor?.bindingId||!snapshot.nativeEditor?.protectionFingerprint)assistErrors.push('新增草稿表单绑定或保持字段证据缺失');
    warnings.push(completion?'将补齐当前单个新增表单及六字段；默认供货、起订量和箱规保持原值，最后由你原生提交':'将填写新增关系草稿，不生成关系ID、不提交；供应商为空时请在原生表单手动补全');
  }else{if(draft.newRelationConfirmed===true)assistErrors.push('当前是已有关系，不能按新增关系批准');if(completion||draft.autoCompleteNewForm===true)assistErrors.push('已有关系禁止执行新增表单补齐');if(snapshot.channel!=='pdd')assistErrors.push('未确认拼多多商品来源');}
  if(completion){
    const p=draft.completionPlan,b=p?.binding||{},rules=p?.rules||{};
    if(!isNew||snapshot.relationId)assistErrors.push('补齐计划仅适用于当前无关系ID的单个新增表单');
    if(!p||p.version!==1||p.mode!=='new_draft_completion'||typeof p.planFingerprint!=='string'||!p.planFingerprint)assistErrors.push('缺少有效的新增表单补齐计划，请重新读取并预览');
    if(draft.completionCanApply!==true)assistErrors.push(...(Array.isArray(draft.completionReasons)&&draft.completionReasons.length?draft.completionReasons.map(str):['新增表单补齐计划尚未就绪，请重新读取并预览']));
    if(!b.routeKey||!b.beforeFingerprint||b.tenantId!==snapshot.tenantId||b.backendUpc!==snapshot.backendUpc||b.rowRef!==snapshot.rowRef||b.bindingId!==snapshot.nativeEditor?.bindingId||b.routeKey!==snapshot.nativeEditor?.routeKey||b.beforeFingerprint!==snapshot.fingerprint)assistErrors.push('补齐计划不属于当前租户、后台商品或表单快照');
    if(str(p?.ratioQnh)!==(preserveQuantity?'':str(draft.ratioQnh)))assistErrors.push('补齐计划的起订倍数与本次牵牛花端比例不同，请重新预览');
    if(rules.channelOther!==true||rules.supplier!=='first_available'||rules.orderMultiple!==(preserveQuantity?'preserve':'ratioQnh')||rules.scope!=='all_selectable_stores'||rules.defaultSupply!=='preserve'||Object.keys(rules).some(key=>!['channelOther','supplier','orderMultiple','scope','defaultSupply'].includes(key)))assistErrors.push('补齐计划包含未批准的原生表单操作');
    if(!['read','at_execution'].includes(p?.supplierEvidence?.status)||!['read','at_execution'].includes(p?.scopeEvidence?.status))assistErrors.push('供应商或门店选择的读取范围不明确');
    if(p?.supplierEvidence?.status==='read'&&!str(p.supplierEvidence.label))assistErrors.push('已读取的首个供应商缺少可核对名称');
    if(p?.scopeEvidence?.status==='read'&&(!/^[1-9]\d*$/.test(str(p.scopeEvidence.count))||(typeof p.scopeEvidence.count==='number'&&!Number.isSafeInteger(p.scopeEvidence.count))))assistErrors.push('未读取到可供全选的门店数量');
    if(p?.supplierEvidence?.status==='at_execution')warnings.push('供应商按执行时原生列表的第一个可选项选择，预览未枚举候选');
    if(p?.scopeEvidence?.status==='at_execution')warnings.push('门店按执行时原生选择器全选全部可选门店，预览未读取数量');
  }
  if(!snapshot.tenantId)assistErrors.push('租户身份未确认');
  if(!completion&&snapshot.nativeEditor?.canFill!==true)assistErrors.push('原生六字段表单尚未完成身份及保持字段核对');
  if(!isNew&&!['relation_id','clicked_row_form','reference_form'].includes(snapshot.nativeEditor?.identityLevel))assistErrors.push('没有明确关系ID或本次原生表单绑定证据');
  if(snapshot.nativeEditor?.identityLevel==='relation_id'&&!snapshot.relationId)assistErrors.push('原生关系ID缺失');
  if(snapshot.nativeEditor?.identityLevel==='clicked_row_form'&&(!snapshot.rowRef||!snapshot.nativeEditor.bindingId||!snapshot.nativeEditor.protectionFingerprint))assistErrors.push('本次点击行与保持字段绑定证据缺失');
  if(snapshot.nativeEditor?.identityLevel==='reference_form'&&(snapshot.routeMode!=='edit'||snapshot.backendUpcSource!=='native_product'||!snapshot.backendUpc||(!snapshot.supplier&&snapshot.nativeEditor.newChannelSupported!==true)||!snapshot.rowRef||!snapshot.nativeEditor.bindingId||!snapshot.nativeEditor.protectionFingerprint||!['https://qnh.meituan.com/home.html#/purchase/replenishment/refer','https://qnh.meituan.com/#/purchase/replenishment/refer'].includes(snapshot.nativeEditor.routeKey)))assistErrors.push('补货参考编辑页的商品、采购平台或表单绑定证据缺失');
  if(!completion&&(!snapshot.nativeFields||MAINTENANCE_FIELDS.some(k=>!Object.hasOwn(snapshot.nativeFields,k))))assistErrors.push('缺少原生六字段完整快照');
  if(snapshot.nativeEditor?.identityLevel==='clicked_row_form')warnings.push('关系ID不可读，仅绑定本次明确打开的原生表单；保存后可能需要人工核对');
  if(snapshot.nativeEditor?.identityLevel==='reference_form')warnings.push('仅绑定补货参考当前编辑抽屉；保留供应商、起订规则和供货范围，保存后请人工核对');
  if(!snapshot.scopeComplete)warnings.push(completion?'本次将按计划全选门店供货范围，默认供货设置保持原值；请核对影响门店':isNew?'请在原生提交前核对新增关系供货范围；插件只保持当前表单范围不变':'未声称完整读取全部门店范围；仅保持原生表单范围不变');
  let reviewFingerprint='';try{reviewFingerprint=maintenanceFingerprint(snapshot,draft);}catch(e){errors.push(e.message);}
  if(!draft.approvedFingerprint||draft.approvedFingerprint!==reviewFingerprint)assistErrors.push('请在最新六字段预览上重新批准');
  return {writeMode:completion?'new_draft_completion':isNew?'new_draft':'existing_relation',ok:errors.length===0,canAssist:errors.length===0&&assistErrors.length===0,errors,warnings,assistErrors,reviewFingerprint,diff,fields,calculation,parsed};
}
