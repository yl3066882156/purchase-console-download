import {couponPrice} from './catalog-price.js';
import {normalizeCheckoutCandidate} from './core.js';
import {connectFormForSku,createAutoFillFlow,prepareAutomaticDraft} from './auto-fill.js';
import {createPddTabWorkspace} from './pdd-tab-workspace.js';
export function mountTable(root,getToken,{onSuccess=()=>{}}){
 const $=s=>root.querySelector(s),body=$('tbody'),status=$('.status');let catalog={products:[],skus:[]},page=1,visible=false,busy=false,lastReceipt=null,cacheEpoch=0,loaded=false,workspace=null,workspaceEpoch=0,syncRunning=false;
 const failedThumbnails=new Set();
 const note=t=>status.textContent=t;
 const setProgress=(t)=>$('.sync-status').textContent=t;
 async function request(command,payload={},token=getToken()){if(!token)throw Error('请重新打开补货参考编辑抽屉');const r=await chrome.runtime.sendMessage({type:'QRTH_REQUEST',command,payload,token});if(!r?.ok)throw Object.assign(Error(r?.error?.message||'后台没有响应'),r?.error);if(token!==getToken())throw Error('当前抽屉已切换，旧操作已停止');return r.data;}
 const price=(value,unit)=>{if(value==null||value===''||!/^\d+(?:\.\d+)?$/.test(String(value)))return '—';if(unit==='fen')return '¥'+(Number(value)/100).toFixed(2);if(unit==='yuan')return '¥'+value;return '—';};
 function copyControl(parent,value,label,cls=''){
  if(value==null||value===''||value==='—')return;
  const button=document.createElement('button');button.type='button';button.className='copy '+cls;
  button.textContent=String(value);button.title='点击复制'+label+'：'+value;button.setAttribute('aria-label','复制'+label+'：'+value);
  button.onclick=async()=>{
   try{
    try{await navigator.clipboard.writeText(String(value));}
    catch{
     const area=document.createElement('textarea');area.value=String(value);area.style.cssText='position:fixed;left:-9999px;top:0';root.append(area);area.select();
     try{if(!document.execCommand('copy'))throw Error('复制未获授权');}finally{area.remove();button.focus();}
    }
    note('已复制'+label);
   }catch{note('无法访问剪贴板，请手动选中文字复制。');}
  };
  parent.replaceChildren(button);
 }
 function render(){
  const filter=$('input').value.trim().toLowerCase(),products=new Map((catalog.products||[]).map(p=>[p.goodsId,p]));
  const byGoods=new Map();for(const s of catalog.skus||[]){if(!byGoods.has(s.goodsId))byGoods.set(s.goodsId,[]);byGoods.get(s.goodsId).push(s);}
  const rows=[...products.values()].flatMap(p=>byGoods.get(p.goodsId)?.map(s=>({...p,...s,thumbnailUrl:s.thumbnailUrl||p.thumbnailUrl}))||[p]);
  const filtered=rows.filter(s=>[s.goodsId,s.skuId,s.name,s.spec].some(v=>String(v||'').toLowerCase().includes(filter))),pages=Math.max(1,Math.ceil(filtered.length/30));page=Math.max(1,Math.min(page,pages));body.replaceChildren();
  for(const s of filtered.slice((page-1)*30,page*30)){
   const tr=document.createElement('tr');const cell=(text,label)=>{const td=document.createElement('td');td.textContent=text==null||text===''?'—':String(text);tr.append(td);if(label)copyControl(td,text,label);return td;};
   const photo=cell('');photo.className='thumbnail-cell';
   if(s.thumbnailUrl&&!failedThumbnails.has(s.thumbnailUrl)){
    const img=document.createElement('img');
    img.alt='';img.width=48;img.height=48;img.loading='lazy';img.decoding='async';img.referrerPolicy='no-referrer';
    img.addEventListener('error',()=>{failedThumbnails.add(s.thumbnailUrl);photo.textContent='—';},{once:true});
    img.src=s.thumbnailUrl;photo.replaceChildren(img);
   }
   cell(s.goodsId,'商品ID');cell(s.skuId,'规格ID');
   const spec=cell('');spec.className='spec-cell';
   const title=document.createElement('strong'),variant=document.createElement('div');
   title.textContent=s.name||'商品 '+s.goodsId;variant.className='variant';variant.textContent=s.spec||'尚未读取具体规格';
   copyControl(title,s.name,'商品名称');copyControl(variant,s.spec,'规格值');spec.replaceChildren(title,variant);
   const link=cell('');
   let c;try{c=normalizeCheckoutCandidate(s);}catch{}
   if(c?.checkoutUrl&&s.skuId)copyControl(link,c.checkoutUrl,'抢购链接','link');
   cell(s.stock,'库存');const coupon=couponPrice(s);const group=s.groupPrice||(['groupPrice','group_price','skuPrice'].includes(s.priceField)?s.price:'');cell(coupon?'¥'+coupon.value+' 券后':price(group,s.priceUnit),'单价');cell(price(s.normalPrice||(coupon?group:''),s.priceUnit),'原价');const actions=cell('');actions.replaceChildren();
   const button=(label,fn,disabled=false)=>{const b=document.createElement('button');b.textContent=label;b.disabled=disabled||busy;b.onclick=()=>run(fn);actions.append(b);};
   const canFill=!!(s.skuId&&s.spec&&s.specComplete!==false&&c?.checkoutUrl);
   if(canFill)button('代填',async()=>{const r=await flow.start(c);if(r.status==='done'&&!r.result?.receipt?.referenceDefaults?.some(s=>s.status==='needs_review'))onSuccess(r.result?.receipt?.selectionIntent?.quantitySource==='default_one'?'已按默认比例 1＝1 代填。请核对原表单。':'已代填并收起。请核对原表单，采购价手填。');});
   else button('读取规格',()=>browse('specs',{goodsId:s.goodsId}));
   button('详情',()=>browse('product',{goodsId:s.goodsId}));body.append(tr);
  }
  if(!filtered.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=$('thead tr').cells.length;td.textContent=filter?'没有匹配数据':'请扫码登录后点击「立即同步」读取收藏。';tr.append(td);body.append(tr);}
  $('.page').textContent=`第 ${page} / ${pages} 页 · ${filtered.length} 行`; $('[data-act="prev"]').disabled=page===1;$('[data-act="next"]').disabled=page===pages;
 }
 function updateBrowseControls(){
  for(const action of ['login','favorites','sync','stop']){
   $('[data-act="'+action+'"]').disabled=action==='stop'?!syncRunning:busy||syncRunning;
  }
 }
 async function run(fn){
  if(busy)return;
  busy=true;updateBrowseControls();
  try{await fn();}catch(e){note(e.message);}
  finally{busy=false;updateBrowseControls();render();}
 }
 const flow=createAutoFillFlow({
  connect:async job=>{const token=getToken();job.tableToken=token;const r=await connectFormForSku({tabs:[{id:0,kind:'qnh_reference',active:true}],tabId:0,selection:job.selection,request:(type,p)=>request(type,p,token),checkpoint:()=>{job.checkpoint();if(token!==getToken()||!visible)throw Error('抽屉或浮层已关闭，旧选择已取消');}});return r;},
  quote:async(context,job)=>job.selection,
  prepare:async(context,candidate,job)=>{job.checkpoint();const s=context.snapshot;if(s.routeMode!=='edit')throw Error('只允许补货参考编辑');if(!s.nativeEditor?.canFill){const reasons=s.nativeEditor?.reasons||[];if(reasons.includes('REFERENCE_CHANNEL_UNVERIFIED'))throw Error('请在当前编辑页选择“其他采购平台”，并检查渠道商品是否可填写。');if(reasons.includes('INCOMPLETE_NATIVE_FIELDS'))throw Error('当前编辑页的渠道商品或比例输入框未就绪，请核对后再代填。');if(reasons.includes('REFERENCE_PRODUCT_UNVERIFIED'))throw Error('未能核对当前编辑页已关联的牵牛花商品及 UPC，请检查商品卡片。');if(reasons.includes('REFERENCE_SOURCE_UNVERIFIED'))throw Error('当前渠道商品已有内容，但无法核对为拼多多商品，请检查结算链接。');}const d={candidate,url:candidate.checkoutUrl,manualPurchasePrice:true,autoActualPrice:false,pricingPolicy:'manual_purchase',selectExistingCartonUnit:true,autoCompleteNewForm:false,ratioPdd:s.nativeFields?.ratioPdd||'',ratioQnh:s.nativeFields?.ratioQnh||''};
   const prepared=prepareAutomaticDraft(s,d,{actionId:job.actionId,defaultUnknownToOne:true});return {snapshot:s,draft:prepared.draft,...(lastReceipt?.state==='waiting_native_save'&&lastReceipt.beforeSnapshot?.nativeEditor?.bindingId===s.nativeEditor?.bindingId?{replaceReceiptId:lastReceipt.id}:{})};
  },
  fill:async(prepared,job)=>{if(!visible||job.tableToken!==getToken())throw Error('浮层已关闭，未继续代填');const r=await request('FILL_MAINTENANCE',prepared,job.tableToken);if(r.filled!==true||!r.receipt)throw Error('代填结果未确认，请核对原表单');lastReceipt=r.receipt;return r;},
  onState:s=>{const texts={connecting:'正在绑定当前补货参考抽屉…',quoting:'使用收藏规格，不读取结算价…',checking:'正在检查规格、数量和保护字段…',filling:'正在代填，请勿切换抽屉…',done:'已代填，未保存。请核对比例、箱规、供应商和范围，采购价在原表单手填，再由你保存。'};if(s.stage==='blocked')note(s.message);else if(s.stage==='done'){const receipt=s.result?.receipt,fields=receipt?.expected?.fields||{};note((receipt?.expected?.preserveQuantity?'已代填商品、链接和SKU；下单比例保留，请核对。':'已代填商品、链接、SKU和比例 '+fields.ratioPdd+'＝'+fields.ratioQnh+'。')+(receipt?.referenceDefaults||[]).map(step=>step.status==='verified'?step.label+'已补齐。':step.label+'请核对：'+step.message+'。').join('')+(receipt?.cartonSelection?.message||'')+' 采购价请手填，核对后由你保存。');}else if(texts[s.stage])note(texts[s.stage]);}
 });
 function resume(){
  if(loaded)return;loaded=true;
  const epoch=++cacheEpoch;
  void request('GET_PDD_CATALOG').then(r=>{if(epoch===cacheEpoch){catalog=r.catalog;render();}}).catch(e=>{if(epoch===cacheEpoch){loaded=false;setProgress(e.message);}});
 }
 function setLoad(progress){
  syncRunning=progress?.state==='running';
  $('[data-act="stop"]').hidden=!syncRunning;
  updateBrowseControls();
  if(progress)setProgress(progress.message);
 }
 function disconnectWorkspace(){
  const previous=workspace;
  workspace=null;
  workspaceEpoch++;
  if(syncRunning)void request('SYNC_PDD_TAB_WORKSPACE',{stopFavoritesLoad:true}).catch(()=>{});
  previous?.dispose();
  setLoad(null);
 }
 async function browse(action,{goodsId}={}){
  if(action==='stop')return workspace?.stopLoading();
  const token=getToken();
  if(!workspace){
   const epoch=++workspaceEpoch;
   const current=()=>visible&&token===getToken()&&workspaceEpoch===epoch;
   const connected=createPddTabWorkspace({
    request:(command,payload)=>{
     if(!current())throw Error('编辑抽屉或收藏表格已关闭');
     return request(command,payload,token);
    },
    onCollection:next=>{if(current()){cacheEpoch++;catalog=next;render();}},
    onStatus:message=>{if(current())setProgress(message);},
    onLoadState:progress=>{if(current())setLoad(progress);}
   });
   workspace=connected;
  }
  const connected=workspace;
  if(action!=='product'&&(!connected.tabId||action==='login')){
   await connected.start({active:action==='login'||action==='favorites',preferLogin:action==='login',resumeLogin:action==='login',forSync:action==='sync'});
  }
  if(connected!==workspace)return;
  if(action==='favorites')await connected.favorites();
  if(action==='sync'){failedThumbnails.clear();await connected.read();}
  if(action==='product')await connected.product(goodsId);
  if(action==='specs')await connected.specs(goodsId);
 }
 const acts={login:()=>browse('login'),favorites:()=>browse('favorites'),sync:()=>browse('sync'),stop:()=>browse('stop'),prev:()=>{page--;},next:()=>{page++;}};
 for(const [key,fn]of Object.entries(acts))$('[data-act="'+key+'"]').onclick=key==='stop'?()=>fn().catch(e=>note(e.message)):()=>run(fn);
 $('input').oninput=()=>{page=1;render();};
 return {setVisible(v){visible=v;if(v){resume();render();}else{flow.cancel();disconnectWorkspace();}},invalidate(){flow.cancel();disconnectWorkspace();lastReceipt=null;cacheEpoch++;loaded=false;catalog={products:[],skus:[]};page=1;note('');setProgress('');}};
}
