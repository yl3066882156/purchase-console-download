/**
 * Passive, self-contained MAIN-world checkout quote reader. Never navigates,
 * submits, creates orders, changes checkout options, or reads address data.
 * Static evidence: PddClient.Analysis_Checkout:866–883; GoodsVo, OrderPayVo,
 * priceVo, shippingVo; CheckoutWorkflow:1458–1503 (integer fen, payable includes
 * shipping). Runtime evidence additionally places goodsId directly on store.
 */
export function readPddCheckoutQuotePage(expected = {}) {
  const result = (status, reason, message) => ({status, pageType:'checkout', reason, message, quote:null});
  const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  const id = value => {
    if (typeof value === 'number' && !Number.isSafeInteger(value)) return '';
    const text=String(value??''); return /^[1-9]\d*$/.test(text)?text:'';
  };
  const money = value => {
    if(typeof value==='number'&&(!Number.isSafeInteger(value)||value<0))return '';
    if(typeof value!=='string'&&typeof value!=='number')return '';
    const text=String(value);return /^\d{1,32}$/.test(text)?BigInt(text).toString():'';
  };
  const query = selector => {try{return [...(globalThis.document?.querySelectorAll?.(selector)||[])];}catch{return [];}};
  const visible = node => {
    if(!node||node.isConnected===false)return false;
    for(let item=node;item;item=item.parentElement){
      if(item.hidden||item.getAttribute?.('aria-hidden')==='true')return false;
      const style=globalThis.getComputedStyle?.(item);
      if(style?.display==='none'||style?.visibility==='hidden'||style?.visibility==='collapse')return false;
    }
    return typeof node.getClientRects!=='function'||node.getClientRects().length>0;
  };
  let current;
  try{current=new URL(globalThis.location?.href);}catch{return result('unsupported','invalid_url','结算页地址不可识别');}
  if(current.origin!=='https://mobile.yangkeduo.com'||current.username||current.password||current.port)return result('unsupported','unsupported_origin','仅支持拼多多官方单品结算页');
  if(current.pathname==='/login.html')return result('needs_user','login_required','请在官方页面完成登录后重新读取当前应付价');
  if(/(?:captcha|verify|verification)/i.test(current.pathname))return result('needs_user','verification_required','官方页面需要人工完成验证');
  if(current.pathname!=='/order_checkout.html')return result('unsupported','unsupported_path','当前页面不是单品结算报价页面');
  if(typeof expected.goodsId!=='string'||typeof expected.skuId!=='string'||!id(expected.goodsId)||!id(expected.skuId)||expected.goodsNumber!=='1')return result('unsupported','invalid_expected_identity','必须明确指定一个商品、一个SKU和数量1');
  const requested={};
  for(const key of ['goods_id','sku_id','goods_number']){
    const values=current.searchParams.getAll(key);
    if(!values.length||new Set(values).size!==1||!id(values[0]))return result('unsupported','ambiguous_url_identity','结算链接缺少身份或存在冲突参数');
    requested[key]=values[0];
  }
  if(requested.goods_id!==expected.goodsId||requested.sku_id!==expected.skuId)return result('needs_user','url_identity_mismatch','结算页商品或SKU与本次候选不一致，未读取报价');
  if(requested.goods_number!=='1')return result('needs_user','quantity_not_one','只支持采购1件的单SKU应付报价，不能把多件总价当单位价');
  // Attribute-selected UI only: do not scan body/address text or form values.
  if(query('input[autocomplete="one-time-code"], input[type="password"], iframe[title*="验证"], [role="dialog"][aria-label*="验证"], [role="dialog"][aria-label*="登录"]').some(visible))return result('needs_user','verification_required','官方登录或验证尚待人工处理');
  if(query('iframe[title*="支付"], [role="dialog"][aria-label*="支付"], [role="dialog"][aria-label*="付款"]').some(visible))return result('needs_user','payment_ui_present','页面已进入支付交互，请人工检查；本功能不会操作付款');
  let raw;
  try{raw=globalThis.window?.rawData;if(typeof raw==='string'){if(raw.length>2_000_000)return result('not_ready','raw_data_too_large','结算状态超出本次安全读取范围');raw=JSON.parse(raw);}}catch{return result('not_ready','raw_data_unreadable','结算页面状态尚未加载或无法解析');}
  const store=raw?.store;
  if(!object(store))return result('not_ready','store_not_loaded','结算页面状态尚未加载');
  // BatchCheckoutResult reads cartInfo.available[*].goodsInfo. Never use that
  // aggregate order total as the quote for a single raw goodsInfo object.
  if(store.cartInfo!=null||Array.isArray(store.goodsInfo))return result('needs_user','multiple_goods_scope','当前包含购物车或多商品结算，不能绑定为单SKU单位价');
  const goods=store.goodsInfo,order=store.orderInfo,prices=store.priceInfo,shipping=store.shippingInfo;
  if(!object(goods)||!object(order)||!object(prices))return result('not_ready','single_checkout_not_loaded','单品结算的商品、应付价或金额组成尚未加载');
  const goodsIdentities=[store.goodsId,goods.goodsId].filter(value=>value!=null);
  if(!goodsIdentities.length||goodsIdentities.some(value=>!id(value)))return result('not_ready','goods_identity_unloaded','商品身份尚未完整加载或数值精度不可靠');
  if(goodsIdentities.some(value=>id(value)!==expected.goodsId)||!id(goods.skuId)||id(goods.skuId)!==expected.skuId)return result('needs_user','raw_identity_mismatch','页面结算状态与预期商品或SKU不一致');
  if(store.skuId!=null&&(!id(store.skuId)||id(store.skuId)!==expected.skuId))return result('needs_user','store_sku_mismatch','结算页顶层与商品SKU状态互相矛盾');
  if(id(goods.goodsNumber)!=='1'||(store.goodsNumber!=null&&id(store.goodsNumber)!=='1'))return result('needs_user','quantity_not_one','当前结算状态未确认单SKU采购1件');
  // Haixiaobao handles these exact shop-promotion states before using payPrice.
  // Reading a self-consistent pre-claim price is not proof that a coupon applied.
  const promotion=store.promotionInfo?.shopPromotion;
  const couponPending=object(promotion)&&([3,31,'3','31'].includes(promotion.promotionStatus)||(Array.isArray(promotion.displayItems)&&promotion.displayItems.some(item=>object(item)&&[3,'3'].includes(item.display_type))));
  if(!object(shipping)||!Object.hasOwn(shipping,'cost'))return result('not_ready','shipping_unknown','尚未明确读取本件运费，不能默认免运费');
  if((Object.hasOwn(order,'payPriceUnit')&&order.payPriceUnit!=='fen')||(Object.hasOwn(shipping,'costUnit')&&shipping.costUnit!=='fen'))return result('not_ready','money_unit_conflict','页面声明的金额单位与已验证整数分字段约定不一致，未读取报价');
  let payable=money(order.payPrice);const rawPayable=payable,freight=money(shipping.cost),listed=money(prices.orderPrice),mallPromotion=money(prices.mallPromotionPrice),platformPromotion=money(prices.platformPromotionPrice);
  if([payable,freight,listed,mallPromotion,platformPromotion].some(value=>value===''))return result('not_ready','money_unit_or_components_unknown','已知结算字段必须是完整整数分；金额或单位未确认时不猜测');
  if(BigInt(payable)<=0n)return result('needs_user','nonpositive_payable','应付金额为0或尚未完成报价，请人工核对');
  if(BigInt(freight)>BigInt(payable))return result('needs_user','shipping_exceeds_payable','运费超过当前应付总额，金额口径存在冲突');
  const net=BigInt(listed)-BigInt(mallPromotion)-BigInt(platformPromotion);
  // Reconcile the explicit components without assuming whether orderPrice
  // already includes freight. Only payPrice supplies the returned payable;
  // neither arithmetic alternative invents a replacement price.
  const reconciliation=net>=0n&&net+BigInt(freight)===BigInt(payable)?'priceInfo_net_plus_shipping':net>=0n&&net===BigInt(payable)?'priceInfo_net_includes_shipping':'';
  if(!reconciliation)return result('not_ready','unreconciled_amounts','当前应付金额与价格、优惠及运费组成尚不一致，请等待原生页面更新');
  // Read the exact pending-action text established by PddClient.Action_Submit;
  // never invoke it. No body text or addressInfo data is read or returned.
  const pending=[];
  try{
    const found=globalThis.document?.evaluate?.("//*[starts-with(translate(normalize-space(.),' ',''),'立即支付')]",globalThis.document,null,globalThis.XPathResult?.ORDERED_NODE_SNAPSHOT_TYPE??7,null);
    for(let i=0;i<(found?.snapshotLength||0)&&i<40;i++){const node=found.snapshotItem(i),label=String(node.textContent||'').trim();if(label.length>100)continue;const withoutAmounts=label.replace(/[¥￥][\s\d.]+/g,'').replace(/[\s\u200b-\u200d\ufeff]/g,'');if(withoutAmounts==='立即支付'&&visible(node)&&!node.disabled&&node.getAttribute?.('aria-disabled')!=='true')pending.push(node);}
  }catch{return result('not_ready','pending_control_unreadable','未确认结算页处于待提交报价状态');}
  const controls=pending.filter(node=>!pending.some(other=>other!==node&&node.contains?.(other)));
  if(controls.length!==1)return result(controls.length?'needs_user':'not_ready',controls.length?'ambiguous_pending_controls':'pending_control_not_loaded','未唯一确认原生立即支付待提交控件；本功能没有执行提交或付款');
  // window.rawData may still contain the server-rendered price after the client
  // applies a coupon. Cross-check only the unique pending control's own amount.
  const paymentText=node=>{
    if(node.nodeType===3)return node.textContent||'';
    if(!visible(node)||/^(?:S|DEL|STRIKE)$/i.test(node.tagName||'')||/line-through/.test(globalThis.getComputedStyle?.(node)?.textDecorationLine||''))return '';
    const children=node.childNodes?Array.from(node.childNodes):[];
    return children.length?children.map(paymentText).join(''):node.textContent||'';
  };
  const amountText=paymentText(controls[0]).replace(/[\s\u200b-\u200d\ufeff]/g,''),amounts=[...amountText.matchAll(/[¥￥](\d+(?:\.\d{1,2})?)(?![\d.])/g)].map(match=>{const [whole,fraction='']=match[1].split('.');return (BigInt(whole)*100n+BigInt(fraction.padEnd(2,'0'))).toString();});
  const renderedAmounts=[...new Set(amounts)];
  if(renderedAmounts.length>1)return result('not_ready','ambiguous_visible_payable','立即支付区域有多个无法区分的有效金额，未采用页面旧价格，请打开官网核对后重读');
  let renderedCoupon=false;
  const coupon=expected.favoritesCoupon;
  try{
    const age=Date.now()-Date.parse(coupon?.capturedAt),url=new URL(coupon?.sourceUrl);
    renderedCoupon=renderedAmounts.length===1&&coupon.goodsId===expected.goodsId&&coupon.skuId===expected.skuId&&coupon.goodsNumber==='1'&&age>=-5000&&age<=60000&&url.origin==='https://mobile.yangkeduo.com'&&url.pathname==='/likes.html'&&!url.username&&!url.password&&money(coupon.amountFen)!==''&&BigInt(coupon.amountFen)>0n&&BigInt(coupon.amountFen)+BigInt(freight)===BigInt(renderedAmounts[0]);
  }catch{/* Missing or mismatched favorites evidence cannot authorize an alternative amount. */}
  if(couponPending&&!renderedCoupon)return result('needs_user','shop_coupon_pending','结算页有尚待领取或处理的店铺优惠，请打开官网处理优惠后重新读取实价；当前价格未用于采购价计算');
  if(renderedAmounts.length===1&&renderedAmounts[0]!==payable){
    if(!renderedCoupon)return result('not_ready','visible_payable_mismatch','结算页显示的应付价与页面报价数据不一致，可能优惠刚更新；请等待或刷新官网后重新读取，当前价格未用于采购价计算');
    payable=renderedAmounts[0];
  }
  const capturedAt=new Date().toISOString(),sourceUrl=current.href,goodsPayable=(BigInt(payable)-BigInt(freight)).toString();
  const source={kind:'checkout_payable_unit_quote',field:payable===rawPayable?'rawData.store.orderInfo.payPrice':'visible_pending_checkout_payable',goodsId:expected.goodsId,skuId:expected.skuId,goodsNumber:'1',costBasis:'single_sku_payable_including_shipping',payableTotalFen:payable,shippingCostFen:freight,goodsPayableFen:goodsPayable,singleSku:true,quantityVerified:true,unsubmitted:true,verifiedUnsubmitted:true,...(renderedAmounts.length===1?{visiblePayableFen:renderedAmounts[0]}:{}),...(payable!==rawPayable?{favoritesCoupon:{...coupon},rawPayableFen:rawPayable}:{}),components:{orderPriceFen:listed,mallPromotionFen:mallPromotion,platformPromotionFen:platformPromotion,payableTotalFen:payable,shippingCostFen:freight,goodsPayableFen:goodsPayable,reconciliation:payable===rawPayable?reconciliation:'visible_payable_matches_favorites_coupon_plus_shipping'},unitEvidence:payable===rawPayable?'known_checkout_schema_integer_fen':'visible_checkout_currency_yuan',pendingControlEvidence:'visible_unsubmitted_checkout_立即支付',sourceUrl,capturedAt};
  return {status:'read',pageType:'checkout',reason:'bound_single_sku_payable',message:'已读取当前单SKU采购1件的应付报价（含明确运费）；未执行提交或支付',quote:{goodsId:expected.goodsId,skuId:expected.skuId,goodsNumber:'1',actualPayPrice:payable,actualPayPriceUnit:'fen',actualPayPriceSource:source},sourceUrl,capturedAt};
}
