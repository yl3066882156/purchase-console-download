/**
 * Official routes observed in static evidence (not a promise about current UI):
 * PddClient.cs:985; ExtractProductControl.cs:88,478. Authentication stays in the
 * official browser page; this module never reads credentials or cookies.
 */
export const PDD_OFFICIAL_ROUTES = Object.freeze({
  home: 'https://mobile.yangkeduo.com/',
  login: 'https://mobile.yangkeduo.com/login.html',
  favorites: 'https://mobile.yangkeduo.com/likes.html',
});

/** Classification is not collection permission: fixture readers also check the HTML marker. */
export function classifyPddUrl(input) {
  try {
    const url = new URL(input);
    if (url.origin === 'https://mobile.yangkeduo.com') {
      if (/^\/goods\d*\.html$/.test(url.pathname)) return 'product';
      if (url.pathname === '/likes.html') return 'favorites';
      if (url.pathname === '/login.html') return 'login';
      return 'other';
    }
    if (url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname) && url.port === '8765') {
      if (url.pathname === '/demo/pdd-product.html') return 'product';
      if (url.pathname === '/demo/pdd-favorites.html') return 'favorites';
    }
  } catch { /* Partial or unrecognized URLs are not PDD pages. */ }
  return 'other';
}

/**
 * Self-contained MAIN-world read for chrome.scripting.executeScript.
 * Passive schema: rawData.baseStore.goodsSet[*].mergePayList was observed in
 * ExtractProductControl.LoadFav (current decompilation, lines 489–517).
 * skuPrice there is divided by 100; preserve its exact value plus unit metadata
 * instead of silently converting. An explicit page unit wins.
 * DOM fallback reads visible detail links, never inferred SKU/price.
 */
export function readPddFavoritesPage({fullFavorites=false}={}) {
  const productLimit=fullFavorites?5000:200,skuLimit=fullFavorites?50000:1000,anchorLimit=fullFavorites?30000:3000;
  const cap = (value, limit = 500) => String(value ?? '').slice(0, limit);
  const safeId = (value, zero = false) => {
    if (typeof value === 'number' && !Number.isSafeInteger(value)) return '';
    const text = String(value ?? '');
    return /^\d+$/.test(text) && (zero || !/^0+$/.test(text)) ? text : '';
  };
  const decimal = value => {
    if (typeof value === 'string' && /^\d+(?:\.\d+)?$/.test(value)) return value;
    if (typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= Number.MAX_SAFE_INTEGER && /^\d+(?:\.\d+)?$/.test(String(value))) return String(value);
    return '';
  };
  const integer = value => (typeof value === 'number' && Number.isSafeInteger(value) && value >= 0) || (typeof value === 'string' && /^\d+$/.test(value)) ? String(value) : '';
  const detailUrl = id => `https://mobile.yangkeduo.com/goods.html?goods_id=${id}`;
  const legacyImageHosts = new Set(['pinduoduoimg.yangkeduo.com', 't00img.yangkeduo.com', 't16img.yangkeduo.com']);
  const thumbnail = value => {
    if (typeof value !== 'string' || value.length > 2048) return '';
    try {
      const url = new URL(value.startsWith('//') ? 'https:' + value : value);
      const isImageHost = url.hostname === 'pddpic.com' || url.hostname.endsWith('.pddpic.com') || legacyImageHosts.has(url.hostname);
      if (!isImageHost || !['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.port) return '';
      url.protocol = 'https:';
      return url.href;
    } catch { return ''; }
  };
  let current;
  try { current = new URL(location.href); } catch { return { status: 'unsupported', message: '页面地址不可识别' }; }
  const official = current.origin === 'https://mobile.yangkeduo.com';
  const fixture = current.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(current.hostname) && current.port === '8765' && current.pathname === '/demo/pdd-favorites.html';
  const isDemo = fixture && globalThis.document?.documentElement?.getAttribute('data-pdd-demo') === 'true';
  if (!official && !isDemo) return { status: 'unsupported', message: '请选择官方拼多多收藏页；演示仅支持明确标记的指定本地页面', products: [], skus: [] };
  if (official && current.pathname === '/login.html') return { status: 'login_required', pageType: 'login', message: '请在此官方页面完成浏览器登录，再返回收藏页；插件不读取登录凭据', products: [], skus: [] };
  if (!isDemo && current.pathname !== '/likes.html') return { status: 'unsupported', message: '请打开拼多多商品收藏页后再读取', products: [], skus: [] };
  let raw = window.rawData;
  if (typeof raw === 'string') { try { raw = JSON.parse(raw); } catch { raw = null; } }
  const warnings = [];
  const capturedAt = new Date().toISOString();
  const couponQuantityConflicts = new Set();
  const productsById = new Map();
  const conflictedGoods = new Set();
  const linkedGoods = new Map();
  let truncated = false;
  let skipped = 0;
  let loadedSkuCount = 0;
  const addProduct = (id, name, groupId, source) => {
    const existing = productsById.get(id);
    if (existing) {
      if (!existing.name && name) existing.name = cap(name);
      if (!existing.sources.includes(source)) existing.sources.push(source);
      if (source === 'rawData.baseStore.goodsSet' && existing.groupId !== '' && groupId !== '' && existing.groupId !== groupId) conflictedGoods.add(id);
      if (existing.groupId === '' && groupId !== '') existing.groupId = groupId;
      return existing;
    }
    if (productsById.size >= productLimit) { truncated = true; return null; }
    const product = { goodsId: id, name: cap(name), groupId, detailUrl: detailUrl(id), skus: [], needsDetail: true, skuCoverage: 'unknown', sources: [source] };
    productsById.set(id, product);
    return product;
  };
  const goodsSet = raw?.baseStore?.goodsSet;
  const entries = Array.isArray(goodsSet) ? goodsSet : goodsSet && typeof goodsSet === 'object' ? Object.values(goodsSet) : [];
  if (entries.length > productLimit) truncated = true;
  for (const goods of entries.slice(0, productLimit)) {
    if (!goods || typeof goods !== 'object') { skipped++; continue; }
    const id = safeId(goods.goodsId);
    if (!id) { skipped++; continue; }
    const groupId = safeId(goods.groupId, true);
    if (goods.groupId != null && !groupId) warnings.push('部分收藏拼团ID格式或精度不可靠，未生成推测值');
    const product = addProduct(id, goods.goodsName, groupId, 'rawData.baseStore.goodsSet');
    const thumbnailUrl = thumbnail(goods.thumbUrl);
    if (product && !product.thumbnailUrl && thumbnailUrl) product.thumbnailUrl = thumbnailUrl;
    if (goods.groupId != null && goods.groupId !== '' && !groupId) continue;
    if (!product || !Array.isArray(goods.mergePayList)) continue;
    for (const sku of goods.mergePayList) {
      if (loadedSkuCount >= skuLimit) { truncated = true; break; }
      loadedSkuCount++;
      if (!sku || typeof sku !== 'object') { skipped++; continue; }
      const skuId = safeId(sku.skuId);
      const declaredGoodsId = sku.goodsId == null ? id : safeId(sku.goodsId);
      if (!skuId || declaredGoodsId !== id) { skipped++; continue; }
      if(sku.goodsNumber != null && safeId(sku.goodsNumber)!=='1')couponQuantityConflicts.add(id+':'+skuId);
      const specs = Array.isArray(sku.spec) ? sku.spec.map(spec => cap(spec?.value, 150)).filter(Boolean) : [];
      const price = decimal(sku.skuPrice);
      // Known schema uses integer fen. A fractional value without an explicit
      // unit violates that evidence and remains unknown for manual verification.
      const explicitUnit = ['yuan', 'fen'].includes(sku.priceUnit) ? sku.priceUnit : '';
      const schemaFen = sku.priceUnit == null && price !== '' && /^\d+$/.test(price);
      const priceUnit = explicitUnit || (schemaFen ? 'fen' : 'unknown');
      if (sku.skuPrice != null && price === '') warnings.push('部分收藏SKU价格格式或数值精度不可靠，未用于成本预览');
      if (priceUnit === 'unknown') warnings.push('部分收藏价格单位不符合已知字段约定，必须人工确认元或分');
      const sale = sku.skuOnSale;
      const skuThumbnail = thumbnail(sku.skuThumbUrl);
      product.skus.push({
        goodsId: id, skuId, groupId: groupId || '0', groupIdSource: groupId ? 'official_favorites' : 'haixiaobao_default', goodsNumber: '1', name: product.name, spec: specs.join(' / '),
        price, priceUnit, priceField: 'skuPrice', priceBasis: 'before_coupon',
        priceUnitSource: explicitUnit ? 'explicit_page_field' : schemaFen ? 'known_favorites_schema' : 'unverified_favorites_field',
        stock: integer(sku.skuQuantity), onSale: sale === true || sale === 1 ? true : sale === false || sale === 0 ? false : null,
        detailUrl: product.detailUrl,
        checkoutUrl: `https://mobile.yangkeduo.com/order_checkout.html?sku_id=${skuId}&group_id=${groupId || '0'}&goods_id=${id}&goods_number=1`,
        source: 'pdd_favorites_rawData',
        ...(skuThumbnail ? {thumbnailUrl: skuThumbnail} : {}),
      });
    }
  }
  // Visible links establish product identity/navigation only, never SKU/price.
  const anchors = globalThis.document?.querySelectorAll?.('a[href]') ?? [];
  if (anchors.length > anchorLimit) truncated = true;
  const recommendationEnds=fullFavorites?[...(globalThis.document?.querySelectorAll?.('h1,h2,h3,h4,div,span')||[])].filter(n=>!n.children?.length&&!n.hidden&&!n.closest?.('[hidden],[aria-hidden="true"]')&&(!n.getClientRects||n.getClientRects().length>0)&&/^(?:精选推荐|猜你喜欢|为你推荐|相关推荐)$/.test(String(n.textContent||'').trim())):[];
  for (let i = 0; i < Math.min(anchors.length, anchorLimit); i++) {
    const anchor = anchors[i];
    if (!anchor || anchor.hidden || anchor.closest?.('[hidden], [aria-hidden="true"]')) continue;
    if(fullFavorites&&(anchor.closest?.('[data-recommendation], [data-section="recommend"]')||recommendationEnds.some(end=>!!(end.compareDocumentPosition?.(anchor)&4))))continue;
    if (typeof anchor.getClientRects === 'function' && anchor.getClientRects().length === 0) continue;
    if (typeof globalThis.getComputedStyle === 'function') {
      const style = globalThis.getComputedStyle(anchor);
      if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse') continue;
    }
    let link;
    try { link = new URL(anchor.getAttribute('href'), current.href); } catch { continue; }
    const officialDetail = link.origin === 'https://mobile.yangkeduo.com' && /^\/goods\d*\.html$/.test(link.pathname);
    const demoDetail = isDemo && link.origin === current.origin && link.pathname === '/demo/pdd-product.html';
    if (!officialDetail && !demoDetail) continue;
    const ids = link.searchParams.getAll('goods_id');
    if (ids.length === 0 || new Set(ids).size !== 1) continue;
    const id = safeId(ids[0]);
    if (!id) continue;
    const name = anchor.getAttribute('title') || anchor.getAttribute('aria-label') || anchor.querySelector?.('img[alt]')?.getAttribute('alt') || anchor.textContent;
    linkedGoods.set(anchor,id);
    const product = addProduct(id, name, '', 'visible_detail_link');
    if (product && demoDetail) product.demoDetailUrl = cap(link.href, 2048);
    if (product && !product.thumbnailUrl && !demoDetail) {
      const images = [...(anchor.querySelectorAll?.('img') || [])];
      if (images.length === 1) {
        const image = images[0];
        const url = thumbnail(image.currentSrc) || thumbnail(image.getAttribute('src')) || thumbnail(image.getAttribute('data-src'));
        if (url) product.thumbnailUrl = url;
      }
    }
  }
  let conflictCount = 0;
  for (const product of productsById.values()) {
    const unique = new Map();
    const conflicts = new Set();
    for (const sku of product.skus) {
      const previous = unique.get(sku.skuId);
      if (!previous) {
        unique.set(sku.skuId, sku);
        continue;
      }
      const {thumbnailUrl: previousImage, ...previousFields} = previous;
      const {thumbnailUrl, ...fields} = sku;
      if (JSON.stringify(previousFields) !== JSON.stringify(fields)) conflicts.add(sku.skuId);
      else if (!previousImage && thumbnailUrl) previous.thumbnailUrl = thumbnailUrl;
    }
    if (conflictedGoods.has(product.goodsId)) {
      conflictCount += product.skus.length;
      product.skus = [];
    } else {
      product.skus = [...unique.values()].filter(sku => !conflicts.has(sku.skuId));
      conflictCount += conflicts.size;
    }
    product.skuCoverage = product.skus.length ? 'selected_only' : 'unknown';
    product.needsDetail = !product.skus.length || product.skus.some(sku => !sku.spec);
  }
  // A coupon quote is DOM evidence, separate from raw skuPrice. It is never
  // inferred by searching arbitrary rawData price fields or opening checkout.
  const queryAll=(root,selector)=>{try{return [...(root?.querySelectorAll?.(selector)||[])];}catch{return [];}};
  const normalizeText=value=>String(value??'').normalize('NFKC').replace(/\s+/g,' ').trim();
  const titleKey=value=>normalizeText(value).replace(/[\s【】\[\]]/g,'');
  const canonicalSpec=value=>normalizeText(value).replace(/\s+/g,'').replace(/[;；]/g,'/');
  const textCache=new WeakMap(),visibilityCache=new WeakMap(),styleCache=new WeakMap();
  const visible=node=>{
    if(!node||typeof node!=='object')return false;if(visibilityCache.has(node))return visibilityCache.get(node);
    let value=true;
    for(let currentNode=node;currentNode;currentNode=currentNode.parentElement){
      if(currentNode.hidden||currentNode.getAttribute?.('aria-hidden')==='true'||/^(SCRIPT|STYLE|TEMPLATE)$/.test(currentNode.tagName||'')){value=false;break;}
      if(typeof globalThis.getComputedStyle==='function'){
        if(!styleCache.has(currentNode))styleCache.set(currentNode,globalThis.getComputedStyle(currentNode));
        const style=styleCache.get(currentNode);if(style?.display==='none'||style?.visibility==='hidden'||style?.visibility==='collapse'){value=false;break;}
      }
    }
    if(value&&typeof node.getClientRects==='function'&&node.getClientRects().length===0)value=false;
    visibilityCache.set(node,value);return value;
  };
  const rendered=node=>{
    if(!node||!visible(node))return '';if(textCache.has(node))return textCache.get(node);
    const value=normalizeText(node.innerText??node.textContent);textCache.set(node,value);return value;
  };
  const contains=(root,node)=>root===node||!!root?.contains?.(node);
  const deepest=nodes=>{const present=new Set(nodes),parents=new Set();for(const node of present)for(let parent=node.parentElement;parent;parent=parent.parentElement)if(present.has(parent))parents.add(parent);return [...present].filter(node=>!parents.has(node));};
  const recommendation=node=>{
    for(let currentNode=node;currentNode;currentNode=currentNode.parentElement){
      const hint=['aria-label','data-section','data-testid','data-recommendation'].map(key=>currentNode.getAttribute?.(key)||'').join(' ');
      if(/猜你喜欢|为你推荐|相关推荐|推荐商品|推荐好物|精选推荐|recommend/i.test(hint))return true;
    }return false;
  };
  const specSelection=value=>{
    const match=normalizeText(value).match(/^(.*?)\s*[×✕]\s*(\d+)\s*$/);if(!match)return null;
    const body=match[1].replace(/^(?:所选规格|已选规格|规格)\s*[:：]\s*/,'');
    const spec=canonicalSpec(body);return spec&&!/^(?:数量|件数|购买数量)$/.test(spec)?{spec,quantity:match[2]}:null;
  };
  const couponQuote=value=>{
    const text=normalizeText(value),labels=[...text.matchAll(/券后(?:价)?\s*[:：]?/g)];if(labels.length!==1)return null;
    const tail=text.slice(labels[0].index+labels[0][0].length),match=tail.match(/^\s*(?:[¥￥]\s*(\d+(?:\s*\.\s*\d+)?)|(\d+(?:\s*\.\s*\d+)?)\s*元)/);
    if(!match)return null;const amount=(match[1]||match[2]).replace(/\s+/g,'');
    if(amount.length>32||!/^\d+(?:\.\d{1,2})?$/.test(amount)||/^\s*(?:起|\/|／|~|至|[-–—]|[,.，]\s*\d)/.test(tail.slice(match[0].length)))return null;
    return {amount,text};
  };
  const couponTextCache=new WeakMap();
  const couponRendered=node=>{
    if(!visible(node))return '';if(couponTextCache.has(node))return couponTextCache.get(node);
    const style=styleCache.get(node),struck=/^(DEL|S|STRIKE)$/.test(node.tagName||'')||/line-through/.test(style?.textDecorationLine||style?.textDecoration||'');
    if(struck){couponTextCache.set(node,'');return '';}
    const children=node.childNodes;
    const value=children?normalizeText([...children].map(child=>child.nodeType===3?child.textContent:couponRendered(child)).join(' ')):rendered(node);
    couponTextCache.set(node,value);return value;
  };
  const domLimit=fullFavorites?60000:12000;let domNodes=queryAll(globalThis.document,'body, body *'),couponDomTruncated=domNodes.length>domLimit;
  if(couponDomTruncated){domNodes=domNodes.slice(0,domLimit);warnings.push('可见券后价DOM达到读取上限，未覆盖的商品报价保持未知');}
  const titleOwners=new Map();
  for(const product of productsById.values()){const name=titleKey(product.name);if(name){if(!titleOwners.has(name))titleOwners.set(name,[]);titleOwners.get(name).push(product.goodsId);}}
  const titleNodes=new Map(),specNodes=[],quoteNodes=[],sectionMarkers=[];
  for(const node of domNodes){
    const rough=normalizeText(node?.textContent);if(!rough||rough.length>8000)continue;
    const title=titleKey(rough);
    if(titleOwners.has(title)&&titleKey(rendered(node))===title&&!recommendation(node)){if(!titleNodes.has(title))titleNodes.set(title,[]);titleNodes.get(title).push(node);}
    if(rough.length<1200&&/[×✕]\s*\d+\s*$/.test(rough)){const selected=specSelection(rendered(node));if(selected&&!recommendation(node))specNodes.push({node,...selected});}
    if(rough.includes('券后')){const quote=couponQuote(couponRendered(node));if(quote&&!recommendation(node))quoteNodes.push({node,...quote,text:rendered(node)});}
    if(/^(猜你喜欢|为你推荐|相关推荐|推荐商品|推荐好物|精选推荐)$/.test(rough)&&visible(node))sectionMarkers.push(node);
  }
  const knownTitleNodes=[...titleNodes.values()].flat(),selectedSpecs=deepest(specNodes.map(item=>item.node));
  const selectedByNode=new Map(specNodes.map(item=>[item.node,item]));
  const ancestorIndex=records=>{
    const index=new WeakMap();for(const record of records){let depth=0;for(let node=record.node;node&&depth<10&&!/^(BODY|HTML)$/.test(node.tagName||'');node=node.parentElement,depth++){if(!index.has(node))index.set(node,new Set());index.get(node).add(record);}}return index;
  };
  const specIndex=ancestorIndex(selectedSpecs.map(node=>selectedByNode.get(node))),quoteIndex=ancestorIndex(quoteNodes),titleIndex=ancestorIndex(knownTitleNodes.map(node=>({node}))),sectionIndex=ancestorIndex(sectionMarkers.map(node=>({node})));
  const hasOtherTitle=(card,title)=>([...(titleIndex.get(card)||[])]).some(record=>!contains(record.node,title)&&!contains(title,record.node));
  const commonAncestor=(a,b)=>{for(let node=a;node;node=node.parentElement)if(contains(node,b))return node;return null;};
  const imageCache=new WeakMap(),linkCache=new WeakMap();
  const largeImages=root=>{if(imageCache.has(root))return imageCache.get(root);const found=queryAll(root,'img').filter(image=>{if(!visible(image))return false;const r=image.getBoundingClientRect?.();return r&&r.width>=48&&r.height>=48;});imageCache.set(root,found);return found;};
  const linkIds=root=>{if(linkCache.has(root))return linkCache.get(root);const found=queryAll(root,'a[href]').map(anchor=>{try{const u=new URL(anchor.getAttribute('href'),current.href);if(u.origin!=='https://mobile.yangkeduo.com'||!/^\/(?:goods\d*|order_checkout)\.html$/.test(u.pathname))return null;const ids=u.searchParams.getAll('goods_id'),skus=u.searchParams.getAll('sku_id');if(new Set(ids).size!==1||new Set(skus).size>1)return {invalid:true};return {node:anchor,goodsId:safeId(ids[0]),skuId:skus.length?safeId(skus[0]):''};}catch{return null;}}).filter(Boolean);linkCache.set(root,found);return found;};
  let couponCount=0;
  for(const product of productsById.values()){
    const name=titleKey(product.name),titles=deepest(titleNodes.get(name)||[]);
    if(couponDomTruncated||titleOwners.get(name)?.length!==1||titles.length!==1)continue;
    const nearbySpecs=new Set();let titleDepth=0;for(let node=titles[0];node&&titleDepth<10&&!/^(BODY|HTML)$/.test(node.tagName||'');node=node.parentElement,titleDepth++){if(hasOtherTitle(node,titles[0])||sectionIndex.has(node))break;const records=specIndex.get(node);if(records&&records.size<=4)for(const record of records)nearbySpecs.add(record);}
    const specOwners=new Map();for(const sku of product.skus){const key=canonicalSpec(sku.spec);if(key){if(!specOwners.has(key))specOwners.set(key,new Set());specOwners.get(key).add(sku.skuId);}}
    for(const sku of product.skus){
      const key=canonicalSpec(sku.spec);if(!key||specOwners.get(key)?.size!==1||couponQuantityConflicts.has(product.goodsId+':'+sku.skuId))continue;
      const matches=[...nearbySpecs].filter(item=>item.spec===key&&item.quantity==='1');
      const bindings=[];
      for(const selected of matches){
        const identity=commonAncestor(titles[0],selected.node);if(!identity||/^(BODY|HTML)$/.test(identity.tagName||''))continue;
        const nearbyQuotes=new Set();for(const candidate of [identity,identity.parentElement]){if(!candidate||/^(BODY|HTML)$/.test(candidate.tagName||'')||hasOtherTitle(candidate,titles[0])||sectionIndex.has(candidate))continue;const records=quoteIndex.get(candidate);if(records&&records.size<=32)for(const record of records)nearbyQuotes.add(record);}
        for(const quote of nearbyQuotes){
          const card=commonAncestor(identity,quote.node);if(!card||/^(BODY|HTML)$/.test(card.tagName||'')||recommendation(card))continue;
          if(card!==identity){
            if(identity.parentElement!==card||largeImages(identity).length||linkIds(identity).some(link=>link.goodsId===product.goodsId))continue;
            let quoteBranch=quote.node;while(quoteBranch.parentElement&&quoteBranch.parentElement!==card)quoteBranch=quoteBranch.parentElement;
            const imageProof=largeImages(card).some(image=>!contains(quoteBranch,image)),linkProof=linkIds(card).some(link=>link.goodsId===product.goodsId&&contains(link.node,titles[0]));
            if(!imageProof&&!linkProof)continue;
          }
          const fullQuote=couponQuote(couponRendered(card));if(!fullQuote||fullQuote.amount!==quote.amount)continue;
          if(hasOtherTitle(card,titles[0]))continue;
          if(sectionIndex.has(card))continue;
          const cardSpecs=[...(specIndex.get(card)||[])].map(record=>record.node);if(cardSpecs.length!==1||cardSpecs[0]!==selected.node)continue;
          const links=linkIds(card);if(links.some(link=>link.invalid||link.goodsId!==product.goodsId||(link.skuId&&link.skuId!==sku.skuId)))continue;
          const declared=queryAll(card,'[data-goods-id], [data-sku-id]').concat(card);
          if(declared.some(node=>{const g=node.getAttribute?.('data-goods-id'),s=node.getAttribute?.('data-sku-id');return(g&&g!==product.goodsId)||(s&&s!==sku.skuId);}))continue;
          if(largeImages(card).length>1)continue;
          bindings.push({card,quote});
        }
      }
      const minimal=bindings.filter(binding=>!bindings.some(other=>binding.card!==other.card&&contains(binding.card,other.card)));
      const cards=[...new Set(minimal.map(binding=>binding.card))];if(cards.length!==1)continue;
      const candidates=minimal.filter(binding=>binding.card===cards[0]),prices=new Set(candidates.map(binding=>binding.quote.amount));if(prices.size!==1)continue;
      const quotes=deepest(candidates.map(binding=>binding.quote.node)),actual=candidates.find(binding=>binding.quote.node===quotes[0]);if(!actual)continue;
      Object.assign(sku,{afterCouponPrice:actual.quote.amount,afterCouponPriceUnit:'yuan',afterCouponPriceSource:{kind:'visible_favorites_coupon_quote',goodsId:sku.goodsId,skuId:sku.skuId,goodsNumber:'1',text:cap(actual.quote.text,1200),sourceUrl:cap(current.href,2048),capturedAt}});couponCount++;
    }
  }
  if(couponCount)warnings.push('券后价来自当前可见收藏商品卡，绑定该已选SKU及×1；不代表已核实最终支付价，也未执行下单');
  else if(quoteNodes.length)warnings.push('可见券后报价未能唯一绑定当前商品、规格和×1数量，未用于实际价');

  let products = [...productsById.values()];
  // Object keys are not display order. A virtualized page can render only its
  // first few cards while goodsSet already contains many more products.
  let pageOrder=new Map();const orderNodes=new Map();
  for(const node of domNodes){
    const linkedId=linkedGoods.get(node);
    if(linkedId&&visible(node)&&!recommendation(node)&&!pageOrder.has(linkedId)){pageOrder.set(linkedId,pageOrder.size);orderNodes.set(linkedId,node);}
    const owners=titleOwners.get(titleKey(node?.textContent));
    if(owners?.length===1&&titleNodes.get(titleKey(node?.textContent))?.includes(node)&&!pageOrder.has(owners[0])){pageOrder.set(owners[0],pageOrder.size);orderNodes.set(owners[0],node);}
  }
  const positions=[...orderNodes].map(([id,node])=>({id,rect:node.getBoundingClientRect?.()}));
  if(positions.length&&positions.every(p=>p.rect&&Number.isFinite(p.rect.top)&&Number.isFinite(p.rect.left)&&p.rect.width>0&&p.rect.height>0)){
   positions.sort((a,b)=>a.rect.top-b.rect.top||a.rect.left-b.rect.left);
   pageOrder=new Map(positions.map((p,i)=>[p.id,i]));
  }
  const scrollPositions=[window.scrollY,globalThis.document?.scrollingElement?.scrollTop].filter(v=>typeof v==='number'&&Number.isFinite(v));
  for(const node of orderNodes.values())for(let parent=node;parent;parent=parent.parentElement)if(typeof parent.scrollTop==='number'&&Number.isFinite(parent.scrollTop))scrollPositions.push(parent.scrollTop);
  const fromStart=scrollPositions.length>0&&scrollPositions.every(v=>v<=2),coversLoaded=products.length>0&&products.every(product=>pageOrder.has(product.goodsId));
  if(coversLoaded||fromStart)products.sort((a,b)=>(pageOrder.get(a.goodsId)??Infinity)-(pageOrder.get(b.goodsId)??Infinity));
  const favoritesOrder={kind:'rendered_favorites',goodsIds:[...pageOrder.keys()].filter(id=>productsById.has(id)),fromStart,coversLoaded};
  const skus = products.flatMap(product => product.skus);
  const productsNeedingDetail = products.filter(product => product.needsDetail).length;
  if (skipped) warnings.push('部分商品或SKU的ID不可靠，已跳过，请进入官方详情页核对');
  if (conflictCount) warnings.push('相同商品或SKU出现冲突数据，已跳过冲突规格，请进入详情页核对');
  if (truncated) warnings.push('达到本次读取上限，当前结果不是完整收藏清单');
  if (productsNeedingDetail) warnings.push(`${productsNeedingDetail}个收藏商品缺少可核对的SKU或规格，请进入详情页补全`);
  warnings.push('只读取当前已加载收藏数据和可见商品链接，不代表完整收藏；收藏中已选SKU不等于商品全部SKU');
  warnings.push('库存与在售标记只反映本次页面数据，不保证实际可购买；生成链接不执行下单');
  if (isDemo) warnings.push('这是纯虚构演示收藏，不代表真实账号、商品或登录状态');
  return {
    status: products.length ? 'read' : 'parse_error', pageType: 'favorites', isDemo,
    message: products.length ? '' : '没有读到可识别的收藏商品；请确认已在官方页面登录，等待加载或手动滚动后再读。不能据此认定收藏为空或商品失效。',
    products, skus, favoritesOrder, sourceUrl: cap(current.href, 2048), capturedAt,
    coverage: { complete: false, scope: 'currently_loaded_favorites', productCount: products.length, selectedSkuCount: skus.length, productsNeedingDetail, truncated },
    warnings: [...new Set(warnings)],
    nextSteps: [fullFavorites?'正在自动分批加载收藏，进度和停止操作请在侧栏查看':'需要更多收藏时，在官方页面手动滚动或翻页，等待加载后重新读取', '缺少SKU、规格或需要其他规格时，打开对应商品详情页并读取SKU', '选择目标SKU后核对规格包装、价格单位及原网采关系，再生成人工复核草稿'],
  };
}
