/** Public promotion-label text only. Numeric flags and image URLs are not evidence.
 * The extractor is embedded in serialized readers, which cannot import helpers.
 */
export function collectPddPromotions(record,source='explicit_promotion_fields'){
  const read=(object,key)=>{try{return Object.getOwnPropertyDescriptor(object,key)?.value;}catch{return undefined;}};
  const fields=['promotionTags','promotion_tags','tagList','tag_list','variedTagsList','varied_tags_list','propertyTagList','property_tag_list','prefixIcons','prefix_icons','pricePrefixInfo','price_prefix_info','priceInfo','price_info','activityTags','activity_tags','serviceTags','service_tags','tags'];
  const textKeys=new Set(['text','name','title','label','content','desc','description','value','alt','altText','tagText','tag_text','tagName','tag_name','tagDesc','tag_desc','displayText','display_text','contentText','content_text','htmlText','html_text','prefixText','prefix_text']);
  const childKeys=new Set(['children','parts','spans','items','list','tags','tagList','tag_list','contents']);
  const imageKeys=['url','imageUrl','image_url','imgUrl','img_url','iconUrl','icon_url'];
  const seen=new WeakSet(),tags=[],observed=[];let visited=0,unknownBadgeCount=0,truncated=false;
  const normalize=value=>value.normalize('NFKC').replace(/<[^>]{0,300}>/g,'').replace(/&nbsp;|&#160;/gi,' ').replace(/&#(?:x([0-9a-f]{1,6})|([0-9]{1,7}));/gi,(_,hex,dec)=>{const n=parseInt(hex||dec,hex?16:10);return n>0&&n<=0x10ffff?String.fromCodePoint(n):'';}).replace(/\s+/g,' ').trim();
  const looksUrl=value=>typeof value==='string'&&/^(?:[a-z][a-z\d+.-]*:|\/\/)/i.test(value.trim());
  const add=value=>{
    if(typeof value!=='string'||!value.trim())return false;
    if(looksUrl(value)){unknownBadgeCount++;return false;}
    if(value.length>500)truncated=true;
    const text=normalize(value.slice(0,500));
    if(!text||/^#[\da-f]{3,8}$/i.test(text)||/^\d+(?:\.\d+)?(?:px|%)?$/.test(text))return false;
    if(tags.length>=60){truncated=true;return true;}
    const bounded=text.slice(0,180);if(text.length>180)truncated=true;
    if(!tags.includes(bounded))tags.push(bounded);return true;
  };
  const walk=(value,depth)=>{
    if(typeof value==='string')return add(value);
    if(!value||typeof value!=='object')return false;
    if(depth>6||visited>=180){truncated=true;return false;}
    if(seen.has(value))return false;seen.add(value);visited++;
    let readable=false;const fragmentStart=tags.length;
    if(Array.isArray(value)){
      if(value.length>40)truncated=true;
      for(let index=0;index<Math.min(value.length,40);index++)readable=walk(read(value,String(index)),depth+1)||readable;
      return readable;
    }
    let keys;try{keys=Object.keys(value).slice(0,80);}catch{return false;}
    for(const key of keys)if(textKeys.has(key)||childKeys.has(key))readable=walk(read(value,key),depth+1)||readable;
    // Join rendering fragments only inside one explicit label, never across unrelated tags.
    if(keys.some(key=>['children','parts','spans','contents'].includes(key))){
      const fragments=tags.slice(fragmentStart).join('').replace(/\s+/g,'');
      for(const phrase of ['百亿补贴','多人团'])if(fragments.includes(phrase)&&!tags.some(text=>text.replace(/\s+/g,'').includes(phrase)))add(phrase);
    }
    if(!readable&&imageKeys.some(key=>looksUrl(read(value,key))))unknownBadgeCount++;
    return readable;
  };
  if(record&&typeof record==='object')for(const field of fields){
    const value=read(record,field);if(value==null)continue;observed.push(field);walk(value,0);
  }
  // Preserve text-only evidence when a goods-only API snapshot is parsed again.
  const inherited=record&&read(record,'promotionEvidence');
  if(inherited&&typeof inherited==='object'){
    const unknown=read(inherited,'unknownBadgeCount');if(Number.isSafeInteger(unknown)&&unknown>0)unknownBadgeCount+=Math.min(unknown,180);
    if(read(inherited,'truncated')===true)truncated=true;
  }
  const names=record&&typeof record==='object'?['name','title','goodsName','goods_name','goodsTitle','goods_title','short_name','spec','specName','spec_name','skuName','sku_name'].map(key=>read(record,key)).filter(value=>typeof value==='string').map(value=>normalize(value.slice(0,1000))):[];
  const all=tags.concat(names),exclusionReasons=[];
  for(const phrase of ['百亿补贴','多人团'])if(all.some(text=>text.replace(/\s+/g,'').includes(phrase)))exclusionReasons.push('包含“'+phrase+'”标签');
  const inheritedFields=read(inherited||{},'fields'),hadOriginalEvidence=Array.isArray(inheritedFields);
  const evidenceFields=[...new Set((hadOriginalEvidence?inheritedFields.filter(value=>typeof value==='string'&&fields.includes(value)):[]).concat(observed.filter(field=>!hadOriginalEvidence||!['promotionTags','promotion_tags'].includes(field))))].slice(0,40);
  return {promotionTags:tags.slice(0,60),exclusionReasons,promotionEvidence:{source:typeof source==='string'?source.slice(0,80):'explicit_promotion_fields',fields:evidenceFields,textOnly:true,unknownBadgeCount:Math.min(unknownBadgeCount,360),truncated,verified:exclusionReasons.length>0||evidenceFields.length>0&&!unknownBadgeCount&&!truncated}};
}

export function evaluatePromotionEligibility(productOrSku){
  const result=collectPddPromotions(productOrSku);
  return {eligible:result.exclusionReasons.length===0,reasons:result.exclusionReasons,tags:result.promotionTags,verified:result.promotionEvidence.verified};
}
