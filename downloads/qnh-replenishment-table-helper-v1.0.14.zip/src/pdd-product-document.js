/** Read one already-listed product document on the official favorites origin.
 * No navigation, script execution, order endpoint, cookie or storage reads.
 * Only a strict JSON rawData assignment is accepted; returned data is goods-only.
 */
export async function readPddProductDocument({goodsId}={}){
 const positive=v=>typeof v==='string'&&/^[1-9]\d*$/.test(v);
 if(location.origin!=='https://mobile.yangkeduo.com'||!/^\/(?:likes|goods\d*)\.html$/.test(location.pathname)||!positive(goodsId))return {status:'unsupported',message:'仅可为当前官网收藏补齐商品规格'};
 const sourceUrl='https://mobile.yangkeduo.com/goods2.html?goods_id='+goodsId+'&qnh_spec_reader=1';
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),7000);
 try{
  const response=await fetch(sourceUrl,{method:'GET',credentials:'same-origin',signal:controller.signal,redirect:'follow'});
  const final=new URL(response.url||sourceUrl);
  if(!response.ok||final.origin!=='https://mobile.yangkeduo.com'||!/^\/goods\d*\.html$/.test(final.pathname)||final.searchParams.getAll('goods_id').length!==1||final.searchParams.get('goods_id')!==goodsId)return {status:'needs_user',message:'商品规格需要在官网详情页完成登录或验证后读取'};
  const html=await response.text();if(html.length>6000000)return {status:'not_ready',message:'商品文档过大，请打开详情读取规格'};
  const doc=new DOMParser().parseFromString(html,'text/html');let raw=null;
  // Balanced JSON, never eval, Function, script insertion or remote code execution.
  for(const script of [...doc.querySelectorAll('script:not([src])')].slice(0,80)){
   const text=script.textContent||'',match=/(?:window\s*\.\s*)?rawData\s*=\s*/.exec(text);if(!match)continue;
   const start=match.index+match[0].length;if(text[start]!=='{')continue;
   let depth=0,quoted=false,escaped=false,end=-1;
   for(let i=start;i<text.length;i++){const c=text[i];if(quoted){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')quoted=false;continue;}if(c==='"')quoted=true;else if(c==='{')depth++;else if(c==='}'&&--depth===0){end=i+1;break;}}
   if(end<0)continue;try{raw=JSON.parse(text.slice(start,end).replace(/("(?:goods_id|goodsId|goodsID|sku_id|skuId|group_id|groupId)"\s*:\s*)(\d{16,})(?=\s*[,}\]])/g,'$1"$2"'));}catch{continue;}if(raw?.store?.initDataObj?.goods)break;
  }
  const g=raw?.store?.initDataObj?.goods;if(!g||!Array.isArray(g.skus))return {status:'not_ready',message:'当前商品文档尚无可读取规格，请打开官网详情后同步'};
  // Never pass the document's other stores, login, account or address data.
  const goodsKeys=['goodsId','goodsID','goods_id','goodsName','goods_name','groupTypes','sku','specs','spec','specification','skuProperty','skuProps'];
  const skuKeys=['goodsId','goods_id','skuId','sku_id','specs','spec','spec_value','specValue','specName','spec_name','groupPrice','normalPrice','group_price','normal_price','priceUnit','quantity','isOnsale','is_sku_onsale'];
  const pick=(object,keys)=>Object.fromEntries(keys.filter(k=>Object.hasOwn(object,k)).map(k=>[k,object[k]]));
  const project=value=>{const out=pick(value,goodsKeys);for(const key of ['skus','sku'])if(Array.isArray(value[key]))out[key]=value[key].slice(0,500).filter(s=>s&&typeof s==='object').map(s=>pick(s,skuKeys));return out;};
  const goods=project(g),rich=raw?.store?.initDataObj?.oakData?.goods;
  return {status:'snapshot',kind:'pdd_product_document',sourceUrl:final.href,rawData:{store:{initDataObj:{goods,...(rich&&typeof rich==='object'?{oakData:{goods:project(rich)}}:{})}}},capturedAt:new Date().toISOString()};
 }catch{return {status:'not_ready',message:'商品规格暂未读取成功，请打开详情或稍后同步'};}finally{clearTimeout(timer);}
}
