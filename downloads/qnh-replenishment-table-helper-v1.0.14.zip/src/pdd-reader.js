/**
 * Serialized by chrome.scripting into the selected page's MAIN world.
 * Keep completely self-contained: no network, cookies, storage or page-code evaluation.
 * Schema evidence: ExtractProductControl.LoadProductDetail, lines 319–376.
 * The desktop code alone does not establish a browser price unit.
 */
export function readPddPage(input) {
  function collectPddPromotions(record,source='explicit_promotion_fields'){
    const read=(object,key)=>{try{return Object.getOwnPropertyDescriptor(object,key)?.value;}catch{return undefined;}};
    const fields=['promotionTags','promotion_tags','tagList','tag_list','variedTagsList','varied_tags_list','propertyTagList','property_tag_list','prefixIcons','prefix_icons','pricePrefixInfo','price_prefix_info','priceInfo','price_info','activityTags','activity_tags','serviceTags','service_tags','tags'];
    const textKeys=new Set(['text','name','title','label','content','desc','description','value','alt','altText','tagText','tag_text','tagName','tag_name','tagDesc','tag_desc','displayText','display_text','contentText','content_text','htmlText','html_text','prefixText','prefix_text']);
    const childKeys=new Set(['children','parts','spans','items','list','tags','tagList','tag_list','contents']);
    const imageKeys=['url','imageUrl','image_url','imgUrl','img_url','iconUrl','icon_url'];
    const seen=new WeakSet(),tags=[],observed=[];let visited=0,unknownBadgeCount=0,truncated=false;
    const normalize=value=>value.normalize('NFKC').replace(/<[^>]{0,300}>/g,'').replace(/&nbsp;|&#160;/gi,' ').replace(/&#(?:x([0-9a-f]{1,6})|([0-9]{1,7}));/gi,(_,hex,dec)=>{const n=parseInt(hex||dec,hex?16:10);return n>0&&n<=0x10ffff?String.fromCodePoint(n):'';}).replace(/\s+/g,' ').trim();
    const looksUrl=value=>typeof value==='string'&&/^(?:[a-z][a-z\d+.-]*:|\/\/)/i.test(value.trim());
    const add=value=>{
      if(typeof value!=='string'||!value.trim())return false;
      if(looksUrl(value)){unknownBadgeCount++;return false;}
      if(value.length>500)truncated=true;
      const text=normalize(value.slice(0,500));
      if(!text||/^#[\da-f]{3,8}$/i.test(text)||/^\d+(?:\.\d+)?(?:px|%)?$/.test(text))return false;
      if(tags.length>=60){truncated=true;return true;}
      const bounded=text.slice(0,180);if(text.length>180)truncated=true;
      if(!tags.includes(bounded))tags.push(bounded);return true;
    };
    const walk=(value,depth)=>{
      if(typeof value==='string')return add(value);
      if(!value||typeof value!=='object')return false;
      if(depth>6||visited>=180){truncated=true;return false;}
      if(seen.has(value))return false;seen.add(value);visited++;
      let readable=false;const fragmentStart=tags.length;
      if(Array.isArray(value)){
        if(value.length>40)truncated=true;
        for(let index=0;index<Math.min(value.length,40);index++)readable=walk(read(value,String(index)),depth+1)||readable;
        return readable;
      }
      let keys;try{keys=Object.keys(value).slice(0,80);}catch{return false;}
      for(const key of keys)if(textKeys.has(key)||childKeys.has(key))readable=walk(read(value,key),depth+1)||readable;
      // Join rendering fragments only inside one explicit label, never across unrelated tags.
      if(keys.some(key=>['children','parts','spans','contents'].includes(key))){
        const fragments=tags.slice(fragmentStart).join('').replace(/\s+/g,'');
        for(const phrase of ['百亿补贴','多人团'])if(fragments.includes(phrase)&&!tags.some(text=>text.replace(/\s+/g,'').includes(phrase)))add(phrase);
      }
      if(!readable&&imageKeys.some(key=>looksUrl(read(value,key))))unknownBadgeCount++;
      return readable;
    };
    if(record&&typeof record==='object')for(const field of fields){
      const value=read(record,field);if(value==null)continue;observed.push(field);walk(value,0);
    }
    // Preserve text-only evidence when a goods-only API snapshot is parsed again.
    const inherited=record&&read(record,'promotionEvidence');
    if(inherited&&typeof inherited==='object'){
      const unknown=read(inherited,'unknownBadgeCount');if(Number.isSafeInteger(unknown)&&unknown>0)unknownBadgeCount+=Math.min(unknown,180);
      if(read(inherited,'truncated')===true)truncated=true;
    }
    const names=record&&typeof record==='object'?['name','title','goodsName','goods_name','goodsTitle','goods_title','short_name','spec','specName','spec_name','skuName','sku_name'].map(key=>read(record,key)).filter(value=>typeof value==='string').map(value=>normalize(value.slice(0,1000))):[];
    const all=tags.concat(names),exclusionReasons=[];
    for(const phrase of ['百亿补贴','多人团'])if(all.some(text=>text.replace(/\s+/g,'').includes(phrase)))exclusionReasons.push('包含“'+phrase+'”标签');
    const inheritedFields=read(inherited||{},'fields'),hadOriginalEvidence=Array.isArray(inheritedFields);
    const evidenceFields=[...new Set((hadOriginalEvidence?inheritedFields.filter(value=>typeof value==='string'&&fields.includes(value)):[]).concat(observed.filter(field=>!hadOriginalEvidence||!['promotionTags','promotion_tags'].includes(field))))].slice(0,40);
    return {promotionTags:tags.slice(0,60),exclusionReasons,promotionEvidence:{source:typeof source==='string'?source.slice(0,80):'explicit_promotion_fields',fields:evidenceFields,textOnly:true,unknownBadgeCount:Math.min(unknownBadgeCount,360),truncated,verified:exclusionReasons.length>0||evidenceFields.length>0&&!unknownBadgeCount&&!truncated}};
  }

  const documentRead=input?.kind==='pdd_product_document'&&input?.status==='snapshot';
  const cap = (value, limit = 500) => String(value ?? '').slice(0, limit);
  const safeId = (value, zero = false) => {
    if (typeof value === 'number' && !Number.isSafeInteger(value)) return '';
    const text = String(value ?? '');
    return /^\d+$/.test(text) && (zero || !/^0+$/.test(text)) ? text : '';
  };
  const decimal = value => {
    if (typeof value === 'string' && /^\d+(?:\.\d+)?$/.test(value)) return value;
    if (typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= Number.MAX_SAFE_INTEGER && /^\d+(?:\.\d+)?$/.test(String(value))) return String(value);
    return '';
  };
  const integer = value => (typeof value === 'number' && Number.isSafeInteger(value) && value >= 0) || (typeof value === 'string' && /^\d+$/.test(value)) ? String(value) : '';
  let current;
  try { current = new URL(documentRead?input.sourceUrl:location.href); } catch { return { status: 'unsupported', message: '页面地址不可识别' }; }
  const official = current.origin === 'https://mobile.yangkeduo.com';
  const fixture = current.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(current.hostname) && current.port === '8765' && current.pathname === '/demo/pdd-product.html';
  const isDemo = fixture && globalThis.document?.documentElement?.getAttribute('data-pdd-demo') === 'true';
  if (!official && !isDemo) return { status: 'unsupported', message: '请选择拼多多商品标签页；演示仅支持明确标记的指定本地页面' };
  if (current.pathname === '/order_checkout.html') return { status: 'unsupported', message: '请停留在商品详情页；本插件不读取结算或付款页面' };
  if (!isDemo && !/^\/goods\d*\.html$/.test(current.pathname)) return { status: current.pathname === '/login.html' ? 'login_required' : 'unsupported', message: '请在浏览器完成官方登录，再打开拼多多商品详情页读取' };
  let raw = documentRead?input.rawData:window.rawData;
  if (typeof raw === 'string') { try { raw = JSON.parse(raw); } catch { raw = null; } }
  const goods = raw?.store?.initDataObj?.goods;
  if (!goods || !Array.isArray(goods.skus)) {
    return { status: 'parse_error', pageType: 'product', isDemo, message: '当前页面没有可识别的SKU数据；请等待加载或刷新商品页后重读。不能据此认定商品失效。', skus: [] };
  }
  const requestedIds=current.searchParams.getAll('goods_id');
  if (new Set(requestedIds).size>1) return {status:'unsafe_id',message:'页面地址包含冲突商品ID，请重新打开正确商品页'};
  const goodsId = safeId(goods.goodsId ?? goods.goodsID ?? goods.goods_id ?? current.searchParams.get('goods_id'));
  if (!goodsId) return { status: 'unsafe_id', message: '商品ID缺失或精度不可靠，请重新打开商品页核对' };
  if (requestedIds.length && requestedIds[0]!==goodsId) return {status:'unsafe_id',message:'页面商品ID与地址不一致，请刷新并核对商品'};
  const group = Array.isArray(goods.groupTypes) ? goods.groupTypes.at(-1) : null;
  const rawGroupId = group?.groupId ?? group?.group_id;
  const groupId = rawGroupId == null || rawGroupId === '' ? '0' : safeId(rawGroupId,true);
  if (!groupId) return {status:'unsafe_id',message:'拼团ID格式或精度不可靠，请重新读取官网商品',skus:[]};
  const groupIdSource = rawGroupId == null || rawGroupId === '' ? 'haixiaobao_default' : 'official_product';
  const detailUrl = `https://mobile.yangkeduo.com/goods.html?goods_id=${goodsId}`;
  const warnings = [];
  // The live store may replace full SKU objects with compact stock/price
  // models. The original inline JSON still contains their specification text.
  let originalGoods=null;
  if(!documentRead&&typeof globalThis.document?.querySelectorAll==='function'){
    for(const script of [...document.querySelectorAll('script:not([src])')].slice(0,80)){
      const source=script.textContent||'',match=/(?:window\s*\.\s*)?rawData\s*=\s*/.exec(source);if(!match||source.length>6000000)continue;
      const start=match.index+match[0].length;if(source[start]!=='{')continue;let depth=0,quoted=false,escaped=false,end=-1;
      for(let i=start;i<source.length;i++){const ch=source[i];if(quoted){if(escaped)escaped=false;else if(ch==='\\')escaped=true;else if(ch==='"')quoted=false;continue;}if(ch==='"')quoted=true;else if(ch==='{')depth++;else if(ch==='}'&&--depth===0){end=i+1;break;}}
      if(end<0)continue;try{const parsed=JSON.parse(source.slice(start,end)),g=parsed?.store?.initDataObj?.goods;if(safeId(g?.goodsId??g?.goodsID??g?.goods_id)===goodsId&&Array.isArray(g.skus)){originalGoods=g;break;}}catch{/* Script code is never evaluated. */}
    }
  }
  const richGoods=raw?.store?.initDataObj?.oakData?.goods;
  const richId=richGoods?.goodsId??richGoods?.goodsID??richGoods?.goods_id;
  const richRows=originalGoods?.skus||((richId==null||safeId(richId)===goodsId)?(Array.isArray(richGoods?.skus)?richGoods.skus:Array.isArray(richGoods?.sku)?richGoods.sku:[]):[]);
  const richById=new Map();
  for(const row of richRows.slice(0,500)){const id=safeId(row?.skuId??row?.sku_id??row?.skuID),gid=row?.goodsId??row?.goods_id;if(id&&(gid==null||safeId(gid)===goodsId))richById.set(id,row);}
  const goodsPromotions=collectPddPromotions(goods,'official_product_tags'),originalPromotions=collectPddPromotions(originalGoods,'official_product_original_tags');
  const mergePromotions=(...values)=>{const promotionTags=[...new Set(values.flatMap(v=>v.promotionTags))],exclusionReasons=[...new Set(values.flatMap(v=>v.exclusionReasons))],fields=values.flatMap(v=>v.promotionEvidence.fields),unknownBadgeCount=values.reduce((sum,v)=>sum+v.promotionEvidence.unknownBadgeCount,0),truncated=values.some(v=>v.promotionEvidence.truncated);return {promotionTags,exclusionReasons,promotionEvidence:{source:'official_product_and_sku_tags',fields:[...new Set(fields)],textOnly:true,unknownBadgeCount,truncated,verified:exclusionReasons.length>0||fields.length>0&&!unknownBadgeCount&&!truncated}};};
  const candidates = goods.skus.slice(0, 500).map(baseSku => {
    const rich=richById.get(safeId(baseSku?.skuId??baseSku?.sku_id??baseSku?.skuID));
    const sku=rich?{...rich,...baseSku,specs:Array.isArray(baseSku.specs)&&baseSku.specs.length?baseSku.specs:rich.specs,spec:Array.isArray(baseSku.spec)&&baseSku.spec.length||typeof baseSku.spec==='string'&&baseSku.spec?baseSku.spec:rich.spec}:baseSku;
    if (!sku || typeof sku!=='object') return null;
    const id = safeId(sku.skuId ?? sku.sku_id ?? sku.skuID);
    const rawGid=sku.goodsId ?? sku.goods_id;
    const gid = rawGid == null ? goodsId : safeId(rawGid);
    if (!id || !gid || gid!==goodsId) return null;
    const valueOf=spec=>typeof spec==='string'?cap(spec,150):spec&&typeof spec==='object'?[spec.spec_value,spec.specValue,spec.value,spec.spec_value_name,spec.specValueName,spec.spec_name,spec.specName].find(v=>typeof v==='string'&&v.trim())||'':'';
    const specRows=Array.isArray(sku.specs)?sku.specs:Array.isArray(sku.spec)?sku.spec:[];
    const specs=specRows.map(valueOf).map(v=>v.trim()).filter(Boolean);
    const direct=[sku.spec_value,sku.specValue,sku.specName,sku.spec_name,typeof sku.spec==='string'?sku.spec:''].find(v=>typeof v==='string'&&v.trim());
    if(!specs.length&&direct)specs.push(cap(direct,300));
    const rawPrice = sku.groupPrice ?? sku.group_price ?? sku.normalPrice ?? sku.normal_price ?? null;
    const price = decimal(rawPrice);
    if (rawPrice!=null && price==='') warnings.push('部分SKU价格格式或数值精度不可靠，未用于成本预览');
    const priceUnit = ['yuan', 'fen'].includes(sku.priceUnit) ? sku.priceUnit : 'unknown';
    const sale = sku.isOnsale ?? sku.is_sku_onsale;
    return {
      goodsId: gid, skuId: id, groupId, groupIdSource, goodsNumber: '1',
      name: cap(goods.goodsName ?? goods.goods_name),
      ...mergePromotions(goodsPromotions,originalPromotions,collectPddPromotions(sku,'official_product_sku_tags')),
      spec: specs.join(' / '),specComplete:specs.length>0&&(!specRows.length||specRows.every(s=>!!valueOf(s).trim())),specSource:specs.length?'product_sku':'missing',
      price, priceUnit, priceUnitSource: priceUnit === 'unknown' ? 'unverified_detail_field' : 'explicit_page_field',
      priceField: (sku.groupPrice ?? sku.group_price) != null ? 'groupPrice' : 'normalPrice',
      groupPrice: decimal(sku.groupPrice ?? sku.group_price), normalPrice: decimal(sku.normalPrice ?? sku.normal_price),
      stock: integer(sku.quantity),
      onSale: sale === 1 || sale === true ? true : sale === 0 || sale === false ? false : null,
      detailUrl,
      checkoutUrl: `https://mobile.yangkeduo.com/order_checkout.html?sku_id=${id}&group_id=${groupId}&goods_id=${gid}&goods_number=1`,
      source: documentRead&&input.sourceKind==='official_sku_render'?'pdd_sku_render_api':'pdd_page_rawData',
    };
  }).filter(Boolean);
  const unique = new Map();
  const conflicts = new Set();
  for (const sku of candidates) {
    const previous = unique.get(sku.skuId);
    if (previous && JSON.stringify(previous) !== JSON.stringify(sku)) conflicts.add(sku.skuId);
    else unique.set(sku.skuId, sku);
  }
  const skus = [...unique.values()].filter(sku => !conflicts.has(sku.skuId));
  if (conflicts.size) warnings.push('相同SKU出现冲突数据，已跳过冲突规格，请刷新后核对');
  if (goods.skus.length > 500) warnings.push('仅显示前500个SKU，请核对目标规格');
  if (candidates.length !== Math.min(goods.skus.length, 500)) warnings.push('部分SKU的ID不可靠，已跳过；请使用完整结算链接核对');
  if (skus.some(sku => !sku.spec)) warnings.push('部分SKU没有规格包装文本，请进入页面确认完整规格后再用于维护');
  if (skus.some(sku => sku.priceUnit === 'unknown')) warnings.push('页面价格单位必须人工确认；未按数值大小猜测元或分');
  warnings.push('库存与在售标记只反映本次页面数据，不保证实际可购买；生成链接不执行下单');
  if (isDemo) warnings.push('这是纯虚构演示商品，不代表真实拼多多商品或登录状态');
  return {
    status: skus.length ? 'read' : 'parse_error', pageType: 'product', isDemo,
    message: skus.length ? '' : '没有可安全读取的SKU', goodsId, groupId, groupIdSource,
    name: cap(goods.goodsName ?? goods.goods_name), ...mergePromotions(goodsPromotions,originalPromotions),sourceUrl: detailUrl,
    pageUrl: cap(current.href, 2048), capturedAt: new Date().toISOString(), skus,
    coverage: { complete: false, scope: 'currently_loaded_product_skus', loadedSkuCount: goods.skus.length, usableSkuCount: skus.length, truncated: goods.skus.length > 500 },
    warnings: [...new Set(warnings)],
  };
}
