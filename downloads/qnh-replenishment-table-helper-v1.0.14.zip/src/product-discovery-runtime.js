import {resolvePddSpecifications} from './pdd-spec-resolver.js';
import {readPddSearchPage} from './pdd-search-reader.js';
import {readPddSkuCatalog} from './pdd-sku-api.js';
import {readPddPage} from './pdd-reader.js';
import {ensureMobileSpecReader} from './pdd-mobile-specs.js';
import {buildProductSearchProfile} from './product-matching.js';
import {evaluateProcurementPrice,sortProcurementCandidates} from './procurement-price-policy.js';
import {evaluatePromotionEligibility} from './pdd-promotions.js';
import {targetIdentity} from './auto-fill.js';
import {setPddFavorite} from './pdd-favorite.js';
import {extractSpecQuantity,validateCheckoutPriceSource,isFreshCheckoutPrice} from './draft-defaults.js';

const failure=(code,message)=>Object.assign(Error(message),{code});
const key=c=>JSON.stringify([c.goodsId,c.skuId]);
const promotion=(...rows)=>({promotionTags:[...new Set(rows.flatMap(r=>r?.promotionTags||[]))],promotionEligibility:{eligible:true,reasons:[]},exclusionReasons:[]});
const rankProductCandidates=(profile,skus)=>skus.map(c=>{const q=extractSpecQuantity(c.spec,profile.unit);return {...c,recommendationTarget:profile.targetIdentity,matching:{status:'matched',quantity:q.quantity||'',ratioPdd:'1',ratioQnh:q.quantity||'',reasons:[]}};});
const policyFor=()=>({comparisonEnabled:false,purchasePriceDecimals:'2'});
/** Official search and quotes are read-only. Only a fresh, target-bound SKU click may favorite. */
export function createProductDiscoveryRuntime({api,ownedTab,inspect,commit,runOfficial,resolveSpecs=resolvePddSpecifications,reference,quote,cancelQuote,now=()=>Date.now(),wait=()=>new Promise(r=>setTimeout(r,400))}){
 let serial=0,active=null;
 const current=n=>serial===n;
 const target=async payload=>{
  if(!Number.isInteger(payload.tabId)||typeof payload.targetIdentity!=='string')throw failure('INVALID_DISCOVERY_TARGET','请先读取当前牵牛花商品');
  const snapshot=await inspect(payload.tabId),profile=buildProductSearchProfile(snapshot);
  if(targetIdentity(snapshot)!==payload.targetIdentity)throw failure('TARGET_CHANGED','牵牛花已切换商品，请等待新的推荐');
  if(snapshot.backendUpcSource!=='native_product'||!snapshot.backendUpc||!snapshot.nativeEditor)throw failure('INVALID_DISCOVERY_TARGET','尚未确认已选定的牵牛花商品');
  return {snapshot,profile};
 };
 const assertTarget=async(payload,profile)=>{const next=await target(payload);if(next.profile.profileKey!==profile.profileKey)throw failure('TARGET_CHANGED','商品规格已变化，请等待新推荐');return next;};
 const execute=async(tab,func,args)=>{const r=await api.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func,args:[args]});return r?.[0]?.result;};
 const restore=async(tab,expected,previous)=>{try{const now=await ownedTab();if(now.id===tab.id&&now.url===expected&&previous!==expected)await api.tabs.update(tab.id,{url:previous,active:false});}catch{}};
 const getReference=async()=>({status:'disabled',comparisonEnabled:false});
 const cost=(c,referenceCost,pricePolicy,profile,evaluatedAt=now())=>evaluateProcurementPrice({candidate:c,reference:referenceCost,ratioQnh:c.matching?.ratioQnh,ratioPdd:'1',maxIncreasePercent:pricePolicy.maxIncreasePercent,purchasePriceDecimals:pricePolicy.purchasePriceDecimals,profile,now:evaluatedAt,compareReference:false});
 const refreshCandidate=(c,fresh,profile)=>{
  if(!fresh||fresh.goodsId!==c.goodsId||fresh.skuId!==c.skuId)throw failure('QUOTE_IDENTITY_MISMATCH','报价未对应所选商品与SKU');
  const next={...c,...fresh,...promotion(c,fresh)};
  return rankProductCandidates(profile,[next])[0];
 };
 return {
  cancel({preserve=false,requestId,targetIdentity:expectedTarget,tabId}={}){
   // A delayed abort from an old side panel must not cancel a newer queued request.
   if(requestId!=null&&(!active||active.requestId!==requestId||expectedTarget!=null&&active.targetIdentity!==expectedTarget||tabId!=null&&active.targetTabId!==tabId))return {cancelled:false,status:'superseded',preserved:false};
   const cancelledSerial=++serial;if(active){active.preserve=preserve===true;active.cancelSerial=cancelledSerial;}cancelQuote?.();return {cancelled:true,preserved:preserve===true};
  },
  async progress(payload){
   if(!payload.requestId)throw failure('INVALID_SEARCH_REQUEST','检索请求标识缺失');
   const {profile}=await target(payload),{pddDiscovery:read}=await api.storage.local.get('pddDiscovery');
   if(!read||read.requestId!==payload.requestId||read.targetIdentity!==payload.targetIdentity||read.targetTabId!==payload.tabId||read.profile?.profileKey!==profile.profileKey)throw failure('STALE_RECOMMENDATION','推荐不属于当前商品与检索请求');
   await assertTarget(payload,profile);return read;
  },
  async search(payload){
   const n=++serial,requestId=String(payload.requestId||'').slice(0,100);if(!requestId)throw failure('INVALID_SEARCH_REQUEST','检索请求标识缺失');
   const pricePolicy=policyFor(payload.maxIncreasePercent),context={n,preserve:false,requestId,targetIdentity:payload.targetIdentity,targetTabId:payload.tabId};active=context;
   return runOfficial('search',async()=>{
    if(!current(n))return {status:'superseded'};
    const startedAt=now(),quotedInRound=new Map();
    const {snapshot,profile}=await target(payload),query=String(payload.query||profile.query||'').trim();
    pricePolicy.purchasePriceDecimals=String(snapshot.nativeEditor?.purchasePriceDecimals??snapshot.purchasePriceDecimals??'2');
    if(!query||query.length>80||/[\x00-\x1f]/.test(query))throw failure('INVALID_SEARCH_QUERY','请输入80字以内的商品搜索词');
    const referenceCost=await getReference(snapshot,profile,payload.refreshReference===true);if(!current(n))return {status:'superseded'};await assertTarget(payload,profile);
    const tab=await ownedTab(),previous=tab.url,searchUrl='https://mobile.yangkeduo.com/search_result.html?search_key='+encodeURIComponent(query);
    const broadQuery='',queries=[],searchReads=[];
    let navigated=false,workspaceUrl=previous;
    const readSearch=async searchQuery=>{
     if(!current(n))return {status:'superseded'};await assertTarget(payload,profile);
     const now=await ownedTab();if(now.id!==tab.id||now.url!==workspaceUrl)throw failure('PDD_WORKSPACE_CHANGED','官网页面已变化，请重新检索');
     const url='https://mobile.yangkeduo.com/search_result.html?search_key='+encodeURIComponent(searchQuery);
     queries.push(searchQuery);
     let result=await execute(now,readPddSearchPage,{query:searchQuery,fetchDocument:true});
     if(!current(n))return {status:'superseded'};await assertTarget(payload,profile);
     if(result?.status!=='read'&&!['login_required','needs_user'].includes(result?.status)){
      const before=await ownedTab();if(before.id!==tab.id||before.url!==workspaceUrl)throw failure('PDD_WORKSPACE_CHANGED','官网页面已变化，请重新检索');
      await api.tabs.update(tab.id,{url,active:false});navigated=true;workspaceUrl=url;
      for(let i=0;i<16&&current(n);i++){
       const t=await ownedTab();if(t.id!==tab.id)throw failure('PDD_WORKSPACE_CHANGED','官网连接已变化');
       if(t.status==='loading'){await wait();continue;}
       if(new URL(t.url).pathname==='/login.html'){result={status:'login_required',message:'请在官网完成登录后重新检索'};break;}
       if(t.url!==url){result={status:'needs_user',message:'官网检索需要处理登录或平台验证，请打开官网'};break;}
       result=await execute(t,readPddSearchPage,{query:searchQuery});
       if(result?.status==='read'||['login_required','needs_user'].includes(result?.status))break;
       await wait();
      }
     }
     if(result?.status==='read'){const after=await ownedTab();if(after.id!==tab.id||after.url!==workspaceUrl)throw failure('PDD_WORKSPACE_CHANGED','官网页面已变化，本次检索已暂停');}
     searchReads.push({query:searchQuery,sourceUrl:url,status:result?.status||'not_ready',productsRead:(result?.products||[]).length,truncated:result?.coverage?.truncated===true});
     return result;
    };
    const read=await readSearch(query);
    if(!current(n)){if(navigated)await restore(tab,workspaceUrl,previous);return {status:'superseded'};}
    if(read?.status!=='read')return {...read,status:read?.status||'not_ready',query,tabId:tab.id,message:read?.message||'暂未读取到官网搜索结果，请打开官网核对'};
    const searchedById=new Map(),inspectedIds=new Set(),excludedProducts=[],products=[],skus=[],issues=[];
    const exclude=p=>{const index=excludedProducts.findIndex(old=>old.goodsId===p.goodsId);if(index<0)excludedProducts.push(p);else excludedProducts[index]=p;};
    const ingest=(result,searchQuery,prioritizeNew=false)=>{
     const newIds=[];
     for(const incoming of (result.products||[]).slice(0,500)){
      const old=searchedById.get(incoming.goodsId),observed=promotion(incoming),next={...incoming,...old,...promotion(old,incoming),searchQueries:[...new Set([...(old?.searchQueries||[]),searchQuery])],promotionObservations:[...(old?.promotionObservations||[]),{query:searchQuery,promotionTags:observed.promotionTags,exclusionReasons:observed.exclusionReasons,promotionEvidence:observed.promotionEvidence}]};
      if(!old)newIds.push(incoming.goodsId);searchedById.set(incoming.goodsId,next);
      if(!next.promotionEligibility.eligible){exclude(next);for(let i=skus.length-1;i>=0;i--)if(skus[i].goodsId===next.goodsId)skus.splice(i,1);}
      else for(let i=0;i<skus.length;i++)if(skus[i].goodsId===next.goodsId)skus[i]={...skus[i],...promotion(skus[i],next),searchQueries:next.searchQueries,promotionObservations:next.promotionObservations};
     }
     const valid=p=>p.promotionEligibility.eligible&&!excludedProducts.some(old=>old.goodsId===p.goodsId),all=[...searchedById.values()].filter(valid);
     const pinned=all.filter(p=>inspectedIds.has(p.goodsId)),pending=all.filter(p=>!inspectedIds.has(p.goodsId));
     if(prioritizeNew)pending.sort((a,b)=>Number(!newIds.includes(a.goodsId))-Number(!newIds.includes(b.goodsId)));
     products.splice(0,products.length,...pinned,...pending);
    };
    ingest(read,query);
    const initialBatch=Math.min(6,products.length);let broadened=false;
    let inspected=0,hydrationComplete=false,quotesAttempted=0,quotesCompleted=0,quotePlan=[],quoteStatus='pending',lastResult;
    const cancellation=async()=>{
     if(!context.preserve||!lastResult||serial!==context.cancelSerial)return {status:'superseded'};
     const result={...lastResult,status:'partial',pending:false,cancelled:true,message:'已暂停后续核价，可选用已核价商品'};
     const stored=(await api.storage.local.get('pddDiscovery')).pddDiscovery;
     if(serial===context.cancelSerial&&stored?.requestId===requestId&&stored?.targetIdentity===payload.targetIdentity){await api.storage.local.set({pddDiscovery:result});}
     return serial===context.cancelSerial?result:{status:'superseded'};
    };
    const comparisonCost=c=>{
     const evaluatedAt=now(),strict=cost(c,referenceCost,pricePolicy,profile,evaluatedAt),proof=validateCheckoutPriceSource(c),capturedAt=proof.valid?Date.parse(proof.source.capturedAt):NaN;
     // Only a quote actually read in this search may remain as historical comparison.
     // Selection still rechecks the same proof against real current time in favorite().
     if(proof.valid&&quotedInRound.get(key(c))===proof.source.capturedAt&&capturedAt>=startedAt&&capturedAt<=evaluatedAt&&!isFreshCheckoutPrice(c,evaluatedAt))return {...cost(c,referenceCost,pricePolicy,profile,capturedAt),quoteStale:true,comparisonOnly:true};
     return {...strict,quoteStale:false,canRequestQuote:strict.status==='unpriced'&&c.matching?.status==='matched'};
    };
    const publish=async(status='partial',message='正在读取多个商品的具体规格，随后核验实际付款价…')=>{
     if(!current(n))return false;await assertTarget(payload,profile);if(!current(n))return false;
     const ranked=rankProductCandidates(profile,skus),priced=sortProcurementCandidates(ranked.map(c=>({...c,cost:comparisonCost(c)})));
     const result={status,query,searchMethod:'keyword',profile,products,skus:priced,sourceUrl:searchUrl,tabId:tab.id,targetTabId:payload.tabId,targetIdentity:payload.targetIdentity,requestId,capturedAt:new Date().toISOString(),referenceCost,pricePolicy,pending:status==='partial'&&quoteStatus!=='needs_user',quoteStatus,
      coverage:{queries:[...queries],queryReads:searchReads.map(r=>({...r})),searchProductsRead:searchedById.size,productsInspected:inspected,matchedProducts:new Set(ranked.filter(c=>c.matching?.status==='matched').map(c=>c.goodsId)).size,quotedProducts:new Set(priced.filter(c=>c.cost?.status==='eligible').map(c=>c.goodsId)).size,productsExcluded:excludedProducts.length,productsLimit:20,displayFiltersEnabled:false,hydrationComplete,quotesPlanned:quotePlan.length,quotesAttempted,quotesCompleted,quotesLimit:18,complete:hydrationComplete&&searchedById.size<=20&&!searchReads.some(r=>r.truncated||r.status!=='read')&&!issues.length&&quotesCompleted===quotePlan.length&&quotePlan.length>0&&ranked.filter(c=>c.matching?.status==='matched').length<=quotePlan.length},excludedProducts:excludedProducts.map(p=>({goodsId:p.goodsId,name:p.name,reasons:p.promotionEligibility.reasons})),issues:[...new Set(issues)],message};
     const cap=priced.find(c=>c.cost?.maxAllowedYuan)?.cost?.maxAllowedYuan;if(cap)result.pricePolicy={...pricePolicy,maxAllowedYuan:cap};
     await api.storage.local.set({pddDiscovery:result});lastResult=result;return current(n);
    };
    if(!await publish('partial','已显示搜索结果，正在读取规格…'))return cancellation();
    await ensureMobileSpecReader(api,tab.id);
    try{
     while(inspectedIds.size<20){
      if(!current(n))return cancellation();await assertTarget(payload,profile);
      const matchedProducts=new Set(rankProductCandidates(profile,skus).filter(c=>c.matching.status==='matched').map(c=>c.goodsId)).size;
      if(!broadened&&broadQuery&&broadQuery!==query&&inspectedIds.size>=initialBatch&&matchedProducts<3){
       broadened=true;const expanded=await readSearch(broadQuery);if(!current(n))return cancellation();await assertTarget(payload,profile);
       if(['needs_user','login_required'].includes(expanded?.status)){quoteStatus='needs_user';issues.push(expanded.message||'请完成官网登录或平台验证');if(!await publish('partial',expanded.message||'官网需要处理验证，已暂停拓宽检索'))return cancellation();return lastResult;}
       if(expanded?.status==='read')ingest(expanded,broadQuery,true);else issues.push(expanded?.message||'拓宽关键词暂未读取到有效搜索商品');
       if(!await publish('partial','正在补充不同店铺的同款商品，仍严格核对具体SKU与净含量…'))return cancellation();
      }
      const p=products.find(row=>!inspectedIds.has(row.goodsId));if(!p)break;
      const now=await ownedTab();if(now.id!==tab.id||now.url!==workspaceUrl)throw failure('PDD_WORKSPACE_CHANGED','官网页面已变化，本次检索已暂停');
      inspectedIds.add(p.goodsId);
      let raw=await execute(now,readPddSkuCatalog,{goodsId:p.goodsId});if(!current(n))return cancellation();await assertTarget(payload,profile);inspected++;
      if(!['snapshot','needs_user','login_required'].includes(raw?.status)&&current(n)){const recovered=await resolveSpecs({api,ownedTab,goodsId:p.goodsId,initialResult:raw,isCurrent:()=>current(n),wait});if(recovered)raw=recovered;}
      if(['needs_user','login_required'].includes(raw?.status)){quoteStatus='needs_user';issues.push(raw.message||'请完成官网登录或平台验证');if(!await publish('partial',raw.message||'官网需要处理验证，已暂停读取后续商品'))return cancellation();return lastResult;}
      if(!['snapshot','read'].includes(raw?.status)){issues.push(raw?.message||'部分商品规格暂未读取');if(!await publish())return cancellation();continue;}
      if(raw.rawData?.store?.initDataObj?.goods&&(!raw.rawData.store.initDataObj.goods.groupTypes?.length)&&typeof p.groupId==='string'&&/^\d+$/.test(p.groupId))raw.rawData.store.initDataObj.goods.groupTypes=[{groupId:p.groupId}];
      const detail=raw.status==='read'?raw:readPddPage(raw);if(detail.status!=='read'||detail.goodsId!==p.goodsId){issues.push('部分商品规格或身份尚未确认');if(!await publish())return cancellation();continue;}
      const goodsPromotion=promotion(p,detail);if(!goodsPromotion.promotionEligibility.eligible){exclude({...p,...goodsPromotion});if(!await publish())return cancellation();continue;}
      const merged={...detail,products:[{...p,...goodsPromotion,groupId:detail.groupId,groupIdSource:detail.groupIdSource,needsDetail:false}]};
      const catalog=await commit(merged,{id:tab.id,url:detail.sourceUrl});if(!current(n))return cancellation();await assertTarget(payload,profile);
      for(const rawCandidate of detail.skus.slice(0,80)){
       const c=catalog.skus.find(s=>s.goodsId===rawCandidate.goodsId&&s.skuId===rawCandidate.skuId&&s.sourceTabId===tab.id)||rawCandidate;
       const pc=promotion(p,detail,rawCandidate,c);if(!pc.promotionEligibility.eligible)continue;
       skus.push({...c,...pc,imageUrl:p.imageUrl||'',shopName:p.shopName||'',sourceTabId:tab.id,sourceUrl:detail.sourceUrl,capturedAt:detail.capturedAt,isDemo:false,searchQueries:p.searchQueries,promotionObservations:p.promotionObservations});
      }
      if(!await publish())return cancellation();
     }
    }finally{if(navigated)await restore(tab,workspaceUrl,previous);}
    if(!current(n))return cancellation();await assertTarget(payload,profile);hydrationComplete=true;
    const ranked=rankProductCandidates(profile,skus),groups=new Map();
    for(const c of ranked.filter(c=>c.matching.status==='matched')){if(!groups.has(c.goodsId))groups.set(c.goodsId,[]);groups.get(c.goodsId).push(c);}
    // First quote one SKU from every product; only then spend remaining capacity on variants.
    for(let index=0;quotePlan.length<18;index++){let added=false;for(const rows of groups.values()){if(rows[index]&&quotePlan.length<18){quotePlan.push(rows[index]);added=true;}}if(!added)break;}
    let lastQuoteUrl='',quoteNeedsUser=false;
    try{if(typeof quote==='function'){
     quoteStatus='pricing';if(!await publish('partial','已匹配多个商品，正在逐款读取券后实付价…'))return cancellation();
     for(const c of quotePlan){
      if(!current(n))return cancellation();await assertTarget(payload,profile);quotesAttempted++;
      lastQuoteUrl=c.checkoutUrl||'';const quoteId=requestId+':quote:'+quotesAttempted,readQuote=await quote(c,{requestId:quoteId,isCurrent:()=>current(n)});
      if(!current(n))return cancellation();await assertTarget(payload,profile);
      if(readQuote?.status==='needs_user'||readQuote?.status==='login_required'){quoteNeedsUser=true;quoteStatus='needs_user';issues.push(readQuote.message||'请处理官网登录或验证');await publish('partial',readQuote.message||'官网需要处理验证，已暂停后续核价');return lastResult;}
      if(readQuote?.status==='read'&&readQuote.candidate){
       const next=refreshCandidate(c,readQuote.candidate,profile),index=skus.findIndex(old=>key(old)===key(c));
       if(index>=0)skus[index]=next;const proof=validateCheckoutPriceSource(next);if(proof.valid&&Date.parse(proof.source.capturedAt)>=startedAt&&Date.parse(proof.source.capturedAt)<=now())quotedInRound.set(key(next),proof.source.capturedAt);quotesCompleted++;
      }else issues.push(readQuote?.message||'部分商品未取得有效实付报价');
      if(!await publish('partial','已核验 '+quotesCompleted+' / '+quotePlan.length+' 个采购规格，按后台单位实价排序'))return cancellation();
     }
    }
    }finally{if(lastQuoteUrl&&!quoteNeedsUser)await restore(tab,lastQuoteUrl,previous);}
    quoteStatus=typeof quote==='function'?'complete':'unavailable';
    const message=!skus.length?'搜索商品已全部展示；规格尚未读取，可打开商品详情查看':typeof quote!=='function'?'商品及规格已展示；选用时读取实付价':'搜索商品已全部展示，不进行筛选';
    if(!await publish(products.length?'read':'not_ready',message))return cancellation();context.done=true;return lastResult;
   });
  },
  async favorite(payload){
   return runOfficial('favorite',async()=>{
    const initialTarget=await target(payload);
    const {pddDiscovery:read,pddFavoritePending:pending={}}=await api.storage.local.get(['pddDiscovery','pddFavoritePending']);
    let c=read?.skus?.find(s=>s.goodsId===payload.goodsId&&s.skuId===payload.skuId&&s.matching?.status==='matched');
    if(!c||read.targetIdentity!==payload.targetIdentity||read.requestId!==payload.requestId||read.profile?.profileKey!==initialTarget.profile.profileKey)throw failure('STALE_RECOMMENDATION','推荐已变化，请选择当前商品最新的匹配规格');
    const tab=await ownedTab();if(tab.id!==read.tabId)throw failure('PDD_WORKSPACE_CHANGED','官网连接已变化，请重新检索');
    const {pddCatalog}=await api.storage.local.get('pddCatalog'),fresh=pddCatalog?.skus?.find(s=>s.goodsId===c.goodsId&&s.skuId===c.skuId&&s.sourceTabId===tab.id);
    if(fresh)c=refreshCandidate(c,fresh,initialTarget.profile);
    if(c.matching?.status!=='matched'||!promotion(c).promotionEligibility.eligible)throw failure('MATCH_CHANGED','当前SKU的规格或促销适用条件已变化，不能选用');
    if(typeof quote==='function'){
     const pricePolicy=policyFor(read.pricePolicy?.maxIncreasePercent);pricePolicy.purchasePriceDecimals=String(initialTarget.snapshot.nativeEditor?.purchasePriceDecimals??read.pricePolicy?.purchasePriceDecimals??'2');
     const referenceCost=await getReference(initialTarget.snapshot,initialTarget.profile,true);await assertTarget(payload,initialTarget.profile);
     const check=cost(c,referenceCost,pricePolicy,initialTarget.profile);if(check.status!=='eligible')throw failure('PRICE_NOT_ELIGIBLE',check.reason);
     // Never let a caller-supplied quote or comparison bypass the registered, current candidate.
     const latest=(await api.storage.local.get('pddDiscovery')).pddDiscovery;if(latest?.requestId!==read.requestId||latest?.targetIdentity!==read.targetIdentity)throw failure('STALE_RECOMMENDATION','推荐已更新，请选择最新商品');
    }
    const intentKey=JSON.stringify([tab.id,c.goodsId]),verifyOnly=!!pending[intentKey];
    if(!verifyOnly)await api.storage.local.set({pddFavoritePending:{...pending,[intentKey]:{at:new Date().toISOString(),goodsId:c.goodsId,skuId:c.skuId}}});
    let result,setterStarted=false;
    try{
     await assertTarget(payload,read.profile);
     setterStarted=true;result=await execute(tab,setPddFavorite,{goodsId:c.goodsId,skuId:c.skuId,verifyOnly});
    }catch(e){
     if(!verifyOnly&&!setterStarted){const freshPending=(await api.storage.local.get('pddFavoritePending')).pddFavoritePending||{};delete freshPending[intentKey];await api.storage.local.set({pddFavoritePending:freshPending});}
     throw e;
    }
    if(result?.status==='read'||(!verifyOnly&&result?.mutationAttempted===false)){
     const freshPending=(await api.storage.local.get('pddFavoritePending')).pddFavoritePending||{};delete freshPending[intentKey];await api.storage.local.set({pddFavoritePending:freshPending});
    }
    await target(payload);
    return result||{status:'unknown',message:'收藏结果未确认，请在官网核对'};
   });
  }
 };
}
