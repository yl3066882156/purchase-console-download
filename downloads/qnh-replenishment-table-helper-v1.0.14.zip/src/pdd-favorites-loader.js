/** One small official-page scroll per sync tick. No credentials, clicks or API writes. */
export function inspectPddFavoritesScroll({reset=false,advance=true,previous}={}){
 const url=location.href;
 if(location.origin!=='https://mobile.yangkeduo.com'||location.pathname!=='/likes.html')return {status:'needs_user',url,message:'收藏页已切换，自动加载已停止'};
 const doc=document,visible=n=>{if(!n||n.hidden||n.closest?.('[hidden],[aria-hidden="true"]'))return false;const s=getComputedStyle(n);return s.display!=='none'&&s.visibility!=='hidden'&&(!n.getClientRects||n.getClientRects().length>0);};
 const nodes=[...doc.querySelectorAll('body *')].slice(0,60000),leaves=nodes.filter(n=>!n.children.length&&visible(n));
 const words=n=>String(n.textContent||'').replace(/\s+/g,' ').trim();
 if(leaves.some(n=>/^(?:请完成安全验证|安全验证|请完成验证|滑动验证|点击完成验证|访问(?:过于)?频繁|操作(?:过于)?频繁|请稍后再试|HTTP ERROR 429)$/.test(words(n))))return {status:'needs_user',url,message:'拼多多要求验证或稍后重试，已保留读取结果'};
 const loading=leaves.some(n=>/^(?:加载中[.。…]*|正在加载[.。…]*|正在加载更多[.。…]*)$/.test(words(n))),empty=leaves.some(n=>/^(?:暂无收藏(?:商品)?|还没有收藏(?:商品)?|你还没有收藏(?:商品)?|暂无商品收藏)$/.test(words(n)));
 const ends=leaves.filter(n=>/^(?:没有更多(?:了|商品|收藏)?|已(?:经)?加载全部|已经到底了|到底(?:了|啦)|暂无更多|全部加载完毕|精选推荐|猜你喜欢|为你推荐)$/.test(words(n)));
 const anchors=[...doc.querySelectorAll('a[href]')].filter(n=>{try{const u=new URL(n.getAttribute('href'),url);return u.origin===location.origin&&/^\/goods\d*\.html$/.test(u.pathname)&&u.searchParams.has('goods_id')&&visible(n);}catch{return false;}});
 let raw=window.rawData;if(typeof raw==='string')try{raw=JSON.parse(raw);}catch{raw=null;}
 const goods=raw?.baseStore?.goodsSet,names=(Array.isArray(goods)?goods:Object.values(goods||{})).slice(0,20).map(g=>String(g?.goodsName||'')).filter(n=>n.length>3);
 const scrolling=doc.scrollingElement||doc.documentElement,roots=[scrolling,...nodes.filter(n=>{if(n===scrolling||!visible(n)||n.clientHeight<120||n.scrollHeight<=n.clientHeight+8)return false;return /auto|scroll/.test(getComputedStyle(n).overflowY);})].filter(Boolean);
 const scored=roots.map(node=>{const text=String(node.textContent||'');return {node,score:anchors.filter(a=>node.contains(a)).length+names.filter(name=>text.includes(name)).length};}).sort((a,b)=>b.score-a.score||a.node.clientHeight-b.node.clientHeight);
 const root=scored.find(s=>s.score>0)?.node||scored.filter(s=>s.node!==scrolling).sort((a,b)=>b.node.scrollHeight-a.node.scrollHeight)[0]?.node||scrolling;if(!root)return {status:'not_ready',url,message:'收藏滚动区域尚未加载'};
 const windowRoot=root===scrolling,viewport=windowRoot?{top:0,bottom:innerHeight}:root.getBoundingClientRect(),height=windowRoot?innerHeight:root.clientHeight;
 const top=()=>windowRoot?(window.scrollY||root.scrollTop||0):root.scrollTop;
 const setTop=value=>{if(windowRoot)window.scrollTo({top:value,behavior:'instant'});else root.scrollTop=value;root.dispatchEvent(new Event('scroll',{bubbles:true}));};
 if(reset){setTop(0);return {status:'ready',url,top:top(),height,scrollHeight:root.scrollHeight,reset:true};}
 const end=ends.some(n=>{const r=n.getBoundingClientRect();return r.top<=viewport.bottom+32&&r.bottom>=viewport.top;});
 const atBottom=end||top()+height>=root.scrollHeight-12;
 const hasMore=[raw?.baseStore?.hasMore,raw?.baseStore?.has_more].some(v=>v===true||v===1);
 const state={status:'ready',url,top:top(),height,scrollHeight:root.scrollHeight,atBottom,end,empty,loading,hasMore};
 if(advance&&!end&&!empty&&!loading){
  const next=Math.max(0,Math.min(root.scrollHeight-height,top()+Math.max(160,height*.85)));
  const alreadyTried=previous?.scrollHeight===state.scrollHeight&&previous?.scrolledTo===top();
  if(next!==top()||hasMore&&!alreadyTried)setTop(next);
  state.scrolledTo=top();
 }
 return state;
}

export function startFavoritesLoad(tabId,now=Date.now()){
 return {id:'favorites-'+now+'-'+Math.random().toString(36).slice(2),tabId,state:'running',startedAt:now,updatedAt:now,lastProgressAt:now,seen:[],round:0,endChecks:0};
}

export function advanceFavoritesLoad(job,{products=[],observation={},truncated=false,now=Date.now()}={}){
 if(job.state!=='running')return job;
 const seen=[...new Set([...job.seen,...products.map(p=>p.goodsId)])],previous=job.metrics;
 const progress=seen.length>job.seen.length||!previous||observation.top!==previous.top||observation.scrollHeight!==previous.scrollHeight;
 const next={...job,seen,round:job.round+1,updatedAt:now,lastProgressAt:progress?now:job.lastProgressAt,metrics:observation,endChecks:observation.end&&!observation.loading&&!observation.hasMore?(progress?1:job.endChecks+1):0};
 if(observation.status!=='ready')return {...next,state:'paused',reason:observation.message||'收藏页面尚未就绪'};
 if(truncated)return {...next,state:'limit',reason:'达到单次自动读取容量，尚未完成全部收藏加载'};
 if(next.endChecks>=2||(observation.empty&&!seen.length&&!observation.loading))return {...next,state:'complete',productsComplete:true,reason:'已到达收藏末尾'};
 if(now-next.startedAt>=600000||next.round>=300)return {...next,state:'paused',reason:'自动加载已超时，保留当前结果，可点击立即同步重试'};
 if(!observation.loading&&now-next.lastProgressAt>=14000&&observation.atBottom)return {...next,state:'settled',productsComplete:false,reason:'已滚动到底，页面暂未返回更多收藏；未提供明确结束标记'};
 if(now-next.lastProgressAt>=45000)return {...next,state:'paused',reason:'收藏页面长时间没有加载进展，保留结果，请处理官网提示后重试'};
 return next;
}

export function favoritesLoadProgress(job){
 if(!job)return null;
 return {id:job.id,state:job.state,count:job.seen.length,round:job.round,productsComplete:job.productsComplete===true,message:job.state==='running'?'正在自动加载收藏，已读取 '+job.seen.length+' 个商品…':job.state==='complete'?'已自动加载到收藏末尾，共 '+job.seen.length+' 个商品。':(job.reason||'自动加载已停止')+'（已读取 '+job.seen.length+' 个商品）'};
}
