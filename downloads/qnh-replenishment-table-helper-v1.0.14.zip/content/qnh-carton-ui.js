/* Read-only carton control anchor for existing-unit selection. */
(() => {
  'use strict';
  const VERSION = '4';
  if (globalThis.__qrthCartonAnchorInstalled === VERSION) return;
  globalThis.__qrthCartonAnchorInstalled = VERSION;
  const doc = globalThis.document, runtime = globalThis.chrome?.runtime;
  if (!doc?.body || !runtime?.sendMessage) return;
  const OWNED = '[data-qnh-owned]', FIELD = '.pms-roo-form-pro-item, .pms-roo-form-item, .ant-form-item, .el-form-item, .form-group, [data-qnh-item]';
  const LABELS = 'label, .pms-roo-form-pro-item-label, .pms-roo-form-item-label, .ant-form-item-label, .el-form-item__label, [data-qnh-label]';
  const SELECTS = 'select, [role="combobox"], .pms-ant-select, .ant-select, .pms-roo-select';
  const norm = value => String(value ?? '').replace(/\u00a0/g, ' ').trim();
  const clean = value => norm(value).replace(/[\s:：*＊]/g, '');
  const all = (root, selector) => [...root.querySelectorAll(selector)];
  const own = node => !!node?.closest?.(OWNED);
  function visible(node) {
    if (!node || own(node) || node.isConnected === false) return false;
    for (let n = node; n && n !== doc; n = n.parentElement) {
      if (n.hidden || n.getAttribute?.('aria-hidden') === 'true') return false;
      const style = globalThis.getComputedStyle?.(n);
      if (style?.display === 'none' || style?.visibility === 'hidden' || style?.visibility === 'collapse') return false;
    }
    return !node.getClientRects || node.getClientRects().length > 0;
  }
  function staticText(node) {
    if (!visible(node) || /^(INPUT|SELECT|TEXTAREA|BUTTON|STYLE|SCRIPT|TEMPLATE)$/.test(node.tagName)) return '';
    return norm([...node.childNodes].map(child => child.nodeType === 3 ? child.textContent : staticText(child)).filter(Boolean).join('\n'));
  }
  const labels = root => all(root, LABELS).filter(visible);
  const productLabels = root => labels(root).filter(node => /^(牵牛花商品名称|牵牛花商品)$/.test(clean(node.textContent)));
  function fieldItem(label) {
    const known = label.closest(FIELD);
    if (known) return known;
    for (let node = label.parentElement, depth = 0; node && depth < 4 && !/^(FORM|BODY|MAIN)$/.test(node.tagName); node = node.parentElement, depth++) {
      if (all(node, SELECTS).some(visible)) return node;
    }
    return null;
  }
  function formScope(item) {
    // Find the nearest region that contains this field and exactly one selected
    // product field. No PDD channel or six editable link fields are required.
    for (let node = item.parentElement; node && node !== doc.body; node = node.parentElement) {
      if (productLabels(node).length) return node;
    }
    return null;
  }
  function contexts() {
    const found = new Map();
    for (const label of labels(doc)) {
      if (clean(label.textContent) !== '箱规单位') continue;
      const item = fieldItem(label); if (!item) continue;
      const candidates = all(item, SELECTS).filter(visible);
      const controls = candidates.filter(node => !candidates.some(parent => parent !== node && parent.contains(node)));
      if (controls.length !== 1) continue;
      const scope = formScope(item); if (!scope) continue;
      found.set(controls[0], {item, control: controls[0], scope});
    }
    return [...found.values()];
  }
  function tenantId() {
    const ids = new Set();
    for (const node of all(doc, '[data-qnh-tenant-id], [data-tenant-id], [data-merchant-id]').filter(visible)) {
      for (const key of ['data-qnh-tenant-id', 'data-tenant-id', 'data-merchant-id']) {
        const value = norm(node.getAttribute(key)); if (/^[1-9]\d*$/.test(value)) ids.add(value);
      }
    }
    const headerNodes = new Set(all(doc, 'header, [role="banner"], .ant-layout-header, .el-header, [data-qnh-header]').filter(visible).flatMap(node => [node, ...all(node, 'span, p, div')]));
    for (const node of all(doc, 'span').filter(visible)) {
      if (node.closest('table, [role="dialog"], .ant-modal-content, .el-dialog')) continue;
      const r = node.getBoundingClientRect();
      if (r.top >= 0 && r.top < 180 && r.bottom <= 200 && r.width > 0 && r.height > 0) headerNodes.add(node);
    }
    for (const node of headerNodes) {
      const text = norm(node.textContent); if (text.length > 160) continue;
      for (const match of text.matchAll(/(?:^|[（(]|\s)租户\s*ID\s*[:：]\s*([1-9]\d*)(?=$|[）)]|\s)/gi)) ids.add(match[1]);
    }
    if (ids.size !== 1) throw Error('无法确认当前租户，请核对页面商家后重试');
    return [...ids][0];
  }
  function targetFor(context) {
    const anchors = productLabels(context.scope), regions = new Set();
    if (!anchors.length) throw Error('请先关联牵牛花商品');
    for (const label of anchors) {
      const item = label.closest(FIELD) || label.parentElement;
      regions.add(item);
      if (/UPC\s*[:：]?\s*\d{8,20}(?!\d)/i.test(staticText(item))) continue;
      // Some native layouts render the selected card immediately after its field.
      for (let next = item.nextElementSibling, count = 0; next && count < 3; next = next.nextElementSibling, count++) {
        if (!visible(next)) continue;
        const value = staticText(next);
        if (/UPC\s*[:：]?\s*\d{8,20}(?!\d)/i.test(value)) { regions.add(next); break; }
        if (value && !/^(已选商品|已关联商品|当前商品)[:：]?$/.test(value)) break;
      }
    }
    const products = new Map();
    for (const region of regions) {
      const text = staticText(region), upcs = [...new Set([...text.matchAll(/(?:^|\b)UPC\s*[:：]?\s*(\d{8,20})(?!\d)/gi)].map(match => match[1]))];
      const name = text.split(/\r?\n/).map(norm).find(line => line && !/^(牵牛花商品名称|牵牛花商品|已选商品|已关联商品|当前商品|UPC|\d{8,20}|请选择.*|搜索|查询|删除|更换|移除|预览|查看图片)$/i.test(clean(line)) && !/^(?:UPC\b|规格\s*[:：]|类目\s*[:：])/i.test(line));
      if (upcs.length !== 1 || !name) continue;
      if (products.has(upcs[0]) && products.get(upcs[0]) !== name) throw Error('当前商品卡片身份冲突，请重新选择商品');
      products.set(upcs[0], name);
    }
    if (products.size !== 1) throw Error('未找到唯一已关联商品，请先选择牵牛花商品后重试');
    const [upc, name] = [...products][0];
    return {tenantId: tenantId(), upc, name};
  }
  function current() {
    const found = contexts();
    if (found.length !== 1) throw Error(found.length ? '存在多个箱规单位表单，请只保留当前目标表单' : '未找到可用的箱规单位表单');
    return {...found[0], target: targetFor(found[0])};
  }
  // Read-only anchor provider. No additional carton-creation UI is installed.
  runtime.onMessage?.addListener((message,sender,respond)=>{
    if(message?.type!=='QRTH_CARTON_GET_TARGET'||sender.id!==runtime.id)return false;
    try{const state=globalThis.__qnhReplenishmentTableState?.();if(!state?.eligible||state.token!==message.tableToken)throw Error('抽屉已切换');const now=current();let anchor=now.control.getAttribute('data-qrth-carton-anchor');if(!anchor){anchor=crypto.randomUUID();now.control.setAttribute('data-qrth-carton-anchor',anchor);}respond({ok:true,data:{target:now.target,anchor}});}catch(e){respond({ok:false,error:{message:e.message}});}return false;
  });
})();
