(()=>{
 if(window.top!==window||globalThis.__qrthHost)return;globalThis.__qrthHost=true;
 document.getElementById('qrth-floating-table')?.remove();
 const host=document.createElement('div');host.id='qrth-floating-table';host.style.cssText='all:initial;position:fixed;inset:0;z-index:2147483646;pointer-events:none;display:none';
 const root=host.attachShadow({mode:'open'});root.innerHTML=`<style>:host{font:14px/1.5 -apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif;color:#263c38}*{box-sizing:border-box}button,input{font:inherit}button:focus-visible,a:focus-visible,input:focus-visible{outline:2px solid #187557;outline-offset:2px}button{cursor:pointer;border:1px solid #ccdcd6;border-radius:6px;background:white;color:#245449;padding:6px 10px}button:disabled{opacity:.45;cursor:default}input{border:1px solid #cadbd4;border-radius:6px;padding:7px;width:min(260px,100%);min-width:0}.toggle{pointer-events:auto;position:fixed;right:calc(var(--editor-right, 0px) + 12px);top:16px;background:#146b58;color:white;box-shadow:0 4px 16px #0003}.panel{pointer-events:auto;position:fixed;right:var(--editor-right, 0px);top:62px;width:var(--panel-width, 0px);max-height:calc(100vh - 90px);display:flex;flex-direction:column;background:#fff;border:1px solid #cbded4;border-radius:12px;box-shadow:0 12px 40px #0004;overflow:hidden}.bar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:10px 14px;background:#f1f7f4}.bar strong{flex:1}p{margin:8px 14px;font-size:12px}.status{white-space:pre-wrap;color:#7b4d09;overflow-wrap:anywhere}.scroll{overflow:auto;min-height:0}table{border-collapse:separate;border-spacing:0;width:100%;min-width:940px;font-size:12px}tbody tr:nth-child(even){background:#f5f6f7}tbody tr:hover{background:#eef7f3}tbody tr td:nth-child(2),tbody tr td:nth-child(3){white-space:nowrap;font-variant-numeric:tabular-nums}th,td{border-bottom:1px solid #e2e6e5;border-right:1px solid #ecefee;text-align:left;padding:9px;vertical-align:top;max-width:350px;overflow-wrap:anywhere}th{position:sticky;top:0;z-index:2;background:#edf5f1;white-space:nowrap}a{color:#126b58;display:block;max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.copy{border:0;padding:0;background:transparent;color:inherit;cursor:copy;text-align:left;max-width:100%;overflow-wrap:anywhere}.copy:hover{color:#126b58;text-decoration:underline}.copy.link{color:#126b58;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;display:block;max-width:320px;width:100%}.toast{position:fixed;right:calc(var(--editor-right,0px) + 12px);top:58px;max-width:min(380px,90vw);padding:8px 12px;background:#146b58;color:white;border-radius:6px;z-index:4}.variant{color:#596963;margin-top:3px}.thumbnail-cell{text-align:center;color:#596963;min-width:66px;height:67px}.thumbnail-cell img{display:block;object-fit:contain;background:#f5f6f7;border-radius:6px;margin:0 auto}th:last-child,td:last-child{position:sticky;right:0;border-left:1px solid #e2e6e5}th:last-child{z-index:3}td:last-child{white-space:nowrap;background:#fff;z-index:1}tbody tr:nth-child(even) td:last-child{background:#f5f6f7}tbody tr:hover td:last-child{background:#eef7f3}td:last-child button:first-child{background:#146b58;color:white;border-color:#146b58}td:last-child button+button{margin-left:5px}.sync-status{color:#365e52}.pager{justify-content:flex-end}[hidden]{display:none!important}
 tbody td{vertical-align:middle}
 .spec-cell{width:180px;min-width:160px;max-width:220px}
 .spec-cell strong,.spec-cell .variant,.spec-cell .copy{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
 .spec-cell .copy:focus-visible{outline-offset:-2px}
 </style><button class="toggle" aria-expanded="false">收藏表格 ▾</button><section class="panel" hidden aria-label="补货参考收藏表格"><div class="bar"><strong>拼多多收藏 · 补货参考代填</strong><button data-act="close">收起</button></div><div class="bar"><button data-act="login">扫码登录</button><button data-act="favorites">打开收藏</button><button data-act="sync">立即同步</button><button data-act="stop" hidden>停止同步</button><input type="search" placeholder="搜索商品ID、规格ID、名称、规格" aria-label="搜索收藏"></div><p>仅绑定本标签页当前编辑抽屉。采购价请在原表单手填；代填不保存。单价为来源参考价，不是结算应付价；缺失字段显示 —。</p><p class="sync-status" role="status"></p><p class="status" role="status" aria-live="polite"></p><div class="scroll"><table><thead><tr><th scope="col">图片</th><th>商品ID</th><th>规格ID</th><th>规格值</th><th>抢购链接</th><th>库存</th><th>单价</th><th>原价</th><th>操作</th></tr></thead><tbody></tbody></table></div><div class="bar pager"><button data-act="prev">上一页</button><span class="page"></span><button data-act="next">下一页</button></div></section><div class="toast" role="status" hidden></div>`;
 document.documentElement.append(host);let current='',panel=null,loading=false,drawer=null,toastTimer;
 const section=root.querySelector('.panel'),toggle=root.querySelector('.toggle'),toast=root.querySelector('.toast');
 const showToast=text=>{toast.textContent=text;toast.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.hidden=true,3200);};
 const close=()=>{section.hidden=true;toggle.setAttribute('aria-expanded','false');toggle.textContent='收藏表格 ▾';panel?.setVisible(false);};
 root.querySelector('[data-act="close"]').onclick=close;
 toggle.onclick=async()=>{if(!current)return;if(!section.hidden){close();return;}section.hidden=false;toggle.setAttribute('aria-expanded',String(!section.hidden));toggle.textContent=section.hidden?'收藏表格 ▾':'收藏表格 ▴';if(!panel&&!loading){loading=true;try{const mod=await import(chrome.runtime.getURL('src/table-panel.js'));panel=mod.mountTable(root,()=>current,{onSuccess:message=>{close();showToast(message);}});}catch(e){root.querySelector('.status').textContent='加载失败：'+e.message;}finally{loading=false;}}panel?.setVisible(!section.hidden);};
 function position(){
  if(!drawer?.isConnected)return;
  const box=drawer.getBoundingClientRect(),viewport=document.documentElement.clientWidth;
  const right=Math.min(viewport,box.right),left=Math.max(0,box.left);
  if(right<=left)return;
  host.style.setProperty('--panel-width',Math.min(box.width/2,right-left)+'px');
  host.style.setProperty('--editor-right',viewport-right+'px');
 }
 const resize=new ResizeObserver(position);
 const drawerSelector='[data-qnh-editor], [role="dialog"], .pms-roo-drawer-content, .pms-ant-drawer-content, .ant-drawer-content, .el-drawer';
 const layoutAttrs=['class','style','hidden','aria-hidden','open'];
 const editorCaption=/牵牛花商品名称|采购渠道|下单比例|供应商|采购价|关联信息|供应信息/;
 const inReference=()=>['/home.html','/'].includes(location.pathname)&&location.hash.split('?')[0]==='#/purchase/replenishment/refer';
 let editor=null,labels=[],candidateDrawers=new Set(),scheduled=0,lastUrl='';
 function scheduleRefresh(){
  if(scheduled)return;
  scheduled=setTimeout(()=>{scheduled=0;if(host.isConnected&&inReference())refresh();},100);
 }
 // The list is dynamic. Only discover editors from relevant additions or
 // removals, and watch attributes separately on the possible editor's path.
 const discovery=new MutationObserver(records=>{
  if(!host.isConnected){dispose();return;}
  if(labels.some(label=>!label.isConnected)||records.some(({target,addedNodes})=>
   editor?.contains(target)||
   (candidateDrawers.size&&candidateDrawers.has(target.closest?.(drawerSelector)))||
   Array.from(addedNodes).some(node=>node.matches?.(drawerSelector)||
    (labels.length&&!editor?editorCaption.test(node.textContent):node.textContent?.includes('牵牛花商品名称')))
  ))scheduleRefresh();
 });
 const editorChanges=new MutationObserver(scheduleRefresh);
 function watchEditor(){
  editorChanges.disconnect();
  const ancestors=new Set();
  for(const candidate of [...labels,...(editor?[editor]:[])]){
   for(let node=candidate;node;node=node.parentElement)ancestors.add(node);
  }
  for(const node of ancestors)editorChanges.observe(node,{attributes:true,attributeFilter:layoutAttrs});
  if(editor)editorChanges.observe(editor,{subtree:true,attributes:true,attributeFilter:layoutAttrs,characterData:true});
 }
 function refresh(){
  const s=globalThis.__qnhReplenishmentTableState?.({watchLabels:true})||{},next=s.eligible?s.token:'';
  if(next!==current){current=next;close();panel?.invalidate();}
  editor=current?globalThis.__qnhReplenishmentTableEditor?.():null;
  labels=s.labels||[];
  candidateDrawers=new Set(labels.map(node=>node.closest(drawerSelector)).filter(Boolean));
  if(inReference())watchEditor();
  const measured=editor?.closest('.pms-roo-drawer-content, .pms-ant-drawer-content, .ant-drawer-content, .el-drawer')||editor;
  if(measured!==drawer){resize.disconnect();drawer=measured;if(drawer)resize.observe(drawer);}
  position();host.style.display=current?'':'none';
 }
 function stopWatching(){
  clearTimeout(scheduled);scheduled=0;discovery.disconnect();editorChanges.disconnect();
 }
 function dispose(){
  stopWatching();resize.disconnect();panel?.invalidate();
  window.removeEventListener('resize',position);
  window.removeEventListener('hashchange',routeChanged);window.removeEventListener('popstate',routeChanged);
  globalThis.navigation?.removeEventListener('currententrychange',routeChanged);
 }
 function routeChanged(){
  if(lastUrl===location.href)return;
  lastUrl=location.href;
  stopWatching();
  if(!host.isConnected){dispose();return;}
  if(inReference())discovery.observe(document.documentElement,{subtree:true,childList:true});
  refresh();
 }
 window.addEventListener('resize',position);
 window.addEventListener('hashchange',routeChanged);window.addEventListener('popstate',routeChanged);
 globalThis.navigation?.addEventListener('currententrychange',routeChanged);
 routeChanged();
 root.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
})();
