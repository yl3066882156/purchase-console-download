/* Classic content script. Business DOM only: no API, credentials or Save click. */
(() => {
  'use strict';
  if (globalThis.__qnhReplenishmentTableAdapterInstalled === '1.3.0') return;
  globalThis.__qnhReplenishmentTableAdapterInstalled = '1.3.0';
  const doc = globalThis.document, bindings = new Map(), refs = new WeakMap();
  let serial = 0, active = null;
  let cartonSelection = null;
  const session = Math.random().toString(36).slice(2, 10);
  const labels = {
    relationId:['网采关系ID','网采关系 ID','网采关系编号'],tenantId:['租户ID','租户编码','商家ID','商家编码'],
    backendSku:['牵牛花商品编码','后台商品SKU','后台SKU','后台商品编码'],
    backendName:['牵牛花商品名称','后台商品名称'],backendSpec:['后台规格','牵牛花规格'],
    backendUnit:['后台采购单位','后台单位','采购单位'],backendUpc:['UPC','商品UPC','牵牛花商品UPC'],channel:['采购渠道'],supplier:['供应商','供应商名称'],
    oldUrl:['渠道商品链接','结算链接','商品链接','网采链接'],
    pddGoodsId:['渠道商品ID','渠道商品编码','拼多多商品ID','goods_id'],pddSkuId:['渠道规格ID','拼多多SKU','SKU ID','sku_id'],
    channelSpec:['渠道商品规格','渠道规格'],scopeText:['完整供货范围','供货范围'],
    excludedScopeText:['非供货范围','排除范围'],ratioRaw:['下单比例'],constraintsText:['采购约束','起订规则']
  };
  const keys=['tenantId','relationId','backendSku','backendName','backendSpec','backendUnit','channel','supplier','oldUrl','pddGoodsId','pddSkuId','channelSpec','scopeText','scopeComplete','ratioRaw','constraintsText'];
  const invariants=['backendSku','backendName','backendSpec','backendUnit','supplier','channel','scopeText','ratioRaw','constraintsText'];
  const norm=v=>String(v??'').replace(/\u00a0/g,' ').replace(/[ \t]+/g,' ').trim();
  const clean=v=>norm(v).replace(/[\s:：*＊]/g,'').toLowerCase();
  const attr=(n,k)=>n?.getAttribute?.(k)||'';
  // Cache only inside one synchronous, read-only observation. No cache survives
  // a native click, input event, await, polling iteration or handler boundary.
  let readScope=null;
  function observeDom(read){
    if(readScope)return read();
    readScope={nodes:Object.create(null),queries:new WeakMap(),globals:new Map()};
    try{return read();}finally{readScope=null;}
  }
  function memoNode(kind,node,read){
    if(!readScope||!node||(typeof node!=='object'&&typeof node!=='function'))return read();
    const cache=readScope.nodes[kind]||(readScope.nodes[kind]=new WeakMap());
    if(!cache.has(node))cache.set(node,read());return cache.get(node);
  }
  const query=(root,selector)=>{
    const read=()=>{try{return [...root.querySelectorAll(selector)].filter(node=>!node.closest?.('[data-qnh-owned]'));}catch{return [];}};
    if(!readScope||!root||(typeof root!=='object'&&typeof root!=='function'))return read();
    let cache=readScope.queries.get(root);if(!cache){cache=new Map();readScope.queries.set(root,cache);}
    if(!cache.has(selector))cache.set(selector,read());return cache.get(selector);
  };
  const text=node=>memoNode('text',node,()=>norm(node?.value!==undefined&&/^(INPUT|TEXTAREA|SELECT)$/.test(node.tagName)?node.value:node?.innerText??node?.textContent));
  const unique=a=>[...new Set(a.map(norm).filter(Boolean))];
  function visible(n){return memoNode('visible',n,()=>readVisible(n));}
  function readVisible(n) {
    if(!n||n.closest?.('[data-qnh-owned]')||n.hidden||n.isConnected===false)return false;
    for(let x=n;x&&x!==doc;x=x.parentElement){
      if(x.hidden||attr(x,'aria-hidden')==='true'||(x.tagName==='DIALOG'&&!x.open))return false;
      const s=memoNode('style',x,()=>globalThis.getComputedStyle?.(x));
      if(s?.display==='none'||s?.visibility==='hidden')return false;
    }
    return !n.getClientRects||n.getClientRects().length>0;
  }
  function fail(code,message,details){const e=new Error(message);e.code=code;e.details=details;throw e;}
  function hash(v){
    // Deterministic change detector, not an authentication/security primitive.
    const s=JSON.stringify(v);let a=2166136261,b=5381;
    for(let i=0;i<s.length;i++){a=Math.imul(a^s.charCodeAt(i),16777619);b=Math.imul(b,33)^s.charCodeAt(i);}
    return 'qnh-dom-v1-'+(a>>>0).toString(16).padStart(8,'0')+(b>>>0).toString(16).padStart(8,'0');
  }
  const fingerprint=s=>hash(keys.map(k=>[k,s[k]??'']));
  const anonymous=s=>hash(keys.filter(k=>!['tenantId','relationId'].includes(k)).map(k=>[k,s[k]??'']));
  function labelled(root,names){
    const wanted=new Set(names.map(clean)),found=[];
    for(const label of [...new Set([...nativeLabels(root),...query(root,'th')])]){
      if(!visible(label)||!wanted.has(clean(text(label))))continue;
      const id=attr(label,'for'),input=id&&doc.getElementById?.(id);
      if(input&&root.contains(input))found.push(text(input));
      const box=localControlBox(label,root);
      if(box&&root.contains(box)){
        const inputs=query(box,'input, textarea, select').filter(visible);
        if(inputs.length===1)found.push(text(inputs[0]));
        const values=query(box,'.ant-form-item-control, .el-form-item__content, .pms-roo-form-pro-control, [data-qnh-value]').filter(visible);
        if(!inputs.length&&values.length===1)found.push(text(values[0]));
      }
      if(label.nextElementSibling&&visible(label.nextElementSibling))found.push(text(label.nextElementSibling));
    }
    return unique(found);
  }
  function tableValue(row,names){
    const table=row.closest?.('table');if(!table)return '';
    const headers=query(table,'thead th, thead td'),cells=[...(row.children||[])].filter(x=>/^(TD|TH)$/.test(x.tagName));
    const wanted=new Set(names.map(clean)),values=[];
    headers.forEach((h,i)=>{if(wanted.has(clean(text(h)))&&cells[i])values.push(text(cells[i]));});
    const found=unique(values);return found.length===1?found[0]:'';
  }
  function nativeColumnDisplay(row){
    // These are display hints inside exact, unambiguous native column headings.
    // They never supply backend SKU / relation identity / scope completeness.
    const table=row.closest?.('table'),cells=[...(row.children||[])].filter(n=>/^(TD|TH)$/.test(n.tagName));
    if(!table||!cells.length)return {};
    const headers=query(table,'thead th, thead td').filter(visible);
    if(headers.length!==cells.length||headers.some(h=>Number(attr(h,'colspan')||1)!==1))return {};
    const column=name=>{
      const indexes=headers.map((h,i)=>clean(text(h))===clean(name)?i:-1).filter(i=>i>=0);
      return indexes.length===1&&visible(cells[indexes[0]])?cells[indexes[0]]:null;
    };
    const backend=column('牵牛花商品信息'),channel=column('渠道商品信息'),supply=column('供应信息');
    const lines=cell=>cell?text(cell).split(/\r?\n/).map(norm).filter(Boolean):[];
    const labelledLine=(cell,names)=>{
      const escaped=names.map(v=>v.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'));
      const pattern=new RegExp('^(?:'+escaped.join('|')+')\\s*[:：]\\s*(.*)$','i'),all=lines(cell),values=[];
      all.forEach((line,i)=>{const m=line.match(pattern);if(m){const value=m[1]||all[i+1]||'';if(value&&!/^[^:：]{1,20}[:：]/.test(value))values.push(value);}});
      const found=unique(values);return found.length===1?found[0]:'';
    };
    const title=cell=>{
      const values=lines(cell).filter(line=>!/^.{1,20}[:：]/.test(line)&&!/^(?:拼多多|pdd|1688|阿里巴巴|编辑|修改|查看|删除|[\d.\s-]+)$/i.test(line));
      return values.length===1?values[0]:'';
    };
    const channelEvidence=lines(channel).concat(query(channel||row,'img[alt], [aria-label]').filter(n=>channel?.contains(n)&&visible(n)).map(n=>attr(n,'alt')||attr(n,'aria-label')));
    const ratio=unique([labelledLine(channel,['下单比例']),labelledLine(supply,['下单比例'])]);
    const constraints=unique(['起订量','起订倍数','下单倍数','箱规','下单方式','采购约束'].map(name=>{
      const value=labelledLine(supply,[name]);return value?name+'：'+value:'';
    })).join('；');
    return {
      backendUpc:labelledLine(backend,['UPC']),
      backendName:labelledLine(backend,['商品名称'])||title(backend),
      backendSpec:labelledLine(backend,['规格']),backendUnit:labelledLine(backend,['采购单位','单位']),
      channelName:labelledLine(channel,['商品名称'])||title(channel),channelSpec:labelledLine(channel,['规格']),
      pddGoodsId:labelledLine(channel,['商品编码','商品ID']),pddSkuId:labelledLine(channel,['规格编码','规格ID','SKU编码']),
      channel:channelEvidence.some(v=>/^(?:采购渠道\s*[:：]\s*)?(?:拼多多|pdd)$/i.test(v))?'pdd':'',
      supplier:labelledLine(supply,['供应商','供应商名称'])||title(supply),ratioRaw:ratio.length===1?ratio[0]:'',constraintsText:constraints
    };
  }
  function field(root,key){
    const marked=unique(query(root,'[data-qnh-field="'+key+'"]').filter(visible).map(text));
    if(marked.length)return marked.length===1?marked[0]:'';
    if(key==='supplier'){
      const selected=selectedSupplierValue(root);
      if(selected.applicable)return selected.value;
    }
    const names=labels[key]||[],found=labelled(root,names);
    if(found.length===1)return found[0];
    const cell=tableValue(root,names);if(cell)return cell;
    // Only explicit field labels, never a bare number or data-row-key.
    const escaped=names.map(v=>v.replace(/[.*+?^{}$()|[\]\\]/g,'\\$&'));
    if(!escaped.length)return '';
    const pattern=new RegExp('^\\s*(?:'+escaped.join('|')+')\\s*[:：]\\s*(.+?)\\s*$','i');
    const hits=unique(String(root.innerText??root.textContent??'').split(/\r?\n/).map(l=>l.match(pattern)?.[1]||''));
    return hits.length===1?hits[0]:'';
  }
  function tenantFrom(root){
    const all=unique([attr(root,'data-qnh-tenant-id'),attr(root,'data-tenant-id'),attr(root,'data-merchant-id'),field(root,'tenantId')]);
    return all.length===1?all[0]:'';
  }
  function pageTenant(){
    // Do not discard a conflicting ancestor in favour of old row/editor IDs.
    const all=unique(query(doc,'[data-qnh-tenant-id], [data-tenant-id], [data-merchant-id]').filter(visible)
      .flatMap(n=>[attr(n,'data-qnh-tenant-id'),attr(n,'data-tenant-id'),attr(n,'data-merchant-id')])
      .concat(query(doc,'[data-qnh-field="tenantId"]').filter(visible).map(text),labelled(doc,labels.tenantId),headerTenantLabels()));
    return all.length===1?all[0]:'';
  }
  function headerTenantLabels(){
    // Explicit tenant labels only, scoped to visible header/top-bar text nodes.
    // Never search the body for arbitrary numbers or table-row IDs.
    const headers=query(doc,'header, [role="banner"], .ant-layout-header, .el-header, [data-qnh-header]').filter(visible);
    const nodes=new Set(headers.flatMap(n=>[n,...query(n,'span, p, div')]));
    for(const n of query(doc,'span').filter(visible)){
      if(n.closest?.('table, [role="dialog"], [data-qnh-editor], .ant-modal-content, .el-dialog'))continue;
      const r=n.getBoundingClientRect?.();
      if(r&&r.top>=0&&r.top<180&&r.bottom<=200&&r.width>0&&r.height>0)nodes.add(n);
    }
    return unique([...nodes].filter(visible).flatMap(n=>{
      const value=text(n);if(value.length>160)return [];
      return [...value.matchAll(/(?:^|[（(]|\s)租户\s*ID\s*[:：]\s*([1-9]\d*)(?=$|[）)]|\s)/gi)].map(m=>m[1]);
    }));
  }
  function urlIds(value){
    try{
      const u=new URL(value);
      if(u.protocol!=='https:'||u.port||u.username||u.password||!/(^|\.)(yangkeduo|pinduoduo)\.com$/i.test(u.hostname))return {valid:false,goodsId:'',skuId:''};
      if(['goods_id','goodsId','sku_id','skuId'].some(k=>u.searchParams.getAll(k).length>1))return {valid:false,goodsId:'',skuId:''};
      const g=u.searchParams.get('goods_id')||u.searchParams.get('goodsId')||'',s=u.searchParams.get('sku_id')||u.searchParams.get('skuId')||'';
      return {valid:true,goodsId:/^\d+$/.test(g)?g:'',skuId:/^\d+$/.test(s)?s:''};
    }catch{return {valid:false,goodsId:'',skuId:''};}
  }
  function normalizedUrl(value){try{const u=new URL(value);u.hash='';u.searchParams.sort();return u.href;}catch{return norm(value);}}
  function scope(root){
    const inc=field(root,'scopeText'),exc=field(root,'excludedScopeText');
    const value=norm(inc+(exc?'；非供货范围：'+exc:''));
    const marked=attr(root,'data-qnh-scope-complete')==='true'||query(root,'[data-qnh-scope-complete="true"]').some(visible);
    // Native counts / "all" labels do not prove inclusion/exclusion semantics.
    return {scopeText:value,scopeComplete:!!value&&marked&&!/…|\.{3}|更多|查看全部|共\s*\d+\s*家/.test(value)};
  }
  function extract(root,tenant=''){
    const s=Object.fromEntries(keys.map(k=>[k,''])),issues=[];
    for(const k of keys)if(!['scopeText','scopeComplete'].includes(k))s[k]=field(root,k);
    const display=nativeColumnDisplay(root);s.readOnlyFallbackFields=[];
    for(const [key,value] of Object.entries(display))if(value&&!s[key]){s[key]=value;s.readOnlyFallbackFields.push(key);}
    s.backendUpc=field(root,'backendUpc')||s.backendUpc||'';
    s.tenantId=tenantFrom(root)||tenant;
    const ids=unique([attr(root,'data-relation-id'),field(root,'relationId')]);
    s.relationId=ids.length===1?ids[0]:'';
    if(ids.length>1)issues.push('关系ID标签与属性冲突');
    s.channel=/拼多多|^pdd$/i.test(s.channel)?'pdd':/1688|阿里巴巴/.test(s.channel)?'1688':'unknown';
    if(!s.oldUrl){
      const links=unique(query(root,'a[href]').filter(visible).map(a=>attr(a,'href')).filter(v=>urlIds(v).valid));
      if(links.length===1)s.oldUrl=links[0];else if(links.length>1)issues.push('多个商品链接，无法唯一定位当前渠道链接');
    }
    const parsed=urlIds(s.oldUrl);
    if(s.pddGoodsId&&parsed.goodsId&&s.pddGoodsId!==parsed.goodsId)issues.push('商品ID与链接goods_id不一致');
    if(s.pddSkuId&&parsed.skuId&&s.pddSkuId!==parsed.skuId)issues.push('规格ID与链接sku_id不一致');
    s.pddGoodsId||=parsed.goodsId;s.pddSkuId||=parsed.skuId;
    Object.assign(s,scope(root));
    if(!s.constraintsText)s.constraintsText=unique(['起订量','起订倍数','混批','箱规','下单方式'].flatMap(l=>labelled(root,[l]).map(v=>l+'：'+v))).join('；');
    if(!s.tenantId)issues.push('无法确认租户/商家身份');
    if(!s.relationId)issues.push('未读取明确网采关系ID，可通过唯一行编辑器继续核对');
    if(!s.scopeComplete)issues.push('未确认完整供货及排除范围，禁止填入修改');
    if(s.readOnlyFallbackFields.some(k=>keys.includes(k)))issues.push('部分字段仅从原生列上下文读取，用于展示，不作为自动填入依据');
    s.identityVerified=!!s.tenantId&&!!s.relationId&&ids.length<=1;
    s.issues=issues;s.rowRef='';s.fingerprint=fingerprint(s);return s;
  }
  function rowNodes(){
    const marked=query(doc,'[data-qnh-relation]').filter(visible);
    const nodes=marked.length?marked:query(doc,'table tbody tr, .ant-table-row, .el-table__row').filter(visible);
    return [...new Set(nodes)].filter(n=>!nodes.some(o=>o!==n&&n.contains(o)));
  }
  function attach(node,s){
    let ref=refs.get(node),b=ref&&bindings.get(ref);
    if(b&&((b.relationId&&s.relationId&&b.relationId!==s.relationId)||b.tenantId!==s.tenantId||(!b.relationId&&b.anonymous!==anonymous(s)))){
      bindings.delete(ref);ref=null;
    }
    if(!ref){ref='qnh-row-'+session+'-'+(++serial);b={node,tenantId:s.tenantId,relationId:s.relationId,anonymous:anonymous(s),recovered:null};refs.set(node,ref);bindings.set(ref,b);}
    if(b.recovered&&!s.relationId&&b.anonymous===anonymous(s)){
      s.relationId=b.recovered.relationId;
      s.identityVerified=!!s.tenantId&&!!s.relationId&&!s.issues.some(x=>x.includes('ID标签与属性冲突'));
      s.issues=s.issues.filter(x=>!x.includes('未读取明确网采关系ID'));
      s.fingerprint=fingerprint(s);
    }
    s.rowRef=ref;return s;
  }
  function checkUnique(s){
    if(!s.relationId)return;
    const matches=rowNodes().filter(n=>{
      const row=extract(n,pageTenant()),b=bindings.get(refs.get(n));
      return (row.relationId||((b?.anonymous===anonymous(row))&&b.recovered?.relationId))===s.relationId&&row.tenantId===s.tenantId;
    });
    if(matches.length!==1)fail('AMBIGUOUS_RELATION','该租户下关系ID不唯一，请重新核对列表');
  }
  function fresh(rowRef){
    const b=bindings.get(rowRef);
    if(!b||b.node.isConnected===false||!doc.documentElement.contains(b.node))fail('ROW_GONE','原列表行已刷新，请重新读取当前页');
    if(!visible(b.node))fail('ROW_NOT_VISIBLE','原列表行不再可见，请重新读取');
    const tenant=pageTenant();if(!tenant||tenant!==b.tenantId)fail('TENANT_CHANGED','租户已变化或无法确认，请重新读取');
    const s=extract(b.node,tenant);
    if((b.relationId&&s.relationId&&s.relationId!==b.relationId)||(!b.relationId&&b.anonymous!==anonymous(s)))fail('ROW_REUSED','列表DOM被复用或未知身份行已改变，请重新读取');
    if(b.recovered&&!s.relationId){s.relationId=b.recovered.relationId;s.issues=s.issues.filter(x=>!x.includes('未读取明确网采关系ID'));}
    if(b.relationId&&!s.relationId)fail('IDENTITY_DISAPPEARED','原关系ID已不可读，请重新读取');
    s.identityVerified=!!s.tenantId&&!!s.relationId&&!s.issues.some(x=>x.includes('ID标签与属性冲突'));
    s.rowRef=rowRef;s.fingerprint=fingerprint(s);checkUnique(s);return s;
  }
  function expect(rowRef,fp){const s=fresh(rowRef);if(!fp||fp!==s.fingerprint)fail('CONFLICT','关系字段已变化或快照过期，请重新审核',{snapshot:s});return s;}
  function editors(){
    const nodes=query(doc,'[data-qnh-editor], [role="dialog"], .ant-modal-content, .el-dialog, .ant-drawer-content').filter(visible);
    return [...new Set(nodes)].filter(n=>!nodes.some(o=>o!==n&&n.contains(o)));
  }
  function linkFields(editor){
    return query(editor,'input, textarea').filter(n=>{
      if(!visible(n)||n.disabled||n.readOnly||/^(password|hidden)$/i.test(n.type))return false;
      if(attr(n,'data-qnh-field')==='oldUrl')return true;
      const names=[...(n.labels||[])].map(text),box=n.closest?.('.ant-form-item, .el-form-item, .pms-roo-form-pro-item, .pms-roo-form-item, .form-group, [data-qnh-item]');
      if(box)names.push(...query(box,'label, .ant-form-item-label, .el-form-item__label').map(text));
      return names.some(v=>labels.oldUrl.map(clean).includes(clean(v)));
    });
  }
  function inspect({refreshNative=false,newSelection=false}={}){
    if(nativeRootCandidates().length)return inspectNative({refresh:refreshNative,newSelection});
    const all=editors();
    if(all.length!==1)fail(all.length?'AMBIGUOUS_EDITOR':'NO_EDITOR',all.length?'存在多个可见编辑器':'未找到可见原生编辑器');
    const node=all[0];
    if(!active){
      const e=extract(node,pageTenant()),candidates=[...bindings.keys()].filter(ref=>{try{const s=fresh(ref);return e.identityVerified&&s.relationId===e.relationId&&s.tenantId===e.tenantId;}catch{return false;}});
      if(candidates.length!==1)fail('UNBOUND_EDITOR','无法唯一绑定此编辑器，请从列表行重新打开');
      active={rowRef:candidates[0],node,initial:null,rowGuard:null};
    }
    if(active.node&&active.node!==node)fail('EDITOR_REPLACED','原编辑器已替换，请重新打开目标关系');
    const row=fresh(active.rowRef),e=extract(node,pageTenant());
    if(active.rowGuard&&active.rowGuard!==anonymous(row))fail('CONFLICT','编辑期间列表关系已变化，请关闭后重新审核',{snapshot:row});
    if(!e.tenantId||e.tenantId!==row.tenantId||!e.relationId||(row.relationId&&e.relationId!==row.relationId))fail('EDITOR_IDENTITY_MISMATCH','编辑器未明确显示同租户目标关系ID，禁止填入');
    if(!row.relationId){bindings.get(active.rowRef).recovered={relationId:e.relationId};row.relationId=e.relationId;}
    if(active.initial){
      for(const k of invariants)if(e[k]&&e[k]!=='unknown'&&active.initial[k]&&e[k]!==active.initial[k])fail('EDITOR_DIRTY','编辑器保持字段已被改动，请重新审核',{field:k});
    }
    const s={...row},source=active.initial||e;
    for(const k of keys)if(!s[k]&&source[k])s[k]=source[k];
    if(!row.scopeComplete&&source.scopeComplete){s.scopeText=source.scopeText;s.scopeComplete=true;}
    s.issues=unique(row.issues.filter(x=>!x.includes('明确网采关系ID')&&!(s.scopeComplete&&x.includes('完整供货'))).concat(e.issues.filter(x=>/不一致|冲突/.test(x))));
    s.identityVerified=!!s.relationId&&!!s.tenantId&&!s.issues.some(x=>x.includes('关系ID标签与属性冲突'));
    s.readOnlyFallbackFields=unique([...(row.readOnlyFallbackFields||[]),...(e.readOnlyFallbackFields||[])]);
    s.fingerprint=fingerprint(s);
    if(!active.initial){active.initial={...s};active.rowGuard=anonymous(row);}
    const fields=linkFields(node),canFill=s.identityVerified&&s.scopeComplete&&s.channel==='pdd'&&!!s.backendSku&&!!s.supplier&&fields.length===1&&!s.readOnlyFallbackFields.some(k=>keys.includes(k))&&!s.issues.some(x=>/不一致|冲突/.test(x));
    return {snapshot:s,editor:{visible:true,relationId:e.relationId,tenantId:e.tenantId,uniqueLinkField:fields.length===1,linkFieldCount:fields.length,currentUrl:fields.length===1?text(fields[0]):'',canFill,warnings:canFill?[]:['需同租户关系ID、完整范围、后台SKU、供应商、拼多多渠道及唯一链接字段']}};
  }
  async function openEditor({rowRef,expectedFingerprint}){
    const s=expect(rowRef,expectedFingerprint);
    if(editors().length)fail('EDITOR_ALREADY_OPEN','已有可见编辑器，请先关闭或检查当前编辑器');
    const node=bindings.get(rowRef).node,explicit=query(node,'[data-qnh-action="edit"]').filter(visible);
    const buttons=explicit.length?explicit:query(node,'button, a, [role="button"]').filter(n=>visible(n)&&/^(编辑|修改)$/.test(clean(text(n))));
    if(buttons.length!==1)fail('AMBIGUOUS_EDIT_BUTTON','无法唯一确定此行编辑按钮');
    active={rowRef,node:null,initial:null,rowGuard:null,origin:s};nativeActive=null;buttons[0].click();
    const deadline=Date.now()+1800;
    while(!editors().length&&!nativeRootCandidates().length&&Date.now()<deadline)await new Promise(r=>setTimeout(r,50));
    if(!editors().length&&!nativeRootCandidates().length){active=null;fail('EDITOR_NOT_OPENED','点击后未找到编辑器，请检查原页面');}
    active.node=editors()[0]||nativeRootCandidates()[0];const result=inspect();
    if(s.relationId&&result.snapshot.relationId!==s.relationId)fail('EDITOR_IDENTITY_MISMATCH','编辑器不是目标关系');
    return result;
  }
  function setValue(n,value){
    const proto=n.tagName==='TEXTAREA'?globalThis.HTMLTextAreaElement?.prototype:globalThis.HTMLInputElement?.prototype;
    const setter=proto&&Object.getOwnPropertyDescriptor(proto,'value')?.set;
    if(setter)setter.call(n,value);else n.value=value;
    n.dispatchEvent(new Event('input',{bubbles:true}));n.dispatchEvent(new Event('change',{bubbles:true}));
  }
  function fill({rowRef,expectedFingerprint,url}){
    if(!active||active.rowRef!==rowRef)fail('UNBOUND_EDITOR','请先从此关系打开并核对编辑器');
    const result=inspect(),s=result.snapshot;
    if(expectedFingerprint!==s.fingerprint)fail('CONFLICT','快照已变化，请重新审核',{snapshot:s});
    if(!result.editor.canFill)fail('UNSAFE_EDITOR','身份、范围或唯一链接字段未确认，禁止填入',result.editor);
    if(!urlIds(url).valid)fail('INVALID_URL','仅接受HTTPS拼多多商品或结算链接');
    const input=linkFields(editors()[0])[0],before=text(input);
    if(before&&before!==active.initial.oldUrl&&before!==active.lastFilled)fail('EDITOR_DIRTY','原生链接框已被人工修改，请重新审核');
    setValue(input,norm(url));if(text(input)!==norm(url))fail('FILL_REJECTED','原生输入框未接受新值');
    active.lastFilled=norm(url);
    return {filled:true,fields:[{field:'oldUrl',label:'已确认的商品/结算链接',before,after:norm(url)}],snapshot:s};
  }
  function verify({rowRef,expected={},beforeSnapshot}){
    let s;
    try { s=fresh(rowRef); }
    catch(error) {
      // Native Save may replace tbody entirely. Rebind only for verification,
      // using a previously verified tenant + relation ID, never same-SKU text.
      if(!['ROW_GONE','ROW_NOT_VISIBLE'].includes(error.code)||!beforeSnapshot?.identityVerified||!beforeSnapshot.relationId||pageTenant()!==beforeSnapshot.tenantId)throw error;
      const matches=rowNodes().map(node=>({node,snapshot:extract(node,pageTenant())})).filter(x=>x.snapshot.identityVerified&&x.snapshot.relationId===beforeSnapshot.relationId&&x.snapshot.tenantId===beforeSnapshot.tenantId);
      if(matches.length!==1)return {status:'unknown',snapshot:null,details:['保存后无法按租户及明确关系ID唯一回读，不能按SKU代替定位']};
      s=attach(matches[0].node,matches[0].snapshot);
    }
    const details=[];
    if(!beforeSnapshot?.identityVerified||!s.identityVerified||!s.scopeComplete||!beforeSnapshot.scopeComplete)return {status:'unknown',snapshot:s,details:['缺少可验证身份或完整范围快照']};
    if(s.tenantId!==beforeSnapshot.tenantId||s.relationId!==beforeSnapshot.relationId)return {status:'mismatch',snapshot:s,details:['租户或关系ID不一致']};
    for(const k of invariants)if(norm(s[k])!==norm(beforeSnapshot[k]))details.push('保持字段变化：'+k);
    const g=norm(expected.goodsId),sku=norm(expected.skuId);
    if(!g||!sku||!s.pddGoodsId||!s.pddSkuId||!s.oldUrl)return {status:'unknown',snapshot:s,details:details.concat('商品ID、SKU ID或实际链接不完整，不能仅凭goods_id确认')};
    if(s.pddGoodsId!==g)details.push('商品ID不匹配');
    if(s.pddSkuId!==sku)details.push('SKU ID不匹配');
    if(!expected.url)return {status:'unknown',snapshot:s,details:details.concat('缺少预期链接')};
    if(normalizedUrl(s.oldUrl)!==normalizedUrl(expected.url))details.push('链接不匹配');
    if(s.issues.some(x=>/不一致|冲突/.test(x)))details.push('页面身份字段互相矛盾');
    return {status:details.length?'mismatch':'verified',snapshot:s,details:details.length?details:['同关系商品、SKU、链接及保持字段回读一致']};
  }
  // v0.2: exact labelled native business form, including the full-page editor.
  const referenceChannelPlaceholders={channelName:'请填写其他采购平台商品名称',url:'请填写其他采购平台商品结算链接',channelCode:'请填写其他采购平台商品编码',channelSpec:'请填写其他采购平台规格名称'};
  const nativeNames={channelName:['渠道商品名称','名称'],url:['结算链接','渠道商品链接','链接'],channelCode:['编码','渠道商品编码'],channelSpec:['规格','渠道商品规格'],ratioPdd:['拼多多比例'],ratioQnh:['牵牛花比例'],purchasePrice:['采购价','采购价格']};
  const maintenanceKeys=['channelName','url','channelSpec','ratioPdd','ratioQnh','purchasePrice'];
  let nativeActive=null;
  const filledNativeNodes=new WeakSet();
  function nativeRouteInfo(){
    try{
      const u=new URL(globalThis.location.href),[path,search='']=u.hash.slice(1).split('?');
      if(u.origin==='https://qnh.meituan.com'&&['/home.html','/'].includes(u.pathname)&&path==='/purchase/replenishment/refer')return {isNativeRoute:true,isReferenceRoute:true,routeMode:'edit',relationId:'',invalidRelationId:false};
      if(u.origin!=='https://qnh.meituan.com'||u.pathname!=='/home.html'||path!=='/pms/online-purchase-center/add-purchase-relation')return {isNativeRoute:false,routeMode:'unknown',relationId:'',invalidRelationId:false};
      const values=new URLSearchParams(search).getAll('relationId'),relationId=values.length===1&&/^[1-9]\d*$/.test(values[0])?values[0]:'';
      const isNew=values.length===0||(values.length===1&&values[0]==='');
      return {isNativeRoute:true,routeMode:isNew?'new':'edit',relationId,invalidRelationId:!isNew&&!relationId};
    }catch{return {isNativeRoute:false,routeMode:'unknown',relationId:'',invalidRelationId:false};}
  }
  function routeRelationId(){return nativeRouteInfo().relationId;}
  const semanticLabelSelector='label, h1, h2, h3, h4, legend, [role="heading"], .ant-form-item-label, .el-form-item__label, .pms-roo-form-pro-item-label, .pms-roo-form-item-label, dt';
  const nativeLabelSelector=semanticLabelSelector+', span, div';
  const isSemanticLabel=node=>node.matches(semanticLabelSelector);
  function nativeLabels(root){
    return query(root,nativeLabelSelector).filter(n=>visible(n)&&(isSemanticLabel(n)||(!n.children?.length&&text(n).length<=24)));
  }
  function localControlBox(label,root,allowed=1){
    const known=label.closest?.('.ant-form-item, .el-form-item, .pms-roo-form-pro-item, .pms-roo-form-item, .form-group, [data-qnh-item]');
    if(known&&root.contains(known)){const controls=query(known,'input, textarea, select').filter(visible);if(controls.length<=allowed)return known;}
    for(let box=label.parentElement,depth=0;box&&root.contains(box)&&depth<5;box=box.parentElement,depth++){
      const controls=query(box,'input, textarea, select').filter(visible);
      if(controls.length)return controls.length<=allowed?box:null;
      if(box===root)break;
    }
    return null;
  }
  function inputsFor(root,key){
    const explicit=query(root,'input, textarea, select').filter(n=>visible(n)&&attr(n,'data-qnh-field')===key);
    if(explicit.length)return explicit;
    const wanted=new Set((nativeNames[key]||[]).map(clean)),nodes=[];
    for(const label of nativeLabels(root)){
      if(!visible(label)||!wanted.has(clean(text(label))))continue;
      const byId=attr(label,'for')&&doc.getElementById?.(attr(label,'for'));
      if(byId&&root.contains(byId)&&visible(byId))nodes.push(byId);
      const box=localControlBox(label,root);
      if(box&&root.contains(box)){const values=query(box,'input, textarea, select').filter(visible);if(values.length===1)nodes.push(values[0]);}
    }
    if(!nodes.length&&['ratioPdd','ratioQnh'].includes(key))for(const label of nativeLabels(root)){
      if(!visible(label)||clean(text(label))!=='下单比例')continue;
      const box=localControlBox(label,root,2);
      const values=query(box||label.parentElement,'input').filter(n=>visible(n)&&!n.disabled&&!n.readOnly);
      if(values.length===2)nodes.push(values[key==='ratioPdd'?0:1]);
    }
    // Empty channel fields can use an icon beside the caption; the exact
    // native placeholder is also a field identifier inside the verified page.
    if(!nodes.length&&nativeRouteInfo().isReferenceRoute){
      const placeholder=referenceChannelPlaceholders[key];
      if(placeholder)nodes.push(...query(root,'input[placeholder]').filter(n=>visible(n)&&attr(n,'placeholder')===placeholder));
    }
    return [...new Set(nodes)];
  }
  function nativeNodes(root){return Object.fromEntries([...maintenanceKeys,'channelCode'].map(k=>[k,inputsFor(root,k)]));}
  function referenceProductLabels(){
    // Filter by text before asking the browser for visibility or rendered text.
    return query(doc,nativeLabelSelector).filter(n=>(!n.children.length||isSemanticLabel(n))&&clean(n.textContent).includes('牵牛花商品名称'));
  }
  function referenceEditorRoots(labels){
    return observeDom(()=>{
      const candidates=(labels||referenceProductLabels()).filter(n=>visible(n)&&clean(text(n))==='牵牛花商品名称');
      const anchors=candidates.filter(n=>!candidates.some(inner=>inner!==n&&n.contains(inner)));
      const roots=new Set(),editorContainers='[data-qnh-editor], [role="dialog"], .ant-drawer-content, .pms-roo-drawer-content, .el-drawer';
      for(const anchor of anchors){
        for(let node=anchor.parentElement;node&&node!==doc.body&&node!==doc.documentElement;node=node.parentElement){
          if(anchors.some(other=>other!==anchor&&node.contains(other)))break;
          const names=new Set(nativeLabels(node).map(n=>clean(text(n))));
          const essentials=['牵牛花商品名称','采购渠道','下单比例','供应商','采购价'];
          if(!essentials.every(name=>names.has(name)))continue;
          const sections=names.has('关联信息')&&names.has('供应信息');
          if(!sections&&!node.matches(editorContainers))continue;
          roots.add(node);break;
        }
      }
      const all=[...roots];
      return all.filter(n=>!all.some(o=>o!==n&&n.contains(o)));
    });
  }
  function nativeRootCandidates(){
    if(nativeRouteInfo().isReferenceRoute)return referenceEditorRoots();
    const dialogs=query(doc,'[data-qnh-editor], [role="dialog"], .ant-modal-content, .el-dialog, .ant-drawer-content, .pms-roo-drawer-content, .pms-roo-modal-content').filter(visible);
    const forms=query(doc,'form, [role="form"], .ant-form, .el-form, .pms-roo-form-pro, .pms-roo-form, [data-qnh-native-editor]').filter(visible);
    const route=nativeRouteInfo();
    if(route.isNativeRoute&&!route.isReferenceRoute){const roots=query(doc,'main, [role="tabpanel"], .ant-tabs-tabpane-active').filter(visible);forms.push(...roots,...query(doc,'body').filter(visible));}
    const all=[...new Set([...dialogs,...forms])].filter(n=>{const fields=nativeNodes(n);return maintenanceKeys.every(k=>fields[k].length>0);});
    return all.filter(n=>!all.some(o=>o!==n&&n.contains(o)));
  }
  function nativeValues(nodes){return Object.fromEntries([...maintenanceKeys,'channelCode'].map(k=>[k,nodes[k].length===1?text(nodes[k][0]):'']));}
  function protectedControlNodes(root){
    const native=nativeNodes(root),targetNodes=new Set(Object.values(native).flat());
    return query(root,'input, textarea, select').filter(n=>visible(n)&&!targetNodes.has(n)&&!/^(hidden|password|file)$/i.test(n.type||attr(n,'type')));
  }
  function protectedValues(root){
    // Only labelled business values; never enumerate storage or authentication fields.
    const names=['供应商','供应商名称','采购渠道','牵牛花商品名称','牵牛花商品编码','供货范围','非供货范围','门店','中心仓','箱规','箱规单位','起订量','起订倍数','下单倍数','下单方式','留言','下单留言','采购留言'];
    const businessValues=names.map(label=>[label,labelled(root,[label])]).concat(['backendSku','backendUpc','backendName','backendSpec','backendUnit','supplier','channel','scopeText','excludedScopeText','constraintsText'].map(key=>[key,field(root,key)]));
    // Preserve visible non-target business controls, including checked state.
    // Never enumerate hidden fields, password fields, cookies or storage.
    const controls=protectedControlNodes(root).map((n,index)=>['business-control',index,attr(n,'name'),attr(n,'id'),attr(n,'aria-label'),text(n),!!n.checked,n.disabled===true]);
    return businessValues.concat(controls);
  }
  function labelledBusinessInputs(root,forName,names){
    const found=[],wanted=new Set(names.map(clean));
    const input=n=>n?.tagName==='INPUT'&&!/^(hidden|password|file|checkbox|radio)$/i.test(n.type||attr(n,'type'));
    for(const label of nativeLabels(root)){
      if(!visible(label)||(!wanted.has(clean(text(label)))&&attr(label,'for')!==forName))continue;
      const byId=attr(label,'for')&&doc.getElementById?.(attr(label,'for'));
      if(input(byId)&&root.contains(byId)&&visible(byId))found.push(byId);
      const box=localControlBox(label,root);
      if(box){const controls=query(box,'input, textarea, select').filter(visible);if(controls.length===1&&input(controls[0]))found.push(controls[0]);}
    }
    const item=completionFieldItem(root,forName,names);
    if(item){const controls=query(item,'input, textarea, select').filter(visible);if(controls.length===1&&input(controls[0]))found.push(controls[0]);}
    return [...new Set(found)];
  }
  function recoveryInputs(root){return {minimum:labelledBusinessInputs(root,'orderMinimum',['起订量']),multiple:labelledBusinessInputs(root,'orderMultiple',['起订倍数','下单倍数'])};}
  function minimumQuantityControls(root){return recoveryInputs(root).minimum;}
  function recoveryControlRoles(root){
    const controls=protectedControlNodes(root),parts=recoveryInputs(root),roles=[];
    for(const [key,role]of [['minimum','orderMinimum'],['multiple','orderMultiple']]){
      const found=parts[key];if(found.length!==1||parts[key==='minimum'?'multiple':'minimum'].includes(found[0]))continue;
      const index=controls.indexOf(found[0]);if(index>=0)roles.push({index,role});
    }
    return roles;
  }
  function protectedChangeDetails(root,before,after,beforeControls){
    const afterControls=protectedControlNodes(root),changed=[];
    const controlValue=row=>row?{value:row[5],checked:row[6],disabled:row[7],name:row[2],id:row[3],ariaLabel:row[4]}:null;
    for(let index=0;index<Math.max(before.length,after.length);index++){
      const a=before[index],b=after[index];if(JSON.stringify(a)===JSON.stringify(b))continue;
      const row=a||b,isControl=row?.[0]==='business-control',key=isControl?'business-control:'+row[1]:row?.[0]||'保持字段结构';let label=key;
      if(isControl){const control=beforeControls[row[1]]||afterControls[row[1]],item=control?.closest?.('.pms-roo-form-pro-item, .ant-form-item, .el-form-item, [data-qnh-item]');label=(item&&nativeLabels(item).map(text).find(v=>v.length<30))||attr(control,'aria-label')||attr(control,'name')||attr(control,'id')||key;}
      changed.push({key,label,before:isControl?controlValue(a):a?.[1],after:isControl?controlValue(b):b?.[1]});
    }
    return {changedKeys:[...new Set(changed.map(row=>row.key))],protectedField:changed[0]||{label:'保持字段结构',before,after}};
  }
  function staticBusinessText(node){
    if(!visible(node)||/^(INPUT|TEXTAREA|SELECT|BUTTON|SCRIPT|STYLE)$/.test(node.tagName))return '';
    // Read rendered text, never the value of an editable product/search input.
    if(!node.children?.length)return text(node);
    return norm([...node.childNodes||[]].filter(n=>n.nodeType===3).map(n=>n.textContent).join(' ')+'\n'+[...node.children].map(staticBusinessText).filter(Boolean).join('\n'));
  }
  const normalizeSupplierDisplay=value=>norm(value).replace(/\s+/g,' ').replace(/[\uE000-\uF8FF]/g,'').trim()
      .replace(/^(?:拼|1688|闪电帮帮)\s+/,'').replace(/\s*[（(]\s*\d+(?:\.\d+)?\s*天\s*[）)]\s*$/,'').trim();
  function selectedSupplierValue(root){
    const item=supplierField(root);
    if(!item)return {applicable:false,value:''};
    const menu='[role="option"], [role="listbox"], .pms-ant-select-dropdown, .ant-select-dropdown, .pms-roo-select-dropdown';
    const inField=node=>visible(node)&&!node.closest?.(menu);
    const widgets=query(item,'.pms-roo-select, .pms-ant-select, .ant-select').filter(inField);
    const outerWidgets=widgets.filter(node=>!widgets.some(parent=>parent!==node&&parent.contains(node)));
    const combos=query(item,'[role="combobox"], select').filter(inField);
    const controls=combos.filter(node=>!combos.some(child=>child!==node&&node.contains(child)));
    if(outerWidgets.length>1||controls.length>1)return {applicable:true,value:''};
    const input=controls[0];
    const finish=values=>{const names=unique(values.map(normalizeSupplierDisplay).filter(value=>value&&!/^(?:请选择|请输入|搜索|暂无|未选择|无选项)/.test(value)));return {applicable:true,value:names.length===1?names[0]:''};};
    if(input?.tagName==='SELECT')return finish([...(input.selectedOptions||[])].map(text));
    // A selected label can be rendered while the search input is hidden or absent.
    // Read only the current labelled field and exclude open option menus.
    function displayText(node){
      if(!inField(node)||/^(INPUT|TEXTAREA|SELECT|BUTTON|SCRIPT|STYLE|TEMPLATE)$/.test(node.tagName)||
         /(?:^|\s)(?:pms-ant-select|ant-select)-(?:dropdown|item-option|selection-placeholder)(?:\s|$|-)/.test(attr(node,'class')))return '';
      return norm([...node.childNodes||[]].map(child=>child.nodeType===3?child.textContent:displayText(child)).filter(Boolean).join('\n'));
    }
    const selections=query(item,'.pms-ant-select-selection-item, .ant-select-selection-item, .pms-roo-select-value').filter(inField);
    if(selections.length)return finish(selections.map(displayText));
    if(outerWidgets.length===1)return finish([displayText(outerWidgets[0])]);
    if(!input)return {applicable:false,value:''};
    const boxes=query(item,'.pms-roo-form-pro-control, .ant-form-item-control, .el-form-item__content, [data-qnh-value]').filter(n=>visible(n)&&n.contains(input));
    const boxesInside=boxes.filter(n=>!boxes.some(other=>other!==n&&n.contains(other)));
    const box=boxesInside.length===1?boxesInside[0]:input.closest?.('.pms-roo-select, .pms-ant-select, .ant-select');
    return box&&item.contains(box)?finish([displayText(box)]):{applicable:true,value:''};
  }
  function namedBusinessRegions(root,names){
    const wanted=new Set(names.map(clean)),regions=[];
    for(const label of nativeLabels(root)){
      if(!wanted.has(clean(text(label))))continue;
      const known=label.closest?.('.ant-form-item, .el-form-item, .pms-roo-form-pro-item, .pms-roo-form-item, .form-group, [data-qnh-item]');
      if(known&&root.contains(known)){regions.push(known);continue;}
      // A generic row/card wrapper is allowed; the whole form/body is not.
      for(let box=label.parentElement,depth=0;box&&root.contains(box)&&depth<5;box=box.parentElement,depth++){
        if(box===root||/^(FORM|BODY|MAIN)$/.test(box.tagName))break;
        if(maintenanceKeys.some(key=>inputsFor(box,key).length))break;
        const staticText=staticBusinessText(box);
        if(/UPC\s*[:：]?\s*\d{8,20}(?!\d)/i.test(staticText)||query(box,'input[type="radio"], .ant-radio-wrapper, .pms-ant-radio-wrapper, .pms-roo-radio, [role="radio"]').length){regions.push(box);break;}
      }
    }
    return [...new Set(regions)];
  }
  function productRegionBoundary(node){
    const names=new Set(['采购渠道','渠道商品','渠道商品信息','供应信息','供货信息','供货范围','非供货范围','供应商','供应商名称','箱规','起订量','起订倍数','下单倍数','下单方式',...Object.values(nativeNames).flat()].map(clean));
    if(nativeLabels(node).some(label=>names.has(clean(text(label)))))return true;
    if(names.has(clean(text(node))))return true;
    return query(node,'input, textarea, select').some(n=>visible(n)&&!n.disabled&&!n.readOnly);
  }
  function selectedProductRegions(root){
    const anchored=namedBusinessRegions(root,labels.backendName),regions=[...anchored];
    for(const anchor of anchored){
      // Prefer an in-field card. Adjacent rendering is only a bounded fallback
      // for the selected-product component below this exact business field.
      if(/UPC\s*[:：]?\s*\d{8,20}(?!\d)/i.test(staticBusinessText(anchor)))continue;
      let start=anchor;
      for(let depth=0;depth<2&&start&&root.contains(start);depth++,start=start.parentElement){
        if(start!==anchor&&(/^(FORM|BODY|MAIN)$/.test(start.tagName)||start===root))break;
        let inspected=0;
        for(let next=start.nextElementSibling;next&&root.contains(next)&&inspected<3;next=next.nextElementSibling,inspected++){
          if(!visible(next))continue;
          if(/^(FORM|BODY|MAIN)$/.test(next.tagName)||productRegionBoundary(next))break;
          const value=staticBusinessText(next);
          if(/UPC\s*[:：]?\s*\d{8,20}(?!\d)/i.test(value)){regions.push(next);break;}
          // Skip only empty layout blocks or an explicit selected-product
          // caption, never unrelated content on the way to a later UPC.
          if(value&&!/^(已选商品|已关联商品|当前商品)[:：]?$/.test(value))break;
        }
        if(start.nextElementSibling)break;
      }
    }
    return [...new Set(regions)];
  }
  function selectedProductCards(root){
    const cards=[];
    for(const region of selectedProductRegions(root)){
      const cardText=staticBusinessText(region),upcs=unique([...cardText.matchAll(/(?:^|\b)UPC\s*[:：]?\s*(\d{8,20})(?!\d)/gi)].map(m=>m[1]));
      if(!upcs.length)continue;
      const names=unique(cardText.split(/\r?\n/).map(norm).filter(line=>line&&!/^(?:牵牛花商品名称|UPC\s*[:：]?|\d{8,20}|请选择.*|搜索|查询|删除|更换|移除|预览|查看图片)$/i.test(line)&&!/^(?:UPC\b|规格\s*[:：]|类目\s*[:：])/i.test(line)));
      // The exact product field plus a static UPC and product name/image binds
      // this card. Similar UPC text elsewhere in the body is never searched.
      if(!names.length&&!query(region,'img').some(visible))continue;
      const spec=cardText.match(/(?:^|\n)(?:规格|后台规格|牵牛花规格)\s*[:：]\s*([^\n]+)/)?.[1]||'';
      cards.push({kind:'associated_product_card',upcs,name:names[0]||'',spec,text:cardText});
    }
    return cards;
  }
  function readableRadioWrapper(wrapper){
    // Current form options remain evidence when normal document scrolling
    // moves them above/below the viewport. Hidden/aria-hidden/display:none
    // ancestors are still excluded by visible(); coordinates are not identity.
    return visible(wrapper);
  }
  function procurementEvidence(root){
    const regions=namedBusinessRegions(root,labels.channel),native='input[type="radio"]',
      optionSelector='.ant-radio-wrapper, .pms-ant-radio-wrapper, .pms-roo-radio, [role="radio"]';
    const wrappers=[...new Set(regions.flatMap(region=>[region,...query(region,optionSelector+', label')]))].filter(readableRadioWrapper);
    const options=wrappers.filter(wrapper=>!query(wrapper,optionSelector).some(readableRadioWrapper)&&
      (wrapper.matches(optionSelector)||query(wrapper,native).length===1));
    const hasRadioGroup=regions.some(region=>region.matches(optionSelector)||query(region,native+', '+optionSelector).length);
    if(options.length||hasRadioGroup){
      const captions=['其他采购平台','其他平台','拼多多','pdd','闪电帮帮采购平台','闪电帮帮','1688采购平台','1688'];
      const labelOf=wrapper=>{
        const nameById=attr(wrapper,'aria-labelledby').split(/\s+/).map(id=>doc.getElementById(id)).filter(n=>n&&root.contains(n)).map(text);
        const named=[attr(wrapper,'aria-label'),attr(wrapper,'title'),...nameById,staticBusinessText(wrapper),...query(wrapper,'span').filter(visible).map(staticBusinessText)];
        return captions.find(caption=>named.some(name=>clean(name)===caption))||norm(staticBusinessText(wrapper));
      };
      const observed=options.map(wrapper=>{
        // The visible radio label may contain a hidden native input or show a
        // checked marker in a differently styled element.
        const radios=query(wrapper,native);
        const classes=[wrapper,...query(wrapper,'[class]')].flatMap(n=>attr(n,'class').split(/\s+/));
        const marked=attr(wrapper,'aria-checked')==='true'||classes.some(c=>/^(?:(?:pms-)?ant-radio(?:-wrapper)?|pms-roo-radio(?:-wrapper|-(?:icon|inner|indicator))?)-checked$/.test(c));
        return {text:labelOf(wrapper),checked:radios.some(n=>n.checked===true),marked,hasInput:radios.length>0,conflict:radios.length>1};
      });
      const nativeSelection=observed.some(o=>o.checked);
      const choices=observed.filter(o=>nativeSelection?o.checked:o.marked&&!o.hasInput),selected=unique(choices.map(o=>o.text));
      const conflict=observed.some(o=>o.conflict)||selected.length>1;
      return {kind:'checked_radio',selected:conflict?[]:selected,hasSelection:choices.length>0,conflict,options:observed};
    }
    const values=[field(root,'channel')];
    for(const region of regions)for(const select of query(region,'select').filter(visible))values.push(...[...(select.selectedOptions||[])].map(text));
    return {kind:'labelled_value',selected:unique(values),conflict:false};
  }

  function productUpcs(root,name){
    const values=[...String(name||'').matchAll(/(?:UPC\s*[:：]?\s*|\b)(\d{8,20})(?=\b|\D|$)/gi)].map(m=>m[1]);
    // A standalone editable UPC search box is a query, even if a full-page
    // fallback root contains it. It must never establish a selected product.
    for(const n of query(root,'[data-qnh-field="backendUpc"]').filter(visible)){
      if(n.getAttribute?.('data-qnh-search-upc')!==null)continue;
      if(!/^(INPUT|TEXTAREA|SELECT)$/.test(n.tagName)||n.disabled||n.readOnly)values.push(text(n));
    }
    const wanted=new Set(labels.backendUpc.map(clean)),productRegions=selectedProductRegions(root);
    for(const label of nativeLabels(root)){
      if(!wanted.has(clean(text(label)))||!productRegions.some(region=>region.contains(label)))continue;
      const box=localControlBox(label,root),controls=query(box||label.parentElement,'input, textarea, select').filter(visible);
      if(controls.length){if(controls.length===1&&(controls[0].disabled||controls[0].readOnly))values.push(text(controls[0]));}
      else if(label.nextElementSibling&&visible(label.nextElementSibling))values.push(text(label.nextElementSibling));
    }
    return unique(values).filter(v=>/^\d{8,20}$/.test(v));
  }
  function nativeSnapshot(node,origin=null){
    const nodes=nativeNodes(node),values=nativeValues(nodes),raw=extract(node,pageTenant());
    const route=nativeRouteInfo(),routed=route.relationId,explicit=raw.relationId;
    let routeKey='';try{const u=new URL(globalThis.location.href);routeKey=u.origin+u.pathname+u.hash.split('?')[0];}catch{/* Unknown route cannot be rebound. */}
    if(route.routeMode==='new')origin=null;
    if(explicit&&routed&&explicit!==routed)fail('EDITOR_IDENTITY_MISMATCH','编辑页路由与表单关系ID冲突');
    const tenant=pageTenant();if(origin?.tenantId&&tenant!==origin.tenantId)fail('TENANT_CHANGED','编辑页租户与打开时不一致');
    const relationId=route.routeMode==='new'?'':(explicit||routed||'');
    if(origin?.relationId&&relationId&&origin.relationId!==relationId)fail('EDITOR_IDENTITY_MISMATCH','当前编辑页不是原网采关系');
    const cards=selectedProductCards(node),name=(/^(?:预览|查看图片)$/.test(norm(raw.backendName))?'':raw.backendName)||origin?.backendName||cards.find(card=>card.name)?.name||'';
    const upcs=unique([...productUpcs(node,name),...cards.flatMap(card=>card.upcs)]);
    let backendUpc=upcs.length===1?upcs[0]:(origin?.backendUpc||''),backendUpcSource=upcs.length===1?'native_product':origin?.backendUpc?'clicked_row':'';
    if(!backendUpc){const pageUpcs=unique([...labelled(doc,labels.backendUpc),...query(doc,'[data-qnh-search-upc]').filter(visible).map(text)]).filter(v=>/^\d{8,14}$/.test(v));if(pageUpcs.length===1){backendUpc=pageUpcs[0];backendUpcSource='page_query_only';}}
    if(origin?.backendUpc&&backendUpc&&origin.backendUpc!==backendUpc)fail('EDITOR_IDENTITY_MISMATCH','编辑页UPC与原列表关系不同');
    const supplier=raw.supplier||origin?.supplier||'';
    if(origin?.supplier&&raw.supplier&&origin.supplier!==raw.supplier)fail('EDITOR_IDENTITY_MISMATCH','编辑页供应商与原列表关系不同');
    const procurement=procurementEvidence(node);
    // A rendered, unique set of exact native placeholders is evidence for
    // the Other platform form, but never overrides an explicit radio choice.
    const renderedOther=route.isReferenceRoute&&!procurement.selected.length&&!procurement.hasSelection&&!procurement.conflict&&
      Object.entries(referenceChannelPlaceholders).every(([key,placeholder])=>nodes[key].length===1&&attr(nodes[key][0],'placeholder')===placeholder);
    const procurementChannelText=procurement.selected.join(' / ')||(renderedOther?'其他采购平台':'');
    const newChannelSupported=!procurement.conflict&&/^(?:其他采购平台|其他平台|拼多多|pdd)$/i.test(clean(procurementChannelText));
    const sourceEvidence={product:{name,upcs,source:backendUpcSource,cards},procurement},evidenceFingerprint=hash(sourceEvidence);
    const p=urlIds(values.url),selectedPdd=procurement.kind==='checked_radio'?procurement.selected.some(v=>/^(拼多多|pdd)$/i.test(clean(v))):raw.channel==='pdd',channel=p.valid||/拼多多/i.test(supplier)||selectedPdd?'pdd':raw.channel;
    const procurementAllowed=procurement.kind==='checked_radio'?newChannelSupported:(newChannelSupported||channel==='pdd');
    const routeMode=route.isNativeRoute?route.routeMode:(relationId||origin?.rowRef?'edit':'unknown');
    const s={...(origin||{}),...raw,tenantId:tenant,relationId,routeMode,backendName:name,backendSpec:raw.backendSpec||origin?.backendSpec||cards.find(card=>card.spec)?.spec||'',backendUpc,backendUpcSource,supplier,channel,procurementChannelText,
      backendSku:raw.backendSku||origin?.backendSku||'',oldUrl:values.url,pddGoodsId:p.goodsId,pddSkuId:p.skuId,channelSpec:values.channelSpec,
      nativeFields:values,ratioRaw:values.ratioPdd+' = '+values.ratioQnh,identityVerified:!!tenant&&!!relationId};
    const protectedFields=protectedValues(node),protectionFingerprint=hash(protectedFields);
    const fieldsComplete=maintenanceKeys.every(k=>nodes[k].length===1&&!nodes[k][0].disabled&&!nodes[k][0].readOnly&&!/password|hidden/i.test(nodes[k][0].type||''));
    // The replenishment drawer has no relation ID in its URL. Bind only the
    // single visible editor and its own selected product. Blank channel drafts
    // additionally require an explicitly selected supported platform.
    // The underlying reference table and its UPC query cannot supply identity.
    const referenceProductVerified=backendUpcSource==='native_product'&&upcs.length===1&&cards.some(card=>card.upcs.length===1&&card.upcs[0]===backendUpc);
    const emptyChannel=['channelName','channelCode','url','channelSpec'].every(key=>!values[key]);
    const referenceEmptySource=route.isReferenceRoute&&referenceProductVerified&&newChannelSupported&&(emptyChannel||p.valid);
    if(referenceEmptySource)s.channel='pdd';
    const referenceBound=route.isReferenceRoute&&referenceProductVerified&&procurementAllowed&&(referenceEmptySource||!!supplier&&channel==='pdd');
    const level=routeMode==='new'?'new_relation_form':route.invalidRelationId?'unknown':relationId?'relation_id':referenceBound?'reference_form':origin?.rowRef&&backendUpc&&supplier?'clicked_row_form':'unknown';
    const bindingId=nativeActive?.node===node?nativeActive.bindingId:'qnh-form-'+session+'-'+(++serial);
    const warnings=[],reasons=[];
    if(routeMode==='new'){warnings.push('当前是新增网采关系草稿（尚无关系ID）；需明确确认新增后才可填入六项，最后由你补全供应商等必填项并原生提交');reasons.push('NEW_RELATION_CONFIRMATION_REQUIRED');if(!supplier)warnings.push('当前供应商为空，插件不会代选；请在原生表单补全后提交');}
    if(route.invalidRelationId){warnings.push('编辑路由的关系ID为空、重复或无效，不能确认已有网采关系');reasons.push('INVALID_ROUTE_RELATION_ID');}
    if(backendUpcSource==='page_query_only'){warnings.push('UPC仅来自页面查询条件，不能证明已关联到当前网采关系');reasons.push('UPC_QUERY_ONLY');}
    if(!backendUpc){warnings.push('未读取当前后台商品的UPC');reasons.push('MISSING_BACKEND_UPC');}
    if(!tenant)warnings.push('租户身份不可读');if(!s.scopeComplete&&routeMode!=='new')warnings.push('完整门店范围未展开读取，仅保持原生表单范围不变');if(!relationId&&routeMode!=='new')warnings.push('关系ID不可读，仅可绑定本次明确点击的原生表单');
    if(!fieldsComplete)warnings.push('六字段缺失、重复或不可编辑');
    if(!tenant)reasons.push('MISSING_TENANT');if(!fieldsComplete)reasons.push('INCOMPLETE_NATIVE_FIELDS');
    if(level==='unknown'){
      if(route.isReferenceRoute){
        if(!referenceProductVerified)reasons.push('REFERENCE_PRODUCT_UNVERIFIED');
        if(!supplier)reasons.push('REFERENCE_SUPPLIER_UNVERIFIED');
        if(!procurementAllowed)reasons.push('REFERENCE_CHANNEL_UNVERIFIED');
        else if(s.channel!=='pdd')reasons.push('REFERENCE_SOURCE_UNVERIFIED');
      }else reasons.push('UNVERIFIED_RELATION');
    }
    const newDraftReady=routeMode==='new'&&!!tenant&&fieldsComplete&&backendUpcSource==='native_product'&&!!backendUpc&&procurementAllowed;
    if(routeMode==='new'&&!procurementAllowed)reasons.push('UNCONFIRMED_PROCUREMENT_CHANNEL');
    if(routeMode!=='new'&&s.channel!=='pdd')reasons.push('UNCONFIRMED_PDD_SOURCE');
    const canFill=routeMode==='new'?newDraftReady:!route.invalidRelationId&&!!tenant&&level!=='unknown'&&fieldsComplete&&s.channel==='pdd'&&!!backendUpc&&backendUpcSource!=='page_query_only';
    s.rowRef=nativeActive?.node===node?nativeActive.rowRef:(origin?.rowRef||bindingId);
    s.nativeEditor={canFill,routeMode,routeKey,writeMode:routeMode==='new'?'new_draft':'existing_relation',newChannelSupported:procurementAllowed,sourceEvidence,evidenceFingerprint,reasons,emptyFields:maintenanceKeys.filter(k=>!values[k]),identityLevel:level,bindingId,fieldsComplete,scopeEvidence:routeMode==='new'?'unknown':s.scopeComplete?'complete':'preserved_form',protectionFingerprint,protectedFields,recoveryControlRoles:recoveryControlRoles(node),warnings};
    s.issues=unique((raw.issues||[]).filter(x=>!x.includes('禁止填入')&&!x.includes('未读取明确网采关系ID')).concat(warnings));
    s.fingerprint=hash({tenantId:s.tenantId,relationId:s.relationId,routeMode:s.routeMode,routeKey,rowRef:s.rowRef,backendUpc,supplier,fields:values,protectionFingerprint,evidenceFingerprint,bindingId});
    const priceNode=nodes.purchasePrice[0],precisionAttr=attr(priceNode,'data-qnh-decimals');
    if(/^[0-6]$/.test(precisionAttr))s.nativeEditor.purchasePriceDecimals=precisionAttr;
    // InputNumber step controls the spinner increment; it does not establish
    // the application's accepted monetary precision (e.g. step=1, value=4.4).
    s.nativeEditor.formFingerprint=s.fingerprint;
    if(nativeActive?.node===node&&nativeActive.completionMode){const summary=scopeCommittedText(completionNativeParts(node));s.completionScopeSummary=summary;s.scopeText=summary;s.fingerprint=hash({nativeFingerprint:s.fingerprint,completionScopeSummary:summary});s.nativeEditor.formFingerprint=s.fingerprint;}
    return {snapshot:s,editor:{visible:true,canFill,routeMode,reasons,relationId,tenantId:tenant,native:true,fieldsComplete,warnings}};
  }
  function inspectNative({refresh=false,newSelection=false}={}){
    const roots=nativeRootCandidates();if(roots.length!==1)fail(roots.length?'AMBIGUOUS_EDITOR':'NO_EDITOR',roots.length?'存在多个原生六字段表单':'没有识别到原生六字段表单');
    const node=roots[0];
    // An explicit SKU click starts a new selection. Both new and existing SPA
    // editors can replace their form DOM after loading or switching products.
    // Rebind only here, never during quote checks, plans or writes.
    if(newSelection&&nativeActive){
      const before=nativeActive.baseline,next=nativeSnapshot(node).snapshot,route=nativeRouteInfo();
      const newDraft=before.routeMode==='new'&&next.routeMode==='new'&&!before.relationId&&!next.relationId;
      const referenceEdit=route.isReferenceRoute&&next.routeMode==='edit'&&next.nativeEditor.canFill===true&&['reference_form','relation_id'].includes(next.nativeEditor.identityLevel);
      const existingEdit=next.routeMode==='edit'&&next.nativeEditor.identityLevel==='relation_id'&&next.nativeEditor.canFill===true&&/^[1-9]\d*$/.test(next.relationId||'')&&
        route.isNativeRoute&&!route.isReferenceRoute;
      const verifiedEdit=referenceEdit||existingEdit;
      if((newDraft||referenceEdit||existingEdit)&&
         (before.tenantId?next.tenantId===before.tenantId:verifiedEdit&&!!next.tenantId)&&(verifiedEdit||next.nativeEditor.routeKey===before.nativeEditor.routeKey)&&
         next.backendUpcSource==='native_product'&&next.backendUpc&&
         (nativeActive.node!==node||next.backendUpc!==before.backendUpc||(referenceEdit&&next.supplier!==before.supplier)||next.relationId!==before.relationId||
          (verifiedEdit&&(!before.nativeEditor.canFill||next.nativeEditor.routeKey!==before.nativeEditor.routeKey)))){
        nativeActive=null;active=null;
      }
    }
    if(nativeActive&&nativeActive.node!==node)fail('EDITOR_REPLACED','原六字段编辑器已被替换，请重新读取当前编辑页');
    const origin=active?.origin||null;
    // With an explicit stable relation ID a supplier edit is a reviewable
    // protected-field change. An unknown-ID clicked-row binding keeps its
    // supplier guard because that value is part of its identity evidence.
    const readOrigin=refresh&&origin&&nativeActive?.baseline?.relationId?{...origin,supplier:''}:origin,read=nativeSnapshot(node,readOrigin);
    if(!nativeActive){nativeActive={node,rowRef:read.snapshot.rowRef,bindingId:read.snapshot.nativeEditor.bindingId,baseline:read.snapshot,lastFilled:null};}
    let baseline=nativeActive.baseline;
    if(read.snapshot.tenantId!==baseline.tenantId||read.snapshot.relationId!==baseline.relationId||read.snapshot.routeMode!==baseline.routeMode||read.snapshot.nativeEditor.routeKey!==baseline.nativeEditor.routeKey)fail('EDITOR_IDENTITY_MISMATCH','原生编辑器身份变化');
    if(baseline.nativeEditor.identityLevel==='reference_form'&&(read.snapshot.backendUpc!==baseline.backendUpc||read.snapshot.backendUpcSource!=='native_product'||read.snapshot.supplier!==baseline.supplier))fail('EDITOR_IDENTITY_MISMATCH','补货参考编辑抽屉的商品或供应商已变化，请重新选择规格');
    if(refresh||read.snapshot.nativeEditor.evidenceFingerprint!==baseline.nativeEditor.evidenceFingerprint){nativeActive.baseline=read.snapshot;nativeActive.lastFilled=null;baseline=read.snapshot;}
    if(read.snapshot.nativeEditor.protectionFingerprint!==baseline.nativeEditor.protectionFingerprint)fail('EDITOR_DIRTY','供应商、范围或其他保持字段发生变化，请重新读取审核');
    const acceptable=nativeActive.lastFilled||baseline.nativeFields;
    const currentNodes=nativeNodes(node),changed=maintenanceKeys.filter(k=>text(currentNodes[k][0])!==strValue(acceptable[k]));
    const returned={...baseline,nativeEditor:{...baseline.nativeEditor,currentFields:read.snapshot.nativeFields,dirtyFields:changed}};
    if(changed.length)returned.nativeEditor.canFill=false;
    return {snapshot:returned,editor:{...read.editor,canFill:returned.nativeEditor.canFill,warnings:changed.length?read.editor.warnings.concat('六字段已被人工修改，请重新读取审核'):read.editor.warnings}};
  }
  const strValue=v=>String(v??'').trim();
  function validateSix(fields,manualPurchasePrice=false,preserveQuantity=false){
    if(preserveQuantity&&!manualPurchasePrice)fail('INVALID_FIELDS','数量手填模式需要手填采购价');
    const keys=maintenanceKeys.filter(key=>!(manualPurchasePrice&&key==='purchasePrice')&&!(preserveQuantity&&['ratioPdd','ratioQnh'].includes(key)));
    if(!fields||keys.some(k=>!Object.hasOwn(fields,k))||Object.keys(fields).some(k=>!keys.includes(k)))fail('INVALID_FIELDS','收到的字段与本次代填范围不一致');
    const v=Object.fromEntries(keys.map(k=>[k,strValue(fields[k])])),p=urlIds(v.url);
    let u;try{u=new URL(v.url);}catch{fail('INVALID_URL','结算链接无效');}
    if(!p.valid||u.hostname!=='mobile.yangkeduo.com'||u.pathname!=='/order_checkout.html'||!p.goodsId||!p.skuId||v.channelName!==p.goodsId||v.channelSpec!==p.skuId)fail('INVALID_FIELDS','渠道名称必须是goods_id，规格必须是sku_id，且与结算链接一致');
    for(const k of keys.filter(k=>['ratioPdd','ratioQnh','purchasePrice'].includes(k)))if(!/^\d+(?:\.\d+)?$/.test(v[k])||!/[1-9]/.test(v[k]))fail('INVALID_FIELDS','比例及采购价必须是正十进制数');
    return v;
  }
  function fillMaintenance({rowRef,expectedFingerprint,fields,newRelationConfirmed,writeMode,manualPurchasePrice=false,preserveQuantity=false,referenceDraft=false}){
    const result=inspectNative(),s=result.snapshot,v=validateSix(fields,manualPurchasePrice,preserveQuantity),writeKeys=Object.keys(v);
    if(rowRef!==s.rowRef||!expectedFingerprint||expectedFingerprint!==s.fingerprint)fail('CONFLICT','原生表单或审核快照已变化');
    if(s.routeMode==='new'&&(newRelationConfirmed!==true||writeMode!=='new_draft'))fail('NEW_RELATION_CONFIRMATION_REQUIRED','当前是新增关系草稿，必须在最新预览中明确批准新增及六字段填入');
    if(s.routeMode!=='new'&&writeMode==='new_draft')fail('WRITE_MODE_MISMATCH','当前是已有关系编辑页，不能当作新增草稿填入');
    if(!result.editor.canFill)fail('UNSAFE_EDITOR','六字段表单身份、UPC或保持字段未确认',result.editor);
    const node=nativeActive.node,nodes=nativeNodes(node),before=nativeValues(nodes),guard=s.nativeEditor.protectionFingerprint;
    const beforeProtected=s.nativeEditor.protectedFields,beforeControls=protectedControlNodes(node),minimums=minimumQuantityControls(node),minimum=minimums.length===1?minimums[0]:null;
    const minimumIndex=beforeControls.indexOf(minimum),minimumBefore=minimum?text(minimum):null,minimumReadOnly=minimum?.readOnly,minimumLabelBefore=beforeProtected.find(([key])=>key==='起订量')?.[1];
    const allowNativeMinimum=!preserveQuantity&&minimumIndex>=0&&Array.isArray(minimumLabelBefore)&&(referenceDraft?(minimumLabelBefore.length===0||minimumLabelBefore.length===1&&minimumLabelBefore[0]===minimumBefore):(s.routeMode==='new'&&s.nativeEditor.writeMode==='new_draft'&&writeMode==='new_draft'&&minimumBefore===''&&minimumLabelBefore.length===0));
    for(const key of writeKeys)setValue(nodes[key][0],v[key]);
    const actual=nativeValues(nativeNodes(node));
    if(preserveQuantity&&['ratioPdd','ratioQnh'].some(key=>actual[key]!==before[key]))fail('PROTECTED_FIELDS_CHANGED','原生联动改变了下单比例，请检查后再保存');
    if(manualPurchasePrice&&actual.purchasePrice!==before.purchasePrice)fail('PROTECTED_FIELDS_CHANGED','原生联动改变了人工采购价，请检查后再保存',{protectedField:{label:'采购价',before:before.purchasePrice,after:actual.purchasePrice}});
    if(writeKeys.some(k=>['ratioPdd','ratioQnh','purchasePrice'].includes(k)?!decimalEquivalent(actual[k],v[k]):actual[k]!==v[k]))fail('FILL_REJECTED','页面未接受全部已批准字段，请检查原生表单，不要直接保存',{actual});
    const afterProtected=protectedValues(node),nativeDefaultChanges=[];let comparedProtected=afterProtected;
    if(hash(afterProtected)!==guard&&allowNativeMinimum){
      const afterMinimums=minimumQuantityControls(node),afterControls=protectedControlNodes(node),minimumLabelAfter=afterProtected.find(([key])=>key==='起订量')?.[1];
      const afterMinimum=text(minimum),knownMinimum=afterMinimum===v.ratioQnh||(referenceDraft&&afterMinimum==='1');
      if(minimum.isConnected!==false&&node.contains(minimum)&&afterMinimums.length===1&&afterMinimums[0]===minimum&&afterControls[minimumIndex]===minimum&&minimum.readOnly===minimumReadOnly&&knownMinimum&&Array.isArray(minimumLabelAfter)&&minimumLabelAfter.length===1&&minimumLabelAfter[0]===afterMinimum){
        // Only this labelled input's value may acquire the native ratio default.
        // Keep every other row and every other control attribute in the guard.
        comparedProtected=afterProtected.map(row=>row[0]==='起订量'?[row[0],minimumLabelBefore]:row[0]==='business-control'&&row[1]===minimumIndex?row.map((value,index)=>index===5?minimumBefore:value):row);
        if(hash(comparedProtected)===guard)nativeDefaultChanges.push({field:'minimumQuantity',before:minimumBefore,after:afterMinimum,source:'native_ratio_linkage'});
      }
    }
    if(hash(comparedProtected)!==guard){const details=protectedChangeDetails(node,beforeProtected,comparedProtected,beforeControls);fail('PROTECTED_FIELDS_CHANGED','页面联动改变了保持字段：'+details.protectedField.label+'，请人工检查后再保存',details);}
    if(nativeNodes(node).channelCode.length&&actual.channelCode!==v.channelName)fail('DERIVED_CODE_MISMATCH','页面派生编码与商品ID不一致');
    // Return the accepted values even when an existing relation has no native
    // minimum-quantity linkage. Otherwise a later selection compares against
    // stale pre-fill fields after an unmatched carton lookup.
    nativeActive.baseline=nativeSnapshot(node).snapshot;
    nativeActive.lastFilled={...actual,...v};filledNativeNodes.add(node);
    return {filled:true,fields:writeKeys.map(field=>({field,before:before[field],after:v[field]})),nativeDefaultChanges,snapshot:inspectNative().snapshot,writeMode:s.nativeEditor.writeMode,manualSaveRequired:true,submitted:false};
  }
  function verifyMaintenance({rowRef,expected={},beforeSnapshot}){
    const wanted=validateSix(expected.fields||expected,expected.manualPurchasePrice===true,expected.preserveQuantity===true),verifyKeys=Object.keys(wanted),before=beforeSnapshot;
    if(before?.routeMode==='new'||before?.nativeEditor?.writeMode==='new_draft')return {status:'unknown',snapshot:null,details:['本次填写的是新增关系草稿，未自动提交；请在牵牛花原生提交后人工确认新生成的网采关系ID、供应商及供货范围']};
    if(!before?.tenantId||!before.relationId)return {status:'unknown',snapshot:null,details:['缺少明确租户及关系ID，不能按UPC或SKU代替唯一关系核对']};
    const roots=nativeRootCandidates();let s;
    if(roots.length===1){
      if(filledNativeNodes.has(roots[0]))return {status:'unknown',snapshot:inspectNative().snapshot,details:['仍是插件填入后的编辑表单；请人工保存并刷新或重新打开关系后核对']};
      const current=nativeSnapshot(roots[0]);s=current.snapshot;
    }else{
      const matches=rowNodes().map(n=>({node:n,s:extract(n,pageTenant())})).filter(x=>x.s.tenantId===before.tenantId&&x.s.relationId===before.relationId);
      if(matches.length!==1)return {status:'unknown',snapshot:null,details:['保存后未找到同租户明确关系ID的唯一记录']};
      s=attach(matches[0].node,matches[0].s);s.nativeFields=Object.fromEntries([...maintenanceKeys,'channelCode'].map(k=>[k,field(matches[0].node,k)]));
    }
    if(s.tenantId!==before.tenantId||s.relationId!==before.relationId)return {status:'mismatch',snapshot:s,details:['租户或关系ID不一致']};
    const missing=verifyKeys.filter(k=>!s.nativeFields?.[k]);if(missing.length)return {status:'unknown',snapshot:s,details:['回读缺少字段：'+missing.join('、')+'；请刷新后重新打开原生关系']};
    const details=verifyKeys.filter(k=>k==='url'?normalizedUrl(s.nativeFields[k])!==normalizedUrl(wanted[k]):!(['ratioPdd','ratioQnh','purchasePrice'].includes(k)?decimalEquivalent(s.nativeFields[k],wanted[k]):s.nativeFields[k]===wanted[k])).map(k=>'已填字段不一致：'+k);
    if(s.nativeFields.channelCode&&s.nativeFields.channelCode!==wanted.channelName)details.push('页面派生编码与新商品ID不同');
    if(before.nativeEditor?.protectionFingerprint&&s.nativeEditor?.protectionFingerprint&&before.nativeEditor.protectionFingerprint!==s.nativeEditor.protectionFingerprint)details.push('保持字段发生变化');
    if(!s.nativeEditor?.protectionFingerprint)return {status:details.length?'mismatch':'unknown',snapshot:s,details:details.concat('列表未完整读取保持字段，请重新打开原生关系核对')};
    return {status:details.length?'mismatch':'verified',snapshot:s,details:details.length?details:['刷新后同租户、同关系的已填字段与原生可见保持字段一致，请同时检查原生保存提示']};
  }
  function decimalEquivalent(a,b){if(a===b)return true;if(!/^\d+(?:\.\d+)?$/.test(a)||!/^\d+(?:\.\d+)?$/.test(b))return false;const canon=x=>x.replace(/^0+(?=\d)/,'').replace(/(\.\d*?)0+$/,'$1').replace(/\.$/,'');return canon(a)===canon(b);}
  function beginCartonSelection({rowRef,expectedFingerprint,anchor}){
    const read=inspectNative({refresh:true}),before=read.snapshot,node=nativeActive.node;
    if(before.rowRef!==rowRef||before.fingerprint!==expectedFingerprint)fail('CONFLICT','选择箱规前表单发生变化');
    const matches=query(node,'[data-qrth-carton-anchor]').filter(n=>attr(n,'data-qrth-carton-anchor')===anchor);
    if(matches.length!==1||!visible(matches[0]))fail('CARTON_TARGET_CHANGED','未确认当前表单的唯一箱规控件');
    const control=matches[0],controls=protectedControlNodes(node),indices=new Set(controls.map((n,i)=>n===control||control.contains(n)?i:-1).filter(i=>i>=0));
    const token='carton-select-'+session+'-'+(++serial);
    cartonSelection={token,node,control,before,controls,indices,expires:Date.now()+15000};return {token};
  }
  function endCartonSelection({token}){
    const operation=cartonSelection;if(!operation||operation.token!==token||operation.expires<Date.now())fail('CARTON_SELECTION_EXPIRED','箱规选择校验已失效');
    const {node,control,before,controls,indices}=operation;
    if(nativeActive?.node!==node||!node.isConnected||!node.contains(control))fail('CARTON_TARGET_CHANGED','箱规表单已关闭或替换');
    const after=nativeSnapshot(node).snapshot,afterControls=protectedControlNodes(node);
    if(before.tenantId!==after.tenantId||before.backendUpc!==after.backendUpc||before.rowRef!==after.rowRef||before.nativeEditor.bindingId!==after.nativeEditor.bindingId||before.nativeEditor.routeKey!==after.nativeEditor.routeKey||JSON.stringify(before.nativeFields)!==JSON.stringify(after.nativeFields))fail('CARTON_OTHER_FIELDS_CHANGED','选箱规期间商品、采购价或下单比例发生变化，请手动核对');
    if(controls.length!==afterControls.length||controls.some((n,i)=>n!==afterControls[i]))fail('CARTON_OTHER_FIELDS_CHANGED','选箱规期间其他业务控件发生变化');
    const normalize=rows=>rows.map(row=>['箱规','箱规单位'].includes(row[0])?[row[0],'approved_carton_selection']:row[0]==='business-control'&&indices.has(row[1])?row.map((v,i)=>i===5?'approved_carton_selection':v):row);
    if(hash(normalize(before.nativeEditor.protectedFields))!==hash(normalize(after.nativeEditor.protectedFields)))fail('CARTON_OTHER_FIELDS_CHANGED','选箱规期间供应商、范围或其他保持字段发生变化');
    nativeActive.baseline=after;nativeActive.lastFilled=null;cartonSelection=null;return {snapshot:after};
  }
  async function searchUpc({upc}){
    const value=strValue(upc);if(!/^\d{8,14}$/.test(value))fail('INVALID_UPC','UPC应为8至14位数字，前导零会保留');
    if(nativeRootCandidates().length||editors().length)fail('EDITOR_ALREADY_OPEN','请先完成或关闭当前原生编辑页，再查询UPC');
    let inputs=query(doc,'[data-qnh-search-upc]').filter(visible);
    if(!inputs.length){const candidates=[];for(const label of nativeLabels(doc))if(visible(label)&&clean(text(label))==='牵牛花商品编码'){
      const byId=attr(label,'for')&&doc.getElementById?.(attr(label,'for'));if(byId&&visible(byId))candidates.push(byId);
      const box=localControlBox(label,doc);if(box)candidates.push(...query(box,'input').filter(visible));
    }inputs=[...new Set(candidates)];}
    if(inputs.length!==1||inputs[0].disabled||inputs[0].readOnly)fail('AMBIGUOUS_UPC_SEARCH','未唯一识别“牵牛花商品编码”查询框');
    const explicit=query(doc,'[data-qnh-action="search"]').filter(visible),buttons=explicit.length?explicit:query(doc,'button, [role="button"]').filter(n=>visible(n)&&/^(查询|搜索)$/.test(clean(text(n))));
    if(buttons.length!==1)fail('AMBIGUOUS_SEARCH_BUTTON','查询按钮不唯一，请在原页面手动查询');
    setValue(inputs[0],value);buttons[0].click();await new Promise(r=>setTimeout(r,350));
    return {...handlers.QNH_READ_PAGE(),query:{upc:value,submitted:true,completion:'visible_dom_only'}};
  }

  // New-form completion is a separate, explicit authorization path. Component
  // drivers are installed only after their native DOM has been verified.
  const completionRules=Object.freeze({channelOther:true,supplier:'first_available',orderMultiple:'ratioQnh',scope:'all_selectable_stores',defaultSupply:'preserve'});
  const completionSteps=[['channelOther','选择其他采购平台'],['supplierFirst','选择首个可选供应商'],['multiple','按后台数量填写起订倍数'],['scopeAll','按门店全选供货范围']];
  const unavailableCompletionDriver={
    inspect:()=>({capabilities:{channelOther:false,supplierFirst:false,multiple:false,scopeAll:false},supplierEvidence:{status:'at_execution'},scopeEvidence:{status:'at_execution'},allowedNodes:[],before:{}}),
    apply:()=>fail('COMPLETION_COMPONENT_UNVERIFIED','新增设置组件尚未完成原生DOM适配，未执行写入')
  };
  function completionFieldItem(root,forName,names){
    const wanted=new Set(names.map(clean)),items=[];
    for(const label of nativeLabels(root))if(attr(label,'for')===forName||wanted.has(clean(text(label)))){
      const item=label.closest?.('.pms-roo-form-pro-item, .pms-roo-form-item, .pms-ant-form-item, .ant-form-item, .el-form-item, [data-qnh-item]');
      if(item&&root.contains(item))items.push(item);
    }
    const found=[...new Set(items)];return found.length===1?found[0]:null;
  }
  const supplierSelectSelector='.pms-ant-select, .ant-select, .pms-roo-select';
  const supplierWidgetSelector=supplierSelectSelector+', [role="combobox"], select';
  function supplierField(root){
    const field=completionFieldItem(root,'qnhSupplierId',labels.supplier);
    if(field)return field;
    if(!nativeRouteInfo().isReferenceRoute)return null;
    const anchors=nativeLabels(root).filter(n=>labels.supplier.some(label=>clean(text(n))===clean(label)));
    const candidates=new Set();
    for(const anchor of anchors){
      for(let box=anchor.parentElement;box&&box!==root;box=box.parentElement){
        const widgets=query(box,supplierWidgetSelector).filter(visible);
        const outer=widgets.filter(n=>!widgets.some(other=>other!==n&&other.contains(n)));
        if(!outer.length)continue;
        if(outer.length===1&&nativeLabels(box).every(n=>!/^(采购价|箱规单位|起订量|起订倍数)$/.test(clean(text(n)))))candidates.add(box);
        break;
      }
    }
    const fields=[...candidates].filter(n=>![...candidates].some(other=>other!==n&&n.contains(other)));
    return fields.length===1?fields[0]:null;
  }
  function supplierControl(item){
    if(!item)return null;
    const controls=query(item,'input[role="combobox"], input[aria-controls], input[aria-owns], input[placeholder*="供应商"], select')
      .filter(n=>!n.disabled&&attr(n,'aria-disabled')!=='true'&&!n.closest('.pms-ant-select-disabled, .ant-select-disabled, .pms-roo-select-disabled')&&
        (visible(n)||visible(n.closest(supplierSelectSelector))));
    if(controls.length===1)return controls[0];
    if(controls.length)return null;
    const widgets=query(item,supplierWidgetSelector).filter(n=>visible(n)&&attr(n,'aria-disabled')!=='true'&&
      !n.closest('.pms-ant-select-disabled, .ant-select-disabled, .pms-roo-select-disabled'));
    const outer=widgets.filter(n=>!widgets.some(parent=>parent!==n&&parent.contains(n)));
    return outer.length===1?outer[0]:null;
  }
  function completionNativeParts(root){
    const channelGoodsItem=completionFieldItem(root,'channelGoodsInfo',['渠道商品','渠道商品信息']);
    const channelItem=completionFieldItem(root,'channelType',['采购渠道']),supplierItem=supplierField(root),multipleItem=completionFieldItem(root,'orderMultiple',['起订倍数','下单倍数']),scopeItem=completionFieldItem(root,'purchaseRangeInfo',['供货范围','门店供货范围','供货及默供范围'])||root;
    const channelOptions=query(channelItem||root,'.pms-roo-radio, .ant-radio-wrapper, [role="radio"]').filter(readableRadioWrapper).filter(wrapper=>clean(staticBusinessText(wrapper))==='其他采购平台').map(wrapper=>({wrapper,radios:query(wrapper,'input[type="radio"]')})).filter(option=>option.radios.length===1);
    const other=channelItem&&channelOptions.length===1?channelOptions[0]:null;
    const supplierInput=supplierControl(supplierItem);
    const multiples=multipleItem?query(multipleItem,'input').filter(n=>visible(n)&&!n.disabled&&!n.readOnly&&!/^(hidden|password|checkbox|radio)$/i.test(n.type||attr(n,'type'))):[];
    const sixNodes=new Set(Object.values(nativeNodes(root)).flat()),oldPlatformControls=channelGoodsItem&&!procurementEvidence(root).selected.some(v=>clean(v)==='其他采购平台')?query(channelGoodsItem,'input, textarea, select').filter(n=>!sixNodes.has(n)):[];
    return {channelItem,channelGoodsItem,oldPlatformControls,supplierItem,multipleItem,scopeItem,other,supplierInput,multipleInput:multiples.length===1?multiples[0]:null};
  }
  async function waitCompletion(check,label,timeout=1800){
    const until=Date.now()+timeout;let value;
    do{value=observeDom(check);if(value)return value;await new Promise(resolve=>setTimeout(resolve,50));}while(Date.now()<until);
    fail('COMPLETION_STEP_UNVERIFIED',label+'的原生结果未确认');
  }
  function renderedControl(node){
    // The portal can render inside an aria-hidden ancestor. Use layout for
    // interactive controls and exclude collapsed accessibility-only nodes.
    if(!node?.isConnected)return false;
    const rect=node.getBoundingClientRect();
    if(rect.width<1||rect.height<1)return false;
    for(let parent=node;parent&&parent!==doc.body;parent=parent.parentElement){
      const style=getComputedStyle(parent);
      if(parent.hidden||style.display==='none'||style.visibility==='hidden')return false;
      if((style.overflowX==='hidden'||style.overflowY==='hidden'||style.overflow==='clip')&&
         (!parent.clientWidth||!parent.clientHeight))return false;
    }
    return true;
  }
  const scopeModalSelector='.selectButtonModal, [class$="-modal-content"], [class$="-modal-dialog"], .pms-roo-modal-content, .pms-ant-modal-content, .ant-modal-content, [role="dialog"], dialog, .pms-roo-modal-dialog, .pms-roo-modal';
  const scopeFooterSelector='[class*="-modal-footer"], footer';
  const scopeTitleSelector='[class*="-modal-title"], [class*="-modal-header"], [role="heading"], h2, h3, h4, h5';
  const storePickerSelector='.pms-roo-multi-cascader-toggle, .pms-ant-select-selector, .ant-select-selector';
  const visibleModals=()=>query(doc,scopeModalSelector).filter(renderedControl);
  function visibleScopeModals(excluded=new Set()){
    const candidates=visibleModals().filter(modal=>!excluded.has(modal));
    const titlePattern=/^(添加|选择)门店供货范围$/;
    const matches=candidates.filter(modal=>{
      const label=doc.getElementById?.(attr(modal,'aria-labelledby'));
      if(titlePattern.test(clean(attr(modal,'aria-label')||text(label))))return true;
      if(query(modal,scopeTitleSelector).some(title=>renderedControl(title)&&titlePattern.test(clean(text(title)))))return true;
      // Some reference drawers render the title outside the dialog content.
      return query(modal,'[class*="-multi-cascader-toggle"]').some(renderedControl)&&
        query(modal,'input[type="radio"]').some(radio=>clean(text(radio.closest('label, [role="radio"]')))==='按门店选择')&&
        !!scopeButton(modal,/^取消$/)&&!!scopeButton(modal,/^(确定|确认)$/);
    });
    return matches.filter(modal=>!matches.some(inner=>inner!==modal&&modal.contains(inner)));
  }
  function scopeButton(modal,pattern){
    const candidates=query(modal,'button, [role="button"]').filter(button=>{
      const footer=button.closest(scopeFooterSelector);
      return renderedControl(button)&&!button.disabled&&attr(button,'aria-disabled')!=='true'&&!(button.form&&button.type==='submit')&&
        pattern.test(clean(text(button)))&&footer&&modal.contains(footer);
    });
    return candidates.length===1?candidates[0]:null;
  }
  function scopeEntry(parts){
    const buttons=parts.scopeItem?query(parts.scopeItem,'button').filter(n=>visible(n)&&clean(text(n))==='添加门店供货范围'):[];
    return buttons.length===1&&!buttons[0].disabled?buttons[0]:null;
  }
  function scopeCommittedText(parts){
    if(!parts.scopeItem)return '';
    const controls=query(parts.scopeItem,'.pms-roo-form-pro-control').filter(visible),value=staticBusinessText(controls.length===1?controls[0]:parts.scopeItem);
    if(!/已选\s*[1-9]\d*\s*(?:个|家)?\s*门店/.test(value))return '';
    return value.split(/\r?\n/).map(norm).filter(v=>v&&!['供货范围','供货及默供范围','门店供货范围','添加门店供货范围','请选择','请选择门店','门店','查询','暂无门店'].includes(clean(v))).join('；');
  }
  async function applyAllStores({node,checkpoint=()=>{},reference=false}){
    const parts=completionNativeParts(node),entry=scopeEntry(parts),before=scopeCommittedText(parts);
    if(!entry)fail('COMPLETION_COMPONENT_UNVERIFIED','未唯一识别添加门店供货范围按钮');
    if(visibleScopeModals().length||!reference&&query(doc,'.pms-roo-modal-content').some(visible))fail('SCOPE_MODAL_ALREADY_OPEN','已有门店范围弹窗，请先关闭');
    const existing=new Set(visibleModals());
    const opened=()=>{const found=visibleScopeModals(existing);return found.length===1?found[0]:null;};
    let modal;
    checkpoint();
    try{
      entry.click();
      modal=await waitCompletion(opened,'门店范围弹窗',3500);
      const radios=query(modal,'input[type="radio"]').filter(radio=>{
        const option=radio.closest('label, [role="radio"], .pms-roo-radio, .pms-ant-radio-wrapper, .ant-radio-wrapper');
        return option&&renderedControl(option)&&clean(attr(option,'title')||attr(option,'aria-label')||text(option))==='按门店选择';
      });
      const radio=radios.length===1?radios[0]:null;
      if(!radio)fail('AMBIGUOUS_STORE_DIMENSION','未唯一识别按门店选择选项');
      const checked=()=>radio.checked;
      checkpoint();
      if(!checked()){if(radio.disabled)fail('STORE_DIMENSION_DISABLED','按门店选择不可用');(radio.closest('label')||radio).click();}
      await waitCompletion(checked,'按门店维度');

      const nativeToggles=query(modal,'[class*="-multi-cascader-toggle"]').filter(n=>renderedControl(n)&&[...n.classList].some(name=>name.endsWith('-multi-cascader-toggle')));
      const toggles=query(modal,storePickerSelector).filter(n=>renderedControl(n)&&/请选择门店|选择门店|请选择/.test(text(n)||attr(n,'aria-label')));
      const picker=nativeToggles.length===1?nativeToggles[0]:toggles.length===1?toggles[0]:null;
      if(!picker)fail('AMBIGUOUS_STORE_PICKER','门店选择器不唯一');
      const popupSelector='[class*="-picker-multi-cascader-menu"], .pms-roo-popup, .pms-ant-select-dropdown, .ant-select-dropdown, [role="listbox"]';
      const oldPopups=new Set(query(doc,popupSelector).filter(renderedControl));
      const allControl=popup=>{
        const roots=query(popup,'[class*="-multi-cascader-checkall"]').filter(renderedControl);
        if(roots.length===1){
          const labels=query(roots[0],'label[class*="-checkbox"]').filter(renderedControl);
          if(labels.length===1)return labels[0];
        }
        const matches=query(popup,'label, [role="checkbox"], .pms-roo-multi-cascader-checkall').filter(n=>renderedControl(n)&&
          /^(全部|全选)$/.test(clean(attr(n,'title')||attr(n,'aria-label')||text(n))));
        const leaves=matches.filter(n=>!matches.some(inner=>inner!==n&&n.contains(inner)));
        return leaves.length===1?leaves[0]:null;
      };
      checkpoint();picker.click();
      const popup=await waitCompletion(()=>{
        const found=query(doc,popupSelector).filter(n=>renderedControl(n)&&!oldPopups.has(n)&&allControl(n));
        const leaves=found.filter(n=>!found.some(inner=>inner!==n&&n.contains(inner)));
        return leaves.length===1?leaves[0]:null;
      },'门店选择列表',3500);
      const searches=query(popup,'input').filter(n=>renderedControl(n)&&/^(text|search)$/.test(n.type));
      if(searches.some(n=>text(n)))fail('FILTERED_STORE_PICKER','门店列表有搜索条件，无法全选门店');
      const control=allControl(popup);
      if(!control)fail('AMBIGUOUS_SELECT_ALL','门店全选控件已更新');
      const checks=control.matches('input[type="checkbox"]')?[control]:query(control,'input[type="checkbox"]');
      if(checks.length>1)fail('AMBIGUOUS_SELECT_ALL','门店全选状态不唯一');
      const checkbox=checks[0];
      const fullySelected=()=>checkbox?checkbox.checked&&!checkbox.indeterminate&&attr(control,'aria-checked')!=='mixed':attr(control,'aria-checked')==='true';
      checkpoint();if(!fullySelected()){
        if(checkbox?.disabled||attr(control,'aria-disabled')==='true')fail('SELECT_ALL_DISABLED','当前没有可全选的门店');
        control.click();
      }
      await waitCompletion(fullySelected,'门店全部选中状态');
      if(searches.some(n=>text(n)))fail('FILTERED_STORE_PICKER','选门店期间搜索筛选发生变化');
      const confirm=scopeButton(modal,/^(确定|确认)$/);
      if(!confirm)fail('AMBIGUOUS_SCOPE_CONFIRM','未唯一识别门店范围弹窗的确定按钮');
      checkpoint();confirm.click();
      await waitCompletion(()=>!renderedControl(modal),'门店范围原生确认');
      const after=await waitCompletion(()=>{
        const live=completionNativeParts(node);
        return scopeCommittedText(live)||(reference?referenceScopeRows(live).join('；'):'');
      },'已应用的门店范围');
      return {status:'verified',before,after,changedFields:[{field:'scopeText',before,after}],evidence:{dimension:'store',rootCheckboxChecked:true,indeterminate:false,summary:after,idsEnumerated:false}};
    }catch(error){
      const openedModal=modal||opened();
      if(renderedControl(openedModal)){
        const cancel=scopeButton(openedModal,/^取消$/);
        const close=query(openedModal,'button.close[data-dismiss="pms-roo-modal"], button.pms-ant-modal-close, button.ant-modal-close').filter(renderedControl);
        (cancel||(close.length===1?close[0]:null))?.click();
      }
      throw error;
    }
  }

  const supplierPopupSelector='[class*="-select-dropdown"], [role="listbox"]';
  const hasClassSuffix=(node,suffix)=>[...node.classList].some(name=>name.endsWith(suffix));
  function supplierPopup(node){
    return attr(node,'role')==='listbox'||hasClassSuffix(node,'-select-dropdown');
  }
  function supplierDropdown(input){
    const widget=input.closest(supplierSelectSelector)||input;
    const ids=unique([input,widget,...query(widget,'input[aria-controls], input[aria-owns], [role="combobox"]')]
      .flatMap(n=>[attr(n,'aria-controls'),attr(n,'aria-owns')].flatMap(value=>value.split(/\s+/))));
    const dropdowns=[];
    for(const id of ids){
      const list=doc.getElementById?.(id);
      if(!list)continue;
      let popup=list;
      while(popup&&!hasClassSuffix(popup,'-select-dropdown'))popup=popup.parentElement;
      popup=popup||list;
      if(renderedControl(popup)&&supplierOptions(popup).length)dropdowns.push(popup);
    }
    const found=[...new Set(dropdowns)];
    return found.length===1?found[0]:null;
  }
  function supplierOptions(dropdown){
    if(!dropdown)return [];
    const native=query(dropdown,'[class*="-select-item-option"]').filter(n=>hasClassSuffix(n,'-select-item-option')&&renderedControl(n));
    // rc-select can publish a clipped accessibility list separately from its clickable options.
    const options=native.length?native:query(dropdown,'[role="option"]').filter(renderedControl);
    return options.filter(n=>!options.some(inner=>inner!==n&&n.contains(inner))).map(option=>{
      const content=query(option,'[class*="-select-item-option-content"]')[0]||option;
      const columns=query(content,'[class*="-col"]').filter(n=>hasClassSuffix(n,'-col')&&renderedControl(n));
      return {node:option,label:columns.length?text(columns[0]):text(content).replace(/\s+/g,' ').trim(),disabled:option.disabled||
        attr(option,'aria-disabled')==='true'||hasClassSuffix(option,'-select-item-option-disabled')};
    });
  }
  function firstSupplierEvidence(dropdown){
    if(!dropdown)return null;
    const holders=query(dropdown,'.rc-virtual-list-holder').filter(renderedControl);if(holders.length>1||holders[0]&&Number(holders[0].scrollTop||0)!==0)return null;
    const inner=holders[0]?query(holders[0],'.rc-virtual-list-holder-inner'):[];if(holders.length&&inner.length!==1)return null;
    const translated=attr(inner[0],'style').match(/translateY\(\s*(-?[\d.]+)px\s*\)/i);if(translated&&Number(translated[1])!==0)return null;
    const options=supplierOptions(dropdown),first=options.find(option=>!option.disabled&&option.label);if(!first)return null;
    return {node:first.node,label:first.label,optionsFingerprint:hash(options.map(option=>[option.label,option.disabled]))};
  }
  async function applyFirstSupplier({node,plan,checkpoint=()=>{}}){
    const parts=completionNativeParts(node),input=parts.supplierInput;if(!input)fail('COMPLETION_COMPONENT_UNVERIFIED','未唯一识别当前新增表单供应商组合框');
    const before=staticBusinessText(parts.supplierItem);
    if(input.tagName==='SELECT'){
      const first=[...input.options].find(option=>option.value&&!option.disabled&&!option.parentElement?.disabled);
      if(!first)fail('SUPPLIER_FIRST_CHANGED','没有可用供应商');
      checkpoint();setValue(input,first.value);
      await waitCompletion(()=>input.value===first.value,'供应商选择回读');
      return {status:'verified',before,after:text(first)};
    }
    const trigger='.pms-ant-select-selector, .ant-select-selector, .pms-roo-select-toggle';
    const selector=input.closest(trigger)||query(input,trigger).find(visible)||input;
    const widget=input.closest(supplierSelectSelector)||input;
    const popups=()=>query(doc,supplierPopupSelector).filter(n=>supplierPopup(n)&&renderedControl(n));
    const previouslyOpen=new Set(popups());
    const isExpanded=()=>[widget,input,...query(widget,'[aria-expanded]')].some(n=>attr(n,'aria-expanded')==='true');
    const currentDropdown=()=>{
      const linked=supplierDropdown(input);
      if(linked)return linked;
      const expanded=isExpanded();
      const anchor=selector.getBoundingClientRect();
      const found=popups().filter(popup=>{
        if(!supplierOptions(popup).length)return false;
        if(!previouslyOpen.has(popup))return true;
        if(!expanded)return false;
        const rect=popup.getBoundingClientRect();
        return rect.left<anchor.right&&rect.right>anchor.left&&
          (Math.abs(rect.top-anchor.bottom)<32||Math.abs(rect.bottom-anchor.top)<32);
      });
      // The virtual list can have a listbox inside the outer select portal.
      const outer=found.filter(n=>!found.some(parent=>parent!==n&&parent.contains(n)));
      return outer.length===1?outer[0]:null;
    };
    checkpoint();
    if(input.tagName==='INPUT'&&!input.readOnly&&text(input))setValue(input,'');
    if(!currentDropdown()&&!isExpanded()){
      input.focus?.();const Mouse=globalThis.MouseEvent||Event;selector.dispatchEvent(new Mouse('mousedown',{bubbles:true,button:0,cancelable:true}));selector.click();
    }
    const dropdown=await waitCompletion(currentDropdown,'供应商下拉列表',8000);
    const holders=query(dropdown,'.rc-virtual-list-holder').filter(renderedControl);
    if(holders.length>1)fail('AMBIGUOUS_SUPPLIER_LIST','原生供应商虚拟列表不唯一');
    if(holders[0]&&Number(holders[0].scrollTop||0)!==0){holders[0].scrollTop=0;holders[0].dispatchEvent(new Event('scroll',{bubbles:true}));await new Promise(resolve=>setTimeout(resolve,100));}
    const first=await waitCompletion(()=>firstSupplierEvidence(currentDropdown()),'原生首个可选供应商');
    if(plan.supplierEvidence?.status==='read'&&(norm(plan.supplierEvidence.label)!==first.label||(plan.supplierEvidence.optionsFingerprint&&plan.supplierEvidence.optionsFingerprint!==first.optionsFingerprint)))fail('SUPPLIER_FIRST_CHANGED','原生首个可选供应商已变化，请重新预览');
    checkpoint();first.node.click();
    await waitCompletion(()=>{
      const selected=selectedSupplierValue(node).value;
      return !!selected&&clean(selected)===clean(normalizeSupplierDisplay(first.label));
    },'供应商选择回读');
    return {status:'verified',before,after:first.label,changedFields:[{field:'supplier',before,after:first.label}],evidence:{rule:'first_available',label:first.label,optionsFingerprint:first.optionsFingerprint,idRead:false}};
  }

  function referenceScopeRows(parts){
    return query(parts.scopeItem,'tbody tr, [role="row"]').filter(visible)
      .filter(row=>query(row,'button, a, [role="button"], span').some(n=>visible(n)&&clean(text(n))==='删除'))
      .map(staticBusinessText).filter(Boolean);
  }
  async function fillReferenceMaintenance(message){
    const before=inspectNative().snapshot,node=nativeActive?.node,opts=message.referenceDefaults;
    if(!nativeRouteInfo().isReferenceRoute||before.nativeEditor.identityLevel!=='reference_form'||!node||message.manualPurchasePrice!==true||opts?.draft!==true)
      return fillMaintenance(message);
    const filled=fillMaintenance({...message,referenceDraft:true}),operations=[];
    const base=filled.snapshot,price=base.nativeFields.purchasePrice;
    let acceptedSupplier=base.supplier;
    const checkpoint=(allowSupplier=false)=>{
      if(!nativeRouteInfo().isReferenceRoute||referenceEditorRoots().length!==1||referenceEditorRoots()[0]!==node||nativeActive?.node!==node)
        fail('EDITOR_REPLACED','补货参考编辑页已切换，已停止补齐');
      const live=nativeSnapshot(node).snapshot;
      if(live.rowRef!==base.rowRef||live.tenantId!==base.tenantId||live.backendUpc!==base.backendUpc||live.backendUpcSource!=='native_product'||
         live.nativeFields.purchasePrice!==price||(!allowSupplier&&live.supplier!==acceptedSupplier)||
         maintenanceKeys.some(key=>live.nativeFields[key]!==base.nativeFields[key]))
        fail('EDITOR_IDENTITY_MISMATCH','补货参考商品或原生表单已变化，已停止补齐');
      return live;
    };
    const run=async(label,apply,changesSupplier=false)=>{
      checkpoint();
      try{const result=await apply();const live=checkpoint(changesSupplier);acceptedSupplier=live.supplier;operations.push({label,status:'verified',after:result?.after});}
      catch(e){
        if(['EDITOR_REPLACED','EDITOR_IDENTITY_MISMATCH'].includes(e.code))throw e;
        const live=checkpoint(changesSupplier);acceptedSupplier=live.supplier;operations.push({label,status:'needs_review',message:e.message});
      }
    };
    if(opts.chooseSupplier&&!base.supplier)await run('供应商',()=>applyFirstSupplier({node,plan:{},checkpoint}),true);
    if(!message.preserveQuantity)for(const [key,label] of [['minimum','起订量'],['multiple','起订倍数']]){
      await run(label,()=>{
        const inputs=recoveryInputs(node)[key],n=inputs.length===1?inputs[0]:null,value=message.fields.ratioQnh;
        if(!n||n.readOnly||n.disabled)fail('COMPLETION_FIELD_DISABLED',label+'输入框未就绪');
        if(!decimalEquivalent(text(n),value))setValue(n,value);
        if(!decimalEquivalent(text(n),value)||n.validity?.valid===false)fail('COMPLETION_FIELD_REJECTED',label+'未接受后台数量');
        return {after:text(n)};
      });
    }
    const parts=completionNativeParts(node);
    if(!scopeCommittedText(parts)&&!referenceScopeRows(parts).length&&!query(parts.scopeItem,'tbody tr').some(row=>visible(row)&&query(row,'td').length>1&&!/暂无|无数据/.test(text(row)))){
      await run('供货范围',()=>applyAllStores({node,checkpoint,reference:true}));
    }
    const after=checkpoint();
    nativeActive.baseline=after;nativeActive.lastFilled=null;
    return {...filled,snapshot:after,referenceDefaults:operations};
  }

  function inspectNativeCompletion(root){
    const parts=completionNativeParts(root),dropdown=parts.supplierInput&&supplierDropdown(parts.supplierInput),first=dropdown&&!text(parts.supplierInput)&&firstSupplierEvidence(dropdown),supplierBound=!!parts.supplierInput&&!!norm(attr(parts.supplierInput,'aria-controls')||attr(parts.supplierInput,'aria-owns'));
    return {capabilities:{channelOther:!!parts.other&&(!parts.other.radios[0].disabled||parts.other.radios[0].checked===true),supplierFirst:supplierBound,multiple:!!parts.multipleInput,scopeAll:!!scopeEntry(parts)&&!query(doc,'.pms-roo-modal-content').some(visible)},supplierEvidence:first?{status:'read',label:first.label,value:'',optionsFingerprint:first.optionsFingerprint}:{status:'at_execution'},scopeEvidence:{status:'at_execution'},before:{orderMultiple:parts.multipleInput?text(parts.multipleInput):''},allowedNodes:[...(parts.other?.radios||[]),...parts.oldPlatformControls,parts.supplierInput,parts.multipleInput].filter(Boolean)};
  }
  async function applyNativeCompletion(id,{node,fields,plan}){
    const parts=completionNativeParts(node);
    if(id==='channelOther'){
      if(!parts.other)fail('COMPLETION_COMPONENT_UNVERIFIED','未唯一识别其他采购平台选项');
      const before=procurementEvidence(node).selected.join(' / '),input=parts.other.radios[0];
      if(!input.checked){if(input.disabled)fail('COMPLETION_FIELD_DISABLED','其他采购平台选项不可选');parts.other.wrapper.click();}
      await waitCompletion(()=>{const actual=completionNativeParts(node);return actual.other?.radios[0].checked===true;},'采购渠道');
      return {status:'verified',before,after:procurementEvidence(node).selected.join(' / ')};
    }
    if(id==='multiple'){
      const input=parts.multipleInput;if(!input)fail('COMPLETION_COMPONENT_UNVERIFIED','未唯一识别可编辑起订倍数');
      const before=text(input);setValue(input,fields.ratioQnh);
      if(!decimalEquivalent(text(input),fields.ratioQnh)||input.validity?.valid===false)fail('COMPLETION_FIELD_REJECTED','原生起订倍数未接受已批准的后台数量');
      return {status:'verified',before,after:text(input),changedFields:[{field:'orderMultiple',before,after:text(input)}]};
    }
    if(id==='supplierFirst')return applyFirstSupplier({node,plan});
    if(id==='scopeAll')return applyAllStores({node});
    fail('COMPLETION_COMPONENT_UNVERIFIED','该原生新增设置组件仍待确认DOM，未执行写入');
  }

  const nativeCompletionDriver={inspect:inspectNativeCompletion,apply:applyNativeCompletion};
  let completionDriver=nativeCompletionDriver;
  function completionAssociatedUpcs(node){
    // A typed backend-product search string is not a selected product. The
    // new completion path requires a static associated card or an explicitly
    // readonly UPC value, independently of the legacy name comparison path.
    return unique([...selectedProductCards(node).flatMap(card=>card.upcs),...productUpcs(node,'')]);
  }
  function completionRoots(){
    const route=nativeRouteInfo();if(!route.isNativeRoute||route.routeMode!=='new'||route.invalidRelationId)fail('NEW_FORM_ONLY','只能补齐尚无关系ID的单个新增表单');
    const candidates=[...new Set(query(doc,'form, [role="form"], .ant-form, .el-form, main, [role="tabpanel"], .ant-tabs-tabpane-active, body').filter(visible))].filter(node=>completionAssociatedUpcs(node).length===1);
    return candidates.filter(node=>!candidates.some(other=>other!==node&&node.contains(other)));
  }
  function completionSnapshot(node){
    if(nativeActive&&nativeActive.node!==node)fail('EDITOR_REPLACED','新增表单已被替换，请重新读取目标表单');
    const read=nativeSnapshot(node),s=read.snapshot,before=nativeActive?.baseline,associated=completionAssociatedUpcs(node);
    if(before&&(s.tenantId!==before.tenantId||s.relationId!==before.relationId||s.routeMode!==before.routeMode||s.nativeEditor.routeKey!==before.nativeEditor.routeKey))fail('EDITOR_IDENTITY_MISMATCH','新增表单的租户、关系或路由已改变');
    if(!s.tenantId||s.relationId||s.routeMode!=='new'||s.backendUpcSource!=='native_product'||!s.backendUpc||associated.length!==1||associated[0]!==s.backendUpc)fail('UNBOUND_NEW_PRODUCT','新增表单未确认租户及已关联后台商品UPC；查询条件不能代替关联商品');
    if(!nativeActive)nativeActive={node,rowRef:s.rowRef,bindingId:s.nativeEditor.bindingId,baseline:s,lastFilled:null};
    if(!nativeActive.completionMode){nativeActive.completionMode=true;const enriched=nativeSnapshot(node).snapshot;nativeActive.baseline=enriched;return enriched;}
    return s;
  }
  function normalizeCompletionEvidence(value,kind){
    if(value?.status==='read')return kind==='supplier'?{status:'read',value:norm(value.value),label:norm(value.label),optionsFingerprint:norm(value.optionsFingerprint)}:{status:'read',count:value.count,ids:Array.isArray(value.ids)?value.ids.map(norm):undefined,optionsFingerprint:norm(value.optionsFingerprint)};
    return {status:'at_execution'};
  }
  async function planNewCompletion({rowRef,expectedFingerprint,ratioQnh,preserveQuantity=false}={}){
    const roots=completionRoots();if(roots.length!==1)fail(roots.length?'AMBIGUOUS_EDITOR':'NO_NEW_FORM',roots.length?'存在多个已关联商品的新增表单':'未找到已关联后台商品的唯一新增表单');
    const node=roots[0],enteringCompletion=!nativeActive?.completionMode,nativeBefore=enteringCompletion?nativeSnapshot(node).snapshot.fingerprint:'',snapshot=completionSnapshot(node);
    if(rowRef&&rowRef!==snapshot.rowRef)fail('CONFLICT','新增表单绑定已变化，请重新预览');
    if(expectedFingerprint&&expectedFingerprint!==snapshot.fingerprint&&!(enteringCompletion&&expectedFingerprint===nativeBefore))fail('CONFLICT','新增表单字段已变化，请重新预览',{snapshot});
    const inspected=await completionDriver.inspect(node,snapshot),capabilities=inspected?.capabilities||{},reasons=[];
    const ratio=preserveQuantity?'':norm(ratioQnh);if(!preserveQuantity&&(!/^\d+(?:\.\d+)?$/.test(ratio)||!/[1-9]/.test(ratio)))reasons.push('请明确填写大于0的牵牛花后台数量，起订倍数不会使用默认值');
    for(const [id,label]of completionSteps)if(!(preserveQuantity&&id==='multiple')&&capabilities[id]!==true)reasons.push(label+'：原生组件尚未确认可操作');
    const supplierEvidence=normalizeCompletionEvidence(inspected?.supplierEvidence,'supplier'),scopeEvidence=normalizeCompletionEvidence(inspected?.scopeEvidence,'scope');
    if(supplierEvidence.status==='read'&&!supplierEvidence.label)reasons.push('首个可选供应商名称未读取完整');
    if(scopeEvidence.status==='read'&&(!Number.isInteger(scopeEvidence.count)||scopeEvidence.count<1))reasons.push('没有读取到可选门店，不能全选');
    const completionPlan={version:1,mode:'new_draft_completion',binding:{tenantId:snapshot.tenantId,backendUpc:snapshot.backendUpc,rowRef:snapshot.rowRef,bindingId:snapshot.nativeEditor.bindingId,routeKey:snapshot.nativeEditor.routeKey,beforeFingerprint:snapshot.fingerprint},ratioQnh:ratio,rules:{...completionRules,orderMultiple:preserveQuantity?'preserve':'ratioQnh'},before:{channel:snapshot.procurementChannelText||'',supplier:snapshot.supplier||'',orderMultiple:norm(inspected?.before?.orderMultiple),scope:snapshot.scopeText||''},supplierEvidence,scopeEvidence,warnings:['仅补齐当前新增草稿并填入六项，不会点击原生提交；默供沿用原生默认']};
    completionPlan.planFingerprint=hash(completionPlan);
    return {snapshot,completionPlan,canApply:reasons.length===0,reasons};
  }
  function completionGuard(node,allowedNodes){
    const permitted=new Set(allowedNodes||[]),nativeTargets=new Set(Object.values(nativeNodes(node)).flat());
    for(const n of permitted)if(!n||n===node||!node.contains(n)||[...nativeTargets].some(t=>n===t||n.contains?.(t)))fail('UNSAFE_COMPLETION_TARGET','新增设置字段边界不明确，未执行写入');
    const allowed=n=>[...permitted].some(target=>n===target||target.contains?.(n));
    const controls=query(node,'input, textarea, select').filter(n=>visible(n)&&!nativeTargets.has(n)&&!allowed(n)&&!/^(hidden|password|file)$/i.test(n.type||attr(n,'type'))).map(n=>({node:n,value:text(n),checked:!!n.checked,disabled:n.disabled===true}));
    const permittedNames=new Set(['供应商','供应商名称','采购渠道','起订倍数','下单倍数','供货范围','supplier','channel','scopeText','constraintsText']);
    const values=protectedValues(node).filter(([key,value])=>key!=='business-control'&&!permittedNames.has(key)&&(['非供货范围','excludedScopeText'].includes(key)||(value!==''&&(!Array.isArray(value)||value.length))));
    return ()=>{
      for(const entry of controls)if(entry.node.isConnected===false||!node.contains(entry.node)||text(entry.node)!==entry.value||!!entry.node.checked!==entry.checked||(entry.node.disabled===true)!==entry.disabled){const item=entry.node.closest?.('.pms-roo-form-pro-item, .ant-form-item, .el-form-item, [data-qnh-item]'),label=(item&&nativeLabels(item).map(text).find(v=>v.length<30))||attr(entry.node,'name')||attr(entry.node,'id')||'未识别业务控件';fail('PROTECTED_FIELDS_CHANGED','新增补齐联动改变了保持字段：'+label,{protectedField:{label,before:{value:entry.value,checked:entry.checked,disabled:entry.disabled},after:{value:text(entry.node),checked:!!entry.node.checked,disabled:entry.node.disabled===true}}});}
      const current=new Map(protectedValues(node).filter(([key])=>key!=='business-control'));
      const changed=values.find(([key,value])=>JSON.stringify(current.get(key))!==JSON.stringify(value));if(changed)fail('PROTECTED_FIELDS_CHANGED','新增补齐改变了保持字段：'+changed[0],{protectedField:{label:changed[0],before:changed[1],after:current.get(changed[0])}});
    };
  }
  function completionChangedFields(before,after){
    if(!after)return [];
    return [...maintenanceKeys.map(k=>['nativeFields.'+k,before.nativeFields?.[k],after.nativeFields?.[k]]),['supplier',before.supplier,after.supplier],['procurementChannelText',before.procurementChannelText,after.procurementChannelText],['scopeText',before.scopeText,after.scopeText]].filter(([,a,b])=>norm(a)!==norm(b)).map(([field,a,b])=>({field,before:a??'',after:b??''}));
  }
  async function completeNewForm({rowRef,expectedFingerprint,fields,completionPlan,newRelationConfirmed,newCompletionConfirmed,manualPurchasePrice=false,preserveQuantity=false}){
    if(newRelationConfirmed!==true||newCompletionConfirmed!==true)fail('NEW_COMPLETION_CONFIRMATION_REQUIRED','请在最新预览中明确批准新增六项及四项原生补齐规则');
    const six=validateSix(fields,manualPurchasePrice,preserveQuantity),planned=await planNewCompletion({rowRef,expectedFingerprint,ratioQnh:six.ratioQnh,preserveQuantity});
    if(!planned.canApply)fail('COMPLETION_UNAVAILABLE',planned.reasons.join('；'),{snapshot:planned.snapshot,operations:[]});
    if(!completionPlan?.planFingerprint||completionPlan.planFingerprint!==planned.completionPlan.planFingerprint||hash({...completionPlan,planFingerprint:undefined})!==hash({...planned.completionPlan,planFingerprint:undefined}))fail('COMPLETION_PLAN_CHANGED','新增补齐计划或首项/门店证据已变化，请重新预览',{snapshot:planned.snapshot,operations:[]});
    const node=nativeActive.node,before=planned.snapshot,inspected=await completionDriver.inspect(node,before),operations=[];
    const multipleInputs=preserveQuantity?recoveryInputs(node).multiple:[];
    const guard=completionGuard(node,(inspected.allowedNodes||[]).filter(control=>!multipleInputs.includes(control)));
    let lastSnapshot=before,currentStep=null;
    const checkIdentity=()=>{
      if(!visible(node)||node.isConnected===false)fail('EDITOR_REPLACED','新增表单已关闭或被替换');
      const s=nativeSnapshot(node).snapshot;
      if(preserveQuantity&&['ratioPdd','ratioQnh'].some(key=>s.nativeFields[key]!==before.nativeFields[key]))fail('PROTECTED_FIELDS_CHANGED','新增补齐联动改变了下单比例，请检查后再保存');
      if(manualPurchasePrice&&s.nativeFields.purchasePrice!==before.nativeFields.purchasePrice)fail('PROTECTED_FIELDS_CHANGED','新增补齐联动改变了人工采购价，请检查后再保存');
      if(s.routeMode!=='new'||s.relationId||s.tenantId!==before.tenantId||s.backendUpc!==before.backendUpc||s.backendUpcSource!=='native_product'||s.nativeEditor.routeKey!==before.nativeEditor.routeKey||s.rowRef!==before.rowRef)fail('EDITOR_IDENTITY_MISMATCH','新增补齐期间租户、关联商品或路由发生变化');
      return s;
    };
    const checkBoundary=()=>observeDom(()=>{guard();return checkIdentity();});
    try{
      for(const [id,label]of completionSteps){
        if(preserveQuantity&&id==='multiple')continue;
        currentStep={id,step:id,label,status:'running',before:null,after:null};operations.push(currentStep);checkBoundary();
        const result=await completionDriver.apply(id,{node,fields:six,plan:planned.completionPlan,snapshot:lastSnapshot});
        lastSnapshot=checkBoundary();
        if(result?.status!=='verified')fail('COMPLETION_STEP_UNVERIFIED',label+'的原生结果未确认');
        Object.assign(currentStep,{before:result.before??null,after:result.after??null,changedFields:result.changedFields||[],status:'completed'});
      }
      nativeActive.baseline=lastSnapshot;nativeActive.lastFilled=null;
      currentStep={id:'sixFields',step:'sixFields',label:preserveQuantity?'填写商品信息':manualPurchasePrice?'填写商品信息及下单比例，采购价手填':'填写已批准的六项',status:'running',before:before.nativeFields,after:null};operations.push(currentStep);
      const filled=fillMaintenance({rowRef,expectedFingerprint:lastSnapshot.fingerprint,fields:six,newRelationConfirmed:true,writeMode:'new_draft',manualPurchasePrice,preserveQuantity});
      currentStep.status='completed';currentStep.after=six;currentStep.changedFields=filled.fields;
      lastSnapshot=nativeSnapshot(node).snapshot;
      return {filled:true,writeMode:'new_draft_completion',operations,snapshot:lastSnapshot,nativeDefaultChanges:filled.nativeDefaultChanges||[],changedFields:completionChangedFields(before,lastSnapshot),manualSaveRequired:true,submitted:false};
    }catch(error){
      if(currentStep?.status==='running')currentStep.status='failed';
      try{lastSnapshot=nativeSnapshot(node).snapshot;}catch{lastSnapshot=null;}
      error.details={...(error.details||{}),operations,snapshot:lastSnapshot,changedFields:completionChangedFields(before,lastSnapshot),submitted:false};throw error;
    }
  }

  const scopedRead=read=>function(...args){return observeDom(()=>read(...args));};
  const scopedNodeRead=(kind,read)=>function(node){return observeDom(()=>memoNode(kind,node,()=>read(node)));};
  nativeLabels=scopedNodeRead('nativeLabels',nativeLabels);
  nativeNodes=scopedNodeRead('nativeNodes',nativeNodes);
  protectedControlNodes=scopedNodeRead('protectedControlNodes',protectedControlNodes);
  protectedValues=scopedNodeRead('protectedValues',protectedValues);
  recoveryInputs=scopedNodeRead('recoveryInputs',recoveryInputs);
  recoveryControlRoles=scopedNodeRead('recoveryControlRoles',recoveryControlRoles);
  completionNativeParts=scopedNodeRead('completionParts',completionNativeParts);
  staticBusinessText=scopedNodeRead('staticBusinessText',staticBusinessText);
  nativeSnapshot=scopedRead(nativeSnapshot);
  inspectNative=scopedRead(inspectNative);
  completionRoots=scopedRead(completionRoots);
  completionSnapshot=scopedRead(completionSnapshot);
  const readPageTenant=pageTenant;
  pageTenant=()=>observeDom(()=>{
    if(!readScope.globals.has('tenant'))readScope.globals.set('tenant',readPageTenant());
    return readScope.globals.get('tenant');
  });

  const handlers={
    QNH_READ_PAGE(){
      if(nativeRootCandidates().length){const roots=nativeRootCandidates();if(active?.node&&active.node!==roots[0])active=null;nativeActive=null;const r=inspectNative();return {page:{url:globalThis.location?.href||'',title:doc.title||'',tenantId:r.snapshot.tenantId,warnings:r.editor.warnings},relations:[r.snapshot]};}
      const tenantId=pageTenant(),relations=rowNodes().map(n=>attach(n,extract(n,tenantId))),counts=new Map();
      for(const s of relations)if(s.relationId){const k=s.tenantId+'\0'+s.relationId;counts.set(k,(counts.get(k)||0)+1);}
      for(const s of relations)if(s.relationId&&counts.get(s.tenantId+'\0'+s.relationId)>1){s.identityVerified=false;s.issues.push('当前页同租户关系ID重复');}
      for(const s of relations)if(!tenantId||s.tenantId!==tenantId){s.identityVerified=false;s.issues.push('页面租户上下文不唯一，行身份不能确认为当前商家');}
      const warnings=['仅读取当前DOM中的可见行；未翻页，虚拟列表可能尚未完整加载'];
      if(!tenantId)warnings.push('无法确认租户身份，禁止填入');
      if(!relations.length)warnings.push('没有读取到可见网采关系；请确认列表已加载且当前筛选有数据');
      return {page:{url:globalThis.location?.href||'',title:doc.title||'',tenantId,warnings},relations};
    },
    QNH_GET_RELATION:({rowRef})=>{if(nativeActive?.rowRef===rowRef&&nativeRootCandidates().length)return {snapshot:inspectNative().snapshot};return {snapshot:active?.rowRef===rowRef&&editors().length?inspect().snapshot:fresh(rowRef)};},
    QNH_OPEN_EDITOR:openEditor,QNH_INSPECT_EDITOR:({newSelection=false}={})=>inspect({refreshNative:true,newSelection:newSelection===true}),QNH_FILL_EDITOR:fill,QNH_VERIFY_RELATION:verify,
    QNH_SEARCH_UPC:searchUpc,QNH_FILL_MAINTENANCE:fillReferenceMaintenance,QNH_VERIFY_MAINTENANCE:verifyMaintenance,
    QNH_BEGIN_CARTON_SELECTION:beginCartonSelection,QNH_END_CARTON_SELECTION:endCartonSelection,QNH_ABORT_CARTON_SELECTION:({token})=>{if(cartonSelection?.token===token)cartonSelection=null;return {aborted:true};},
    QNH_PLAN_NEW_FORM_COMPLETION:planNewCompletion,QNH_COMPLETE_NEW_FORM:completeNewForm
  };
  let tableRoot=null,tableSignature='',tableToken='';
  const tableState=({watchLabels=false}={})=>observeDom(()=>{
    const labels=nativeRouteInfo().isReferenceRoute?referenceProductLabels():[];
    const roots=labels.length?referenceEditorRoots(labels):[];
    const node=roots.length===1?roots[0]:null;
    const eligible=!!node&&visible(node);
    const signature=eligible?JSON.stringify([location.href,selectedProductCards(node).map(c=>[c.name,c.upcs,c.spec])]):'';
    if(!eligible||node!==tableRoot||signature!==tableSignature){tableRoot=eligible?node:null;tableSignature=signature;tableToken=eligible?crypto.randomUUID():'';nativeActive=null;active=null;}
    return {eligible,token:tableToken,...(watchLabels?{labels}:{})};
  });
  globalThis.__qnhReplenishmentTableState=tableState;
  globalThis.__qnhReplenishmentTableEditor=()=>tableRoot;
  const tableAllowed=new Set(['QNH_GET_RELATION','QNH_INSPECT_EDITOR','QNH_FILL_MAINTENANCE','QNH_BEGIN_CARTON_SELECTION','QNH_END_CARTON_SELECTION','QNH_ABORT_CARTON_SELECTION']);
  globalThis.chrome?.runtime?.onMessage?.addListener((message,sender,respond)=>{
    if(sender.id!==chrome.runtime.id)return false;
    if(message?.type==='QRTH_ELIGIBILITY'){respond({ok:true,data:tableState()});return false;}
    if(message?.type==='QRTH_ADAPTER_1_0_0')message={...message,type:message.action};
    else if(!globalThis.__QNH_ADAPTER_TEST__)return false;
    if(!message||!Object.hasOwn(handlers,message.type))return false;
    Promise.resolve().then(()=>{
      const state=tableState();
      if(!state.eligible||!message.tableToken||message.tableToken!==state.token||!tableAllowed.has(message.type))throw Object.assign(new Error('补货参考编辑抽屉已关闭或切换，请重新选择规格'),{code:'TABLE_TARGET_CHANGED'});
      return handlers[message.type](message);
    }).then(data=>respond({ok:true,data}),e=>respond({ok:false,error:{code:e.code||'ADAPTER_ERROR',message:e.message||'页面适配失败',...(e.details?{details:e.details}:{})}}));
    return true;
  });
  if(globalThis.__QNH_ADAPTER_TEST__)globalThis.__QNH_ADAPTER_TEST_HOOKS__={handlers,extract,field,urlIds,fingerprint,visible,routeRelationId,nativeRouteInfo,nativeNodes,nativeSnapshot,selectedProductCards,procurementEvidence,nativeCompletionDriver,setCompletionDriver:driver=>{completionDriver=driver||nativeCompletionDriver;}};
})();
